/**
 * DevHelper - 万能计算器工具脚本
 * 功能包括：标准与科学计算器（安全数学表达式解析）、实时汇率换算（含 API 刷新与本地备份降级）、房贷还款计划推演
 */

document.addEventListener('DOMContentLoaded', () => {
  // ─── 统一初始化 ───
  createNavbar('万能计算器');
  initTabs();
  initCalculator();
  initExchange();
  initLoan();
  initUnits();
  initSpecialized();
  initAIPanel();
});

// ─── 选项卡切换逻辑 ───
let currentTabId = 'calculator';
function initTabs() {
  const tabBtns = document.querySelectorAll('.tab-btn');
  const panels = document.querySelectorAll('.calc-panel');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = btn.dataset.tab;
      currentTabId = tab;
      
      tabBtns.forEach(b => b.classList.remove('active'));
      panels.forEach(p => p.classList.remove('active'));

      btn.classList.add('active');
      const targetPanel = document.getElementById(`panel-${tab}`);
      if (targetPanel) {
        targetPanel.classList.add('active');
      }
    });
  });
}

// ─── 模块一：安全数学表达式解析与计算器 ───
let isScientificMode = false;
let currentFormula = '';
let isLastCharOperator = false;

// 预设按键列表
const STANDARD_KEYS = [
  { label: 'C', class: 'clear' },
  { label: '(', class: 'op' },
  { label: ')', class: 'op' },
  { label: '⌫', class: 'clear', action: 'backspace' },
  { label: '7', class: 'num' },
  { label: '8', class: 'num' },
  { label: '9', class: 'num' },
  { label: '÷', class: 'op' },
  { label: '4', class: 'num' },
  { label: '5', class: 'num' },
  { label: '6', class: 'num' },
  { label: '×', class: 'op' },
  { label: '1', class: 'num' },
  { label: '2', class: 'num' },
  { label: '3', class: 'num' },
  { label: '-', class: 'op' },
  { label: '0', class: 'num' },
  { label: '.', class: 'num' },
  { label: '=', class: 'eq' },
  { label: '+', class: 'op' }
];

const SCIENTIFIC_KEYS = [
  { label: 'sin', class: 'sci' },
  { label: 'cos', class: 'sci' },
  { label: 'tan', class: 'sci' },
  { label: 'C', class: 'clear' },
  { label: '⌫', class: 'clear', action: 'backspace' },
  
  { label: 'ln', class: 'sci' },
  { label: 'log', class: 'sci' },
  { label: '^', class: 'op' },
  { label: '(', class: 'op' },
  { label: ')', class: 'op' },
  
  { label: '√', class: 'sci', value: 'sqrt(' },
  { label: '7', class: 'num' },
  { label: '8', class: 'num' },
  { label: '9', class: 'num' },
  { label: '÷', class: 'op' },
  
  { label: 'π', class: 'sci' },
  { label: '4', class: 'num' },
  { label: '5', class: 'num' },
  { label: '6', class: 'num' },
  { label: '×', class: 'op' },
  
  { label: 'e', class: 'sci' },
  { label: '1', class: 'num' },
  { label: '2', class: 'num' },
  { label: '3', class: 'num' },
  { label: '-', class: 'op' },
  
  { label: '%', class: 'op' },
  { label: '0', class: 'num' },
  { label: '.', class: 'num' },
  { label: '=', class: 'eq' },
  { label: '+', class: 'op' }
];

function initCalculator() {
  const grid = document.getElementById('calcGrid');
  const btnToggle = document.getElementById('btnToggleScience');
  
  // 切换科学模式
  btnToggle.addEventListener('click', () => {
    isScientificMode = !isScientificMode;
    btnToggle.textContent = isScientificMode ? '返回标准计算' : '切换科学计算';
    renderCalcGrid();
  });

  renderCalcGrid();
  bindKeyboardEvents();
}

function renderCalcGrid() {
  const grid = document.getElementById('calcGrid');
  grid.innerHTML = '';
  
  if (isScientificMode) {
    grid.className = 'calc-grid scientific';
    SCIENTIFIC_KEYS.forEach(key => grid.appendChild(createCalcButton(key)));
  } else {
    grid.className = 'calc-grid';
    STANDARD_KEYS.forEach(key => grid.appendChild(createCalcButton(key)));
  }
}

function createCalcButton(key) {
  const btn = document.createElement('button');
  btn.className = `calc-btn ${key.class}`;
  btn.textContent = key.label;
  
  btn.addEventListener('click', () => {
    handleCalcInput(key.value || key.label, key.action);
  });
  
  return btn;
}

function handleCalcInput(value, action) {
  const formulaEl = document.getElementById('calcFormula');
  const resultEl = document.getElementById('calcResult');
  
  if (action === 'backspace') {
    // 退格
    if (currentFormula.length > 0) {
      // 如果删除的是诸如 sin(, cos(, sqrt( 等函数，我们尝试一次性删掉它们
      const functions = ['sin(', 'cos(', 'tan(', 'sqrt(', 'log(', 'ln('];
      let deleted = false;
      for (const fn of functions) {
        if (currentFormula.endsWith(fn)) {
          currentFormula = currentFormula.substring(0, currentFormula.length - fn.length);
          deleted = true;
          break;
        }
      }
      if (!deleted) {
        currentFormula = currentFormula.slice(0, -1);
      }
    }
  } else if (value === 'C') {
    // 清空
    currentFormula = '';
    resultEl.textContent = '0';
  } else if (value === '=') {
    // 执行计算
    if (!currentFormula.trim()) return;
    try {
      const res = safeEvaluate(currentFormula);
      // 格式化输出，处理浮点数精度问题，如 0.1 + 0.2
      if (typeof res === 'number') {
        if (Number.isNaN(res)) {
          resultEl.textContent = 'NaN';
        } else if (!Number.isFinite(res)) {
          resultEl.textContent = 'Infinity';
        } else {
          // 限制最多 10 位小数以防溢出
          resultEl.textContent = parseFloat(res.toFixed(10)).toString();
        }
      } else {
        resultEl.textContent = res;
      }
    } catch (err) {
      resultEl.textContent = 'Error';
      console.error('计算错误：', err);
    }
    return;
  } else {
    // 追加算式
    // 防止连续输入两个运算符
    const ops = ['+', '-', '×', '÷', '%', '^'];
    const valIsOp = ops.includes(value);
    
    if (valIsOp && currentFormula.length === 0 && value !== '-') {
      // 初始不能输入除负号外的运算符
      return;
    }
    
    const lastChar = currentFormula[currentFormula.length - 1];
    const lastCharIsOp = ops.includes(lastChar);
    
    if (valIsOp && lastCharIsOp) {
      // 连续操作符，则替换最后一个
      currentFormula = currentFormula.slice(0, -1) + value;
    } else {
      // 函数类追加
      if (['sin', 'cos', 'tan', 'ln', 'log'].includes(value)) {
        currentFormula += value + '(';
      } else {
        currentFormula += value;
      }
    }
  }
  
  formulaEl.textContent = currentFormula;
}

// 绑定物理键盘按键
function bindKeyboardEvents() {
  document.addEventListener('keydown', (e) => {
    if (currentTabId !== 'calculator') return;
    
    // 如果焦点在输入框（比如 AI 侧边栏的搜索），则不接管键盘
    if (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA') {
      return;
    }

    const key = e.key;
    if (/[0-9.]/.test(key)) {
      handleCalcInput(key);
    } else if (key === '+') {
      handleCalcInput('+');
    } else if (key === '-') {
      handleCalcInput('-');
    } else if (key === '*') {
      handleCalcInput('×');
    } else if (key === '/') {
      e.preventDefault();
      handleCalcInput('÷');
    } else if (key === '%') {
      handleCalcInput('%');
    } else if (key === '^') {
      handleCalcInput('^');
    } else if (key === '(' || key === ')') {
      handleCalcInput(key);
    } else if (key === 'Enter' || key === '=') {
      e.preventDefault();
      handleCalcInput('=');
    } else if (key === 'Backspace') {
      handleCalcInput(null, 'backspace');
    } else if (key === 'Escape') {
      handleCalcInput('C');
    }
  });
}

// ─── 纯 JS 安全数学解析器实现 (Shunting-yard + RPN) ───
function safeEvaluate(expression) {
  let expr = expression
    .replace(/×/g, '*')
    .replace(/÷/g, '/');

  // 补全括号，防止少输入括号报错
  let openBrackets = 0;
  for (let i = 0; i < expr.length; i++) {
    if (expr[i] === '(') openBrackets++;
    if (expr[i] === ')') openBrackets--;
  }
  while (openBrackets > 0) {
    expr += ')';
    openBrackets--;
  }

  // 隐式乘法自动补全
  // 1) 数字 后面紧跟 字母(函数/e)、π、左括号
  expr = expr.replace(/(\d)(?=[a-zA-Z\(π])/g, '$1*');
  // 2) π 后面紧跟 数字、字母、左括号
  expr = expr.replace(/(π)(?=[0-9a-zA-Z\(])/g, '$1*');
  // 3) e 后面紧跟 数字、字母、左括号
  expr = expr.replace(/(e)(?=[0-9a-zA-Z\(])/g, '$1*');
  // 4) 右括号 后面紧跟 数字、字母、π、左括号
  expr = expr.replace(/(\))(?=[0-9a-zA-Z\(π])/g, '$1*');

  // Tokenize
  const tokens = [];
  let i = 0;
  while (i < expr.length) {
    const c = expr[i];
    if (/\s/.test(c)) {
      i++;
      continue;
    }
    
    if (['(', ')', '+', '-', '*', '/', '%', '^'].includes(c)) {
      // 区分减号与负号：如果 - 处于最前，或者前一个 token 是操作符/左括号，则判定为单目负号
      if (c === '-') {
        const lastToken = tokens[tokens.length - 1];
        if (tokens.length === 0 || ['+', '-', '*', '/', '%', '^', '('].includes(lastToken)) {
          tokens.push('neg');
          i++;
          continue;
        }
      }
      tokens.push(c);
      i++;
    } else if (/[0-9.]/.test(c)) {
      let numStr = '';
      while (i < expr.length && /[0-9.]/.test(expr[i])) {
        numStr += expr[i];
        i++;
      }
      tokens.push(parseFloat(numStr));
    } else if (/[a-zA-Z]/.test(c)) {
      let funcStr = '';
      while (i < expr.length && /[a-zA-Z]/.test(expr[i])) {
        funcStr += expr[i];
        i++;
      }
      tokens.push(funcStr);
    } else if (c === 'π') {
      tokens.push(Math.PI);
      i++;
    } else {
      i++; // 忽略其他不支持的字符
    }
  }

  // Shunting-yard 转换逆波兰表达式
  const outputQueue = [];
  const operatorStack = [];
  const operators = {
    '+': { precedence: 2, associativity: 'Left' },
    '-': { precedence: 2, associativity: 'Left' },
    '*': { precedence: 3, associativity: 'Left' },
    '/': { precedence: 3, associativity: 'Left' },
    '%': { precedence: 3, associativity: 'Left' },
    '^': { precedence: 4, associativity: 'Right' },
    'neg': { precedence: 5, associativity: 'Right' }
  };
  const functions = ['sin', 'cos', 'tan', 'sqrt', 'log', 'ln'];

  for (const token of tokens) {
    if (typeof token === 'number') {
      outputQueue.push(token);
    } else if (functions.includes(token)) {
      operatorStack.push(token);
    } else if (token in operators) {
      const o1 = token;
      let o2 = operatorStack[operatorStack.length - 1];
      while (
        o2 &&
        (o2 in operators || functions.includes(o2)) &&
        (functions.includes(o2) ||
          (operators[o1].associativity === 'Left' && operators[o1].precedence <= operators[o2].precedence) ||
          (operators[o1].associativity === 'Right' && operators[o1].precedence < operators[o2].precedence))
      ) {
        outputQueue.push(operatorStack.pop());
        o2 = operatorStack[operatorStack.length - 1];
      }
      operatorStack.push(o1);
    } else if (token === '(') {
      operatorStack.push(token);
    } else if (token === ')') {
      let top = operatorStack[operatorStack.length - 1];
      while (top && top !== '(') {
        outputQueue.push(operatorStack.pop());
        top = operatorStack[operatorStack.length - 1];
      }
      if (!top) throw new Error('括号不匹配');
      operatorStack.pop(); // 弹出 '('
      if (functions.includes(operatorStack[operatorStack.length - 1])) {
        outputQueue.push(operatorStack.pop());
      }
    }
  }

  while (operatorStack.length > 0) {
    const top = operatorStack.pop();
    if (top === '(' || top === ')') throw new Error('括号不匹配');
    outputQueue.push(top);
  }

  // RPN 求值
  const stack = [];
  const mathFuncs = {
    'sin': (x) => Math.sin(x * Math.PI / 180),
    'cos': (x) => Math.cos(x * Math.PI / 180),
    'tan': (x) => Math.tan(x * Math.PI / 180),
    'sqrt': (x) => {
      if (x < 0) throw new Error('负数不能求平方根');
      return Math.sqrt(x);
    },
    'log': (x) => {
      if (x <= 0) throw new Error('对数自变量必须大于0');
      return Math.log10(x);
    },
    'ln': (x) => {
      if (x <= 0) throw new Error('对数自变量必须大于0');
      return Math.log(x);
    }
  };

  for (const token of outputQueue) {
    if (typeof token === 'number') {
      stack.push(token);
    } else if (token === 'neg') {
      const x = stack.pop();
      if (x === undefined) throw new Error('表达式不完整');
      stack.push(-x);
    } else if (token in mathFuncs) {
      const x = stack.pop();
      if (x === undefined) throw new Error('表达式不完整');
      stack.push(mathFuncs[token](x));
    } else {
      const b = stack.pop();
      const a = stack.pop();
      if (a === undefined || b === undefined) throw new Error('表达式不完整');
      switch (token) {
        case '+': stack.push(a + b); break;
        case '-': stack.push(a - b); break;
        case '*': stack.push(a * b); break;
        case '/':
          if (b === 0) throw new Error('除数不能为零');
          stack.push(a / b);
          break;
        case '%': stack.push(a % b); break;
        case '^': stack.push(Math.pow(a, b)); break;
      }
    }
  }

  if (stack.length !== 1) throw new Error('语法错误');
  return stack[0];
}

// ─── 模块二：汇率换算逻辑 ───
// 降级本地硬编码汇率，以 USD 为基准
const DEFAULT_RATES = {
  "USD": 1.0,
  "CNY": 7.258,
  "EUR": 0.918,
  "JPY": 156.24,
  "GBP": 0.785,
  "HKD": 7.812,
  "AUD": 1.505,
  "CAD": 1.368,
  "SGD": 1.348,
  "KRW": 1378.5
};

const CURRENCY_NAMES = {
  "CNY": "人民币 (CNY)",
  "USD": "美元 (USD)",
  "EUR": "欧元 (EUR)",
  "JPY": "日元 (JPY)",
  "GBP": "英镑 (GBP)",
  "HKD": "港币 (HKD)",
  "AUD": "澳元 (AUD)",
  "CAD": "加拿大元 (CAD)",
  "SGD": "新加坡元 (SGD)",
  "KRW": "韩元 (KRW)"
};

let activeRates = { ...DEFAULT_RATES };
let ratesLastUpdate = "2026-07-16 00:00:00 (本地预设)";
let isOfflineMode = false;

async function initExchange() {
  const fromSelect = document.getElementById('exchangeFromCurrency');
  const toSelect = document.getElementById('exchangeToCurrency');
  
  // 初始化下拉框选项
  Object.keys(CURRENCY_NAMES).forEach(code => {
    const optFrom = document.createElement('option');
    optFrom.value = code;
    optFrom.textContent = CURRENCY_NAMES[code];
    if (code === 'USD') optFrom.selected = true;
    fromSelect.appendChild(optFrom);

    const optTo = document.createElement('option');
    optTo.value = code;
    optTo.textContent = CURRENCY_NAMES[code];
    if (code === 'CNY') optTo.selected = true;
    toSelect.appendChild(optTo);
  });

  // 绑定事件
  document.getElementById('exchangeFromAmount').addEventListener('input', () => {
    convertCurrency('from');
  });
  document.getElementById('exchangeToAmount').addEventListener('input', () => {
    convertCurrency('to');
  });
  fromSelect.addEventListener('change', () => convertCurrency('from'));
  toSelect.addEventListener('change', () => convertCurrency('from'));
  
  // 交换货币
  document.getElementById('btnSwapCurrency').addEventListener('click', () => {
    const tmp = fromSelect.value;
    fromSelect.value = toSelect.value;
    toSelect.value = tmp;
    
    const fromVal = parseFloat(document.getElementById('exchangeFromAmount').value) || 0;
    const toVal = parseFloat(document.getElementById('exchangeToAmount').value) || 0;
    
    document.getElementById('exchangeFromAmount').value = toVal;
    document.getElementById('exchangeToAmount').value = fromVal;
    
    convertCurrency('from');
  });

  document.getElementById('btnRefreshExchange').addEventListener('click', () => {
    fetchRates(true);
  });

  // 首次获取汇率
  await fetchRates(false);
}

// 核心转换逻辑
function convertCurrency(direction = 'from') {
  const fromSelect = document.getElementById('exchangeFromCurrency');
  const toSelect = document.getElementById('exchangeToCurrency');
  const fromInput = document.getElementById('exchangeFromAmount');
  const toInput = document.getElementById('exchangeToAmount');

  const fromCode = fromSelect.value;
  const toCode = toSelect.value;
  
  const rateFromUsd = activeRates[fromCode];
  const rateToUsd = activeRates[toCode];
  
  if (!rateFromUsd || !rateToUsd) return;

  // 汇率转换计算： 1 unit of A = (rateToUsd / rateFromUsd) unit of B
  if (direction === 'from') {
    const val = parseFloat(fromInput.value);
    if (Number.isNaN(val) || val < 0) {
      toInput.value = '';
      return;
    }
    const result = val * (rateToUsd / rateFromUsd);
    toInput.value = parseFloat(result.toFixed(4));
  } else {
    const val = parseFloat(toInput.value);
    if (Number.isNaN(val) || val < 0) {
      fromInput.value = '';
      return;
    }
    const result = val * (rateFromUsd / rateToUsd);
    fromInput.value = parseFloat(result.toFixed(4));
  }
}

// 获取汇率数据并做完备降级处理
async function fetchRates(isManual = false) {
  const statusEl = document.getElementById('exchangeStatus');
  statusEl.className = 'exchange-status';
  statusEl.textContent = '正在获取实时汇率数据...';

  try {
    const res = await fetch('https://open.er-api.com/v6/latest/USD');
    if (!res.ok) throw new Error('网络请求异常');
    
    const data = await res.json();
    if (data.result === 'success' && data.rates) {
      // 成功获取
      activeRates = {};
      Object.keys(DEFAULT_RATES).forEach(code => {
        if (data.rates[code]) {
          activeRates[code] = data.rates[code];
        } else {
          activeRates[code] = DEFAULT_RATES[code]; // API 漏掉的，用本地预设补充
        }
      });
      
      ratesLastUpdate = data.time_last_update_utc || new Date().toUTCString();
      isOfflineMode = false;
      
      // 保存至 chrome.storage 做缓存
      if (typeof chrome !== 'undefined' && chrome.storage) {
        try {
          await chrome.storage.local.set({
            'exchange_rates_cache': activeRates,
            'exchange_rates_update_time': ratesLastUpdate,
            'exchange_rates_fetch_time': Date.now()
          });
        } catch (e) {
          console.warn('保存汇率缓存失败：', e);
        }
      }
      
      statusEl.textContent = `实时汇率由 Open Exchange Rates API 提供，更新于：${ratesLastUpdate}`;
      if (isManual && typeof showToast !== 'undefined') {
        showToast('汇率数据已刷新');
      }
    } else {
      throw new Error('API 返回数据格式错误');
    }
  } catch (err) {
    console.warn('获取汇率接口失败，启用降级方案：', err);
    isOfflineMode = true;
    
    // 尝试读取本地 chrome.storage 缓存
    let loadedFromCache = false;
    if (typeof chrome !== 'undefined' && chrome.storage) {
      try {
        const cached = await chrome.storage.local.get(['exchange_rates_cache', 'exchange_rates_update_time']);
        if (cached.exchange_rates_cache) {
          activeRates = cached.exchange_rates_cache;
          ratesLastUpdate = cached.exchange_rates_update_time;
          statusEl.className = 'exchange-status offline';
          statusEl.textContent = `⚠️ 网络连接失败，已加载本地缓存汇率（更新于：${ratesLastUpdate}）`;
          loadedFromCache = true;
        }
      } catch (e) {
        console.warn('读取汇率缓存失败：', e);
      }
    }
    
    if (!loadedFromCache) {
      // 若缓存无，则使用出厂预设
      activeRates = { ...DEFAULT_RATES };
      ratesLastUpdate = "2026-07-16 00:00:00 (出厂硬编码备份)";
      statusEl.className = 'exchange-status offline';
      statusEl.textContent = `⚠️ 无法连接实时汇率服务，已自动启用离线备份汇率（更新于：${ratesLastUpdate}）`;
    }
  }

  // 渲染常用汇率表格与更新计算
  renderRatesTable();
  convertCurrency('from');
}

// 渲染常用汇率表格
function renderRatesTable() {
  const grid = document.getElementById('exchangeRatesGrid');
  grid.innerHTML = '';
  
  const table = document.createElement('table');
  table.className = 'loan-result-table';
  table.innerHTML = `
    <thead>
      <tr>
        <th>货币代码</th>
        <th>货币名称</th>
        <th>当前汇率 (以 1 USD 为基底)</th>
        <th>100 人民币 (CNY) 可兑换</th>
      </tr>
    </thead>
    <tbody></tbody>
  `;
  
  const tbody = table.querySelector('tbody');
  const cnyRate = activeRates['CNY'];
  
  Object.keys(CURRENCY_NAMES).forEach(code => {
    if (code === 'CNY') return; // 不对比 CNY 自己
    
    const rateVal = activeRates[code];
    // 100 CNY 可以换多少： 100 * (rateVal / cnyRate)
    const converted = 100 * (rateVal / cnyRate);
    
    const row = document.createElement('tr');
    row.innerHTML = `
      <td style="font-weight:700">${code}</td>
      <td>${CURRENCY_NAMES[code].split(' ')[0]}</td>
      <td>${parseFloat(rateVal.toFixed(4))}</td>
      <td style="color:var(--primary);font-weight:700">${parseFloat(converted.toFixed(2))} ${code}</td>
    `;
    tbody.appendChild(row);
  });
  
  grid.appendChild(table);
}

// ─── 模块三：房贷还款计划推演 ───
function initLoan() {
  const yearsSelect = document.getElementById('loanYearsSelect');
  const customMonthsInput = document.getElementById('loanMonthsCustom');
  
  yearsSelect.addEventListener('change', () => {
    if (yearsSelect.value === 'custom') {
      customMonthsInput.style.display = 'block';
      customMonthsInput.focus();
    } else {
      customMonthsInput.style.display = 'none';
    }
  });

  document.getElementById('btnCalculateLoan').addEventListener('click', calculateLoanPlan);
}

function calculateLoanPlan() {
  const amountVal = parseFloat(document.getElementById('loanAmount').value);
  const yearsSelect = document.getElementById('loanYearsSelect');
  const customMonthsInput = document.getElementById('loanMonthsCustom');
  const rateVal = parseFloat(document.getElementById('loanRate').value);
  const method = document.getElementById('loanMethod').value;
  
  let months = 0;
  if (yearsSelect.value === 'custom') {
    months = parseInt(customMonthsInput.value, 10);
  } else {
    months = parseInt(yearsSelect.value, 10) * 12;
  }
  
  // 参数安全校验
  if (Number.isNaN(amountVal) || amountVal <= 0) {
    if (typeof showToast !== 'undefined') showToast('请输入有效的贷款本金', 'error');
    return;
  }
  if (Number.isNaN(months) || months <= 0) {
    if (typeof showToast !== 'undefined') showToast('请输入正确的还款期数（月数）', 'error');
    return;
  }
  if (Number.isNaN(rateVal) || rateVal <= 0) {
    if (typeof showToast !== 'undefined') showToast('请输入正确的年化利率', 'error');
    return;
  }

  const principal = amountVal * 10000; // 万元转元
  const annualRate = rateVal / 100;
  const monthlyRate = annualRate / 12; // 月利率
  
  const tbody = document.getElementById('loanResultBody');
  tbody.innerHTML = '';

  const firstMonthLabel = document.getElementById('firstMonthLabel');
  const decreaseLabel = document.getElementById('decreaseLabel');
  
  let totalInterest = 0;
  let totalRepay = 0;
  let firstMonthPay = 0;
  let monthlyDecrease = 0;
  
  const listData = [];
  
  if (method === 'acpi') {
    // 1. 等额本息
    firstMonthLabel.textContent = '每月月供';
    decreaseLabel.textContent = '月供性质';
    
    // 每月月供公式: [P * R * (1 + R)^N] / [(1 + R)^N - 1]
    const monthlyPay = principal * (monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1);
    firstMonthPay = monthlyPay;
    monthlyDecrease = 0; // 等额本息每月无递减
    
    document.getElementById('summaryDecrease').textContent = '固定额度';
    
    let remainingPrincipal = principal;
    let accumulatedPrincipal = 0;
    let accumulatedInterest = 0;
    
    // 计算利息总和
    totalRepay = monthlyPay * months;
    totalInterest = totalRepay - principal;

    for (let m = 1; m <= months; m++) {
      const interest = remainingPrincipal * monthlyRate; // 当期利息
      const principalPaid = monthlyPay - interest; // 当期本金
      
      accumulatedPrincipal += principalPaid;
      accumulatedInterest += interest;
      remainingPrincipal -= principalPaid;
      
      // 避免剩余本金由于浮点数产生细微负数
      const displayRemainingPrincipal = Math.max(0, remainingPrincipal);
      // 剩余总利息
      const displayRemainingInterest = Math.max(0, totalInterest - accumulatedInterest);

      listData.push({
        num: m,
        monthlyPay: monthlyPay,
        principalPaid: principalPaid,
        interestPaid: interest,
        accumulatedPrincipal: accumulatedPrincipal,
        accumulatedInterest: accumulatedInterest,
        remainingPrincipal: displayRemainingPrincipal,
        remainingInterest: displayRemainingInterest
      });
    }
  } else {
    // 2. 等额本金
    firstMonthLabel.textContent = '首月月供';
    decreaseLabel.textContent = '每月递减';
    
    // 每月本金固定
    const principalPerMonth = principal / months;
    let remainingPrincipal = principal;
    let accumulatedPrincipal = 0;
    let accumulatedInterest = 0;
    
    // 每月递减额: 每月应还本金 * 月利率
    monthlyDecrease = principalPerMonth * monthlyRate;
    document.getElementById('summaryDecrease').textContent = `${monthlyDecrease.toFixed(2)} 元`;
    
    // 先跑出全期的数据用以求得利息总和
    const tempPayments = [];
    for (let m = 1; m <= months; m++) {
      const interest = remainingPrincipal * monthlyRate; // 当期利息
      const monthlyPay = principalPerMonth + interest; // 当期月供
      
      accumulatedPrincipal += principalPerMonth;
      accumulatedInterest += interest;
      remainingPrincipal -= principalPerMonth;
      
      tempPayments.push({
        num: m,
        monthlyPay: monthlyPay,
        principalPaid: principalPerMonth,
        interestPaid: interest,
        accumulatedPrincipal: accumulatedPrincipal,
        accumulatedInterest: accumulatedInterest,
        remainingPrincipal: Math.max(0, remainingPrincipal)
      });
    }
    
    totalInterest = accumulatedInterest;
    totalRepay = principal + totalInterest;
    firstMonthPay = tempPayments[0].monthlyPay;
    
    tempPayments.forEach(p => {
      listData.push({
        ...p,
        remainingInterest: Math.max(0, totalInterest - p.accumulatedInterest)
      });
    });
  }
  
  // 更新四个汇总大字卡
  document.getElementById('summaryFirstMonth').textContent = `${firstMonthPay.toFixed(2)} 元`;
  document.getElementById('summaryTotalInterest').textContent = `${(totalInterest / 10000).toFixed(2)} 万元`;
  document.getElementById('summaryTotalRepay').textContent = `${(totalRepay / 10000).toFixed(2)} 万元`;
  
  // 渲染汇总表头及合计行
  const totalRow = document.createElement('tr');
  totalRow.className = 'total-row';
  totalRow.innerHTML = `
    <td>合计</td>
    <td>${(totalRepay / 10000).toFixed(2)} 万元</td>
    <td>${(principal / 10000).toFixed(2)} 万元</td>
    <td>${(totalInterest / 10000).toFixed(2)} 万元</td>
    <td colspan="4" style="color:var(--text-tertiary);font-weight:normal;text-align:center">以汇总值为准 · 详细推演如下</td>
  `;
  tbody.appendChild(totalRow);
  
  // 循环插入每期还款行
  listData.forEach(item => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>第 ${item.num} 期</td>
      <td style="font-weight:600;color:var(--text-primary)">${item.monthlyPay.toFixed(2)} 元</td>
      <td>${item.principalPaid.toFixed(2)} 元</td>
      <td>${item.interestPaid.toFixed(2)} 元</td>
      <td>${item.accumulatedPrincipal.toFixed(2)} 元</td>
      <td>${item.accumulatedInterest.toFixed(2)} 元</td>
      <td>${item.remainingPrincipal.toFixed(2)} 元</td>
      <td>${item.remainingInterest.toFixed(2)} 元</td>
    `;
    tbody.appendChild(row);
  });
  
  if (typeof showToast !== 'undefined') {
    showToast('房贷计划多维推演成功');
  }
}

// ─── 模块四：常用单位换算 ───
const UNIT_CATEGORIES = {
  length: {
    name: '长度换算',
    base: 'm', // 基准单位
    units: [
      { code: 'km', name: '千米 (km)', rate: 1000 },
      { code: 'm', name: '米 (m)', rate: 1.0 },
      { code: 'dm', name: '分米 (dm)', rate: 0.1 },
      { code: 'cm', name: '厘米 (cm)', rate: 0.01 },
      { code: 'mm', name: '毫米 (mm)', rate: 0.001 },
      { code: 'um', name: '微米 (µm)', rate: 0.000001 },
      { code: 'li', name: '里', rate: 500 },
      { code: 'zhang', name: '丈', rate: 3.3333333333 },
      { code: 'chi', name: '尺', rate: 0.3333333333 },
      { code: 'cun', name: '寸', rate: 0.0333333333 },
      { code: 'mile', name: '英里 (mile)', rate: 1609.344 },
      { code: 'yd', name: '码 (yd)', rate: 0.9144 },
      { code: 'ft', name: '英尺 (ft)', rate: 0.3048 },
      { code: 'in', name: '英寸 (in)', rate: 0.0254 }
    ]
  },
  weight: {
    name: '重量换算',
    base: 'kg',
    units: [
      { code: 't', name: '吨 (t)', rate: 1000 },
      { code: 'kg', name: '千克 (kg)', rate: 1.0 },
      { code: 'g', name: '克 (g)', rate: 0.001 },
      { code: 'mg', name: '毫克 (mg)', rate: 0.000001 },
      { code: 'jin', name: '斤', rate: 0.5 },
      { code: 'liang', name: '两', rate: 0.05 },
      { code: 'lb', name: '磅 (lb)', rate: 0.45359237 },
      { code: 'oz', name: '盎司 (oz)', rate: 0.0283495231 }
    ]
  },
  area: {
    name: '面积换算',
    base: 'm2',
    units: [
      { code: 'km2', name: '平方千米 (km²)', rate: 1000000 },
      { code: 'm2', name: '平方米 (㎡)', rate: 1.0 },
      { code: 'ha', name: '公顷 (ha)', rate: 10000 },
      { code: 'mu', name: '亩', rate: 666.6666666667 },
      { code: 'mile2', name: '平方英里 (mile²)', rate: 2589988.1103 },
      { code: 'acre', name: '英亩', rate: 4046.8564 },
      { code: 'ft2', name: '平方英尺 (ft²)', rate: 0.09290304 }
    ]
  },
  volume: {
    name: '体积换算',
    base: 'L',
    units: [
      { code: 'm3', name: '立方米 (m³)', rate: 1000 },
      { code: 'dm3', name: '立方分米 (dm³)', rate: 1.0 },
      { code: 'cm3', name: '立方厘米 (cm³)', rate: 0.001 },
      { code: 'L', name: '升 (L)', rate: 1.0 },
      { code: 'mL', name: '毫升 (mL)', rate: 0.001 },
      { code: 'gal', name: '加仑 (gal)', rate: 3.78541178 },
      { code: 'qt', name: '夸脱 (qt)', rate: 0.9463529 },
      { code: 'pt', name: '品脱 (pt)', rate: 0.4731764 }
    ]
  },
  temperature: {
    name: '温度换算',
    base: 'C',
    units: [
      { code: 'C', name: '摄氏度 (°C)' },
      { code: 'F', name: '华氏度 (°F)' },
      { code: 'K', name: '开氏度 (K)' }
    ]
  },
  speed: {
    name: '速度换算',
    base: 'm_s',
    units: [
      { code: 'm_s', name: '米每秒 (m/s)', rate: 1.0 },
      { code: 'km_h', name: '千米每小时 (km/h)', rate: 0.2777777778 },
      { code: 'mph', name: '英里每小时 (mph)', rate: 0.44704 },
      { code: 'knot', name: '节 (knot)', rate: 0.5144444444 },
      { code: 'mach', name: '马赫 (mach)', rate: 340.3 }
    ]
  }
};

let activeUnitsCategory = 'length';
let isUnitsUpdating = false;

function initUnits() {
  const catBtns = document.querySelectorAll('.units-cat-btn');
  catBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      catBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeUnitsCategory = btn.dataset.cat;
      renderUnitsGrid();
    });
  });

  document.getElementById('btnResetUnits').addEventListener('click', () => {
    const fields = document.querySelectorAll('.unit-input-field');
    fields.forEach(f => f.value = '');
  });

  renderUnitsGrid();
}

function renderUnitsGrid() {
  const grid = document.getElementById('unitsGrid');
  grid.innerHTML = '';

  const catData = UNIT_CATEGORIES[activeUnitsCategory];
  catData.units.forEach(unit => {
    const group = document.createElement('div');
    group.className = 'unit-input-group';
    group.innerHTML = `
      <label class="unit-label">${unit.name}</label>
      <div class="unit-input-wrap">
        <input type="number" class="form-input unit-input-field" data-unit="${unit.code}" placeholder="输入数值" step="any">
      </div>
    `;
    
    const input = group.querySelector('input');
    input.addEventListener('input', () => {
      if (isUnitsUpdating) return;
      handleUnitConvert(unit.code, parseFloat(input.value));
    });
    
    grid.appendChild(group);
  });
}

function handleUnitConvert(sourceCode, value) {
  if (Number.isNaN(value)) {
    isUnitsUpdating = true;
    const fields = document.querySelectorAll('.unit-input-field');
    fields.forEach(f => {
      if (f.dataset.unit !== sourceCode) f.value = '';
    });
    isUnitsUpdating = false;
    return;
  }

  isUnitsUpdating = true;
  const catData = UNIT_CATEGORIES[activeUnitsCategory];
  
  // 1. 先计算基准单位数值 (baseValue)
  let baseValue = 0;
  if (activeUnitsCategory === 'temperature') {
    if (sourceCode === 'C') baseValue = value;
    else if (sourceCode === 'F') baseValue = (value - 32) / 1.8;
    else if (sourceCode === 'K') baseValue = value - 273.15;
  } else {
    const srcUnit = catData.units.find(u => u.code === sourceCode);
    baseValue = value * srcUnit.rate;
  }

  // 2. 转换并更新其他所有输入框
  const fields = document.querySelectorAll('.unit-input-field');
  fields.forEach(f => {
    const targetCode = f.dataset.unit;
    if (targetCode === sourceCode) return;

    let targetValue = 0;
    if (activeUnitsCategory === 'temperature') {
      if (targetCode === 'C') targetValue = baseValue;
      else if (targetCode === 'F') targetValue = baseValue * 1.8 + 32;
      else if (targetCode === 'K') targetValue = baseValue + 273.15;
    } else {
      const tgtUnit = catData.units.find(u => u.code === targetCode);
      targetValue = baseValue / tgtUnit.rate;
    }

    // 格式化输出浮点数，最大保留 8 位小数
    if (Math.abs(targetValue) < 1e-8 && targetValue !== 0) {
      f.value = targetValue.toExponential(4); // 极小数字用科学计数法
    } else {
      f.value = parseFloat(targetValue.toFixed(8));
    }
  });

  isUnitsUpdating = false;
}

// ─── 模块五：财务大写与 BMI 计算 ───
function initSpecialized() {
  // 人民币大写金额转换器
  const digitInput = document.getElementById('digitAmountInput');
  const capText = document.getElementById('cnyCapitalText');
  const copyBtn = document.getElementById('btnCopyCapital');

  digitInput.addEventListener('input', () => {
    const val = parseFloat(digitInput.value);
    if (Number.isNaN(val) || val < 0) {
      capText.textContent = '零元整';
      return;
    }
    if (val >= 1e12) {
      capText.textContent = '金额过大（已超万亿上限）';
      return;
    }
    capText.textContent = digitToChinese(val);
  });

  copyBtn.addEventListener('click', () => {
    const text = capText.textContent;
    if (!text || text === '金额过大（已超万亿上限）' || text === '金额无效') return;
    navigator.clipboard.writeText(text).then(() => {
      if (typeof showToast !== 'undefined') showToast('大写金额已复制到剪贴板');
    }).catch(err => {
      console.error('复制失败', err);
    });
  });

  // BMI 计算器
  const hInput = document.getElementById('bmiHeightInput');
  const wInput = document.getElementById('bmiWeightInput');
  const calcBtn = document.getElementById('btnCalculateBmi');
  const resetBtn = document.getElementById('btnResetBmi');
  const resBox = document.getElementById('bmiResultBox');
  const valText = document.getElementById('bmiValText');
  const statusText = document.getElementById('bmiStatusText');
  const tipsText = document.getElementById('bmiTipsText');

  const bmiAiAnalyzeBtn = document.getElementById('btnBmiAiAnalyze');
  const bmiAiOutput = document.getElementById('bmiAiOutput');

  calcBtn.addEventListener('click', () => {
    const height = parseFloat(hInput.value); // cm
    const weight = parseFloat(wInput.value); // kg

    if (Number.isNaN(height) || height <= 30 || height > 300) {
      if (typeof showToast !== 'undefined') showToast('请输入合适的身高 (30 ~ 300 cm)', 'error');
      return;
    }
    if (Number.isNaN(weight) || weight <= 2 || weight > 500) {
      if (typeof showToast !== 'undefined') showToast('请输入合适的体重 (2 ~ 500 kg)', 'error');
      return;
    }

    const heightM = height / 100;
    const bmi = weight / (heightM * heightM);

    valText.textContent = bmi.toFixed(1);
    resBox.style.display = 'flex';

    if (bmi < 18.5) {
      statusText.textContent = '偏瘦';
      statusText.style.background = '#3b82f6';
      tipsText.textContent = '您的 BMI 指数偏低，可能存在营养不良。建议多补充优质蛋白质与高营养膳食，配合力量训练增加肌肉量。';
    } else if (bmi < 24) {
      statusText.textContent = '正常';
      statusText.style.background = '#10b981';
      tipsText.textContent = '恭喜！您的 BMI 指数处于最健康的范围。请继续保持合理的饮食和规律运动，继续维持良好体态！';
    } else if (bmi < 28) {
      statusText.textContent = '超重';
      statusText.style.background = '#f59e0b';
      tipsText.textContent = '您的 BMI 指数属于超重范畴。建议适度调整饮食结构，减少高油高热量摄入，结合有氧运动以控制体重。';
    } else {
      statusText.textContent = '肥胖';
      statusText.style.background = '#ef4444';
      tipsText.textContent = '您的 BMI 指数已达肥胖级别，可能会增加心脑血管系统疾病风险。建议咨询专业医生或营养师，进行科学的体脂管理。';
    }

    // 重置之前的 AI 分析状态
    if (bmiAiOutput) {
      bmiAiOutput.style.display = 'none';
      bmiAiOutput.textContent = '点击按钮获取 AI 专家量身定制的运动与营养改善建议...';
    }

    if (typeof showToast !== 'undefined') showToast('BMI 指数计算成功');
  });

  if (bmiAiAnalyzeBtn && bmiAiOutput) {
    bmiAiAnalyzeBtn.addEventListener('click', () => {
      const height = parseFloat(hInput.value);
      const weight = parseFloat(wInput.value);
      const bmiVal = valText.textContent;
      const bmiStatus = statusText.textContent;
      const bmiTips = tipsText.textContent;

      if (!bmiVal || bmiVal === '-') {
        if (typeof showToast !== 'undefined') showToast('请先计算您的 BMI 指数', 'error');
        return;
      }

      // 1. 禁用诊断按钮并显示诊断中状态
      bmiAiAnalyzeBtn.disabled = true;
      const originalBtnText = bmiAiAnalyzeBtn.textContent;
      bmiAiAnalyzeBtn.textContent = '⚡ 诊断中...';
      bmiAiAnalyzeBtn.style.opacity = '0.7';
      bmiAiAnalyzeBtn.style.cursor = 'not-allowed';

      // 2. 展现带旋转加载动效的 Loading 提示
      bmiAiOutput.style.display = 'block';
      bmiAiOutput.innerHTML = `
        <div class="ai-loading-wrapper" style="display:flex;align-items:center;gap:12px;padding:6px 4px;">
          <div style="width:16px;height:16px;border:2px solid rgba(124, 58, 237, 0.15);border-top:2px solid var(--primary);border-radius:50%;animation:spin 0.8s linear infinite;flex-shrink:0;"></div>
          <span style="font-size:12px;color:var(--text-secondary);font-weight:500;">AI 专家正在分析您的体格指标，深度定制健康方案中...</span>
        </div>
      `;

      const bmiPrompt = `我的身高是 ${height} cm，体重是 ${weight} kg，计算得出 BMI 指数是 ${bmiVal}，处于「${bmiStatus}」状态。
已有的基础建议是：${bmiTips}。
请作为专业的营养与运动健康专家，为我量身定制一份包括：
1. 膳食营养改善建议（具体的能量比例及食材推荐）；
2. 科学的运动健身计划（有氧与力量训练频率及强度）；
3. 日常生活作息与健康管理贴士。
请用通俗易懂、温暖且专业的语气，以清晰的排版形式输出，字数在 250 字左右。`;

      const resetBtnState = () => {
        bmiAiAnalyzeBtn.disabled = false;
        bmiAiAnalyzeBtn.textContent = originalBtnText;
        bmiAiAnalyzeBtn.style.opacity = '1';
        bmiAiAnalyzeBtn.style.cursor = 'pointer';
      };

      if (typeof DevHelperAI !== 'undefined') {
        let isFirst = true;
        const systemPrompt = 'You are a professional nutritionist and fitness coach. Analyze user body metrics and provide constructive advice in Chinese.';
        DevHelperAI.callAI(
          systemPrompt,
          bmiPrompt,
          (fullText) => {
            if (isFirst) {
              bmiAiOutput.innerHTML = ''; // 清除 loading 动效
              isFirst = false;
            }
            if (typeof window.renderInlineMarkdown === 'function') {
              bmiAiOutput.innerHTML = window.renderInlineMarkdown(fullText);
            } else {
              bmiAiOutput.textContent = fullText;
            }
          }
        ).then(() => {
          resetBtnState();
        }).catch((err) => {
          console.error('BMI AI分析失败', err);
          bmiAiOutput.textContent = `❌ 智能分析失败: ${err.message || '网络连接异常，请重试'}`;
          resetBtnState();
        });
      } else {
        bmiAiOutput.textContent = '❌ 未检测到 AI 引擎服务，请在扩展侧边栏或右上角设置中进行检查。';
        resetBtnState();
      }
    });
  }

  resetBtn.addEventListener('click', () => {
    hInput.value = '';
    wInput.value = '';
    resBox.style.display = 'none';
    if (bmiAiOutput) {
      bmiAiOutput.style.display = 'none';
      bmiAiOutput.textContent = '点击按钮获取 AI 专家量身定制的运动与营养改善建议...';
    }
  });
}

function digitToChinese(n) {
  if (Number.isNaN(n) || n < 0) return '金额无效';
  const fraction = ['角', '分'];
  const digit = ['零', '壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖'];
  const unit = [
    ['元', '万', '亿'],
    ['', '拾', '佰', '仟']
  ];
  let head = n < 0 ? '欠' : '';
  n = Math.abs(n);
  let s = '';
  const decimalPart = Math.round((n % 1) * 100);
  if (decimalPart > 0) {
    const jiao = Math.floor(decimalPart / 10);
    const fen = decimalPart % 10;
    if (jiao > 0) s += digit[jiao] + fraction[0];
    if (fen > 0) s += digit[fen] + fraction[1];
  }
  
  let integerPart = Math.floor(n);
  for (let i = 0; i < unit[0].length && integerPart > 0; i++) {
    let p = '';
    for (let j = 0; j < unit[1].length && integerPart > 0; j++) {
      p = digit[integerPart % 10] + unit[1][j] + p;
      integerPart = Math.floor(integerPart / 10);
    }
    s = p.replace(/(零.)*零$/, '').replace(/^$/, '零') + unit[0][i] + s;
  }
  
  s = head + s.replace(/(零.)*零元/, '元')
              .replace(/(零.)+/g, '零')
              .replace(/^整$/, '零元整');
  if (s === '') {
    s = '零元整';
  } else if (!s.endsWith('分')) {
    s += '整';
  }
  return s;
}

// ─── 模块六：AI 智能诊断面板 ───
function initAIPanel() {
  const getContext = () => {
    let contextStr = `【万能计算器 - 当前所处面板】：${
      currentTabId === 'calculator' ? '标准/科学计算器' : 
      currentTabId === 'exchange' ? '实时汇率换算' : 
      currentTabId === 'loan' ? '房贷还款多维推演' : 
      currentTabId === 'units' ? '常用单位换算' : 
      currentTabId === 'capital' ? '财务大写金额' : 'BMI身体质量'
    }\n`;
    
    if (currentTabId === 'calculator') {
      const formula = document.getElementById('calcFormula').textContent;
      const result = document.getElementById('calcResult').textContent;
      contextStr += `当前算式表达式：${formula || '未输入'}\n`;
      contextStr += `实时计算结果：${result}\n`;
    } else if (currentTabId === 'exchange') {
      const fromSelect = document.getElementById('exchangeFromCurrency');
      const toSelect = document.getElementById('exchangeToCurrency');
      const fromInput = document.getElementById('exchangeFromAmount');
      const toInput = document.getElementById('exchangeToAmount');
      
      contextStr += `源币种：${fromSelect.value}，数量：${fromInput.value}\n`;
      contextStr += `目标币种：${toSelect.value}，转换额：${toInput.value}\n`;
      contextStr += `数据状态信息：${document.getElementById('exchangeStatus').textContent}\n`;
      contextStr += `所有币种最新汇率表一览（以美元USD为基准）：\n`;
      Object.keys(activeRates).forEach(k => {
        contextStr += `- ${k}: ${activeRates[k]}\n`;
      });
    } else if (currentTabId === 'loan') {
      const amountVal = document.getElementById('loanAmount').value;
      const yearsSelect = document.getElementById('loanYearsSelect');
      const rateVal = document.getElementById('loanRate').value;
      const method = document.getElementById('loanMethod').value;
      
      contextStr += `贷款总额：${amountVal} 万元\n`;
      contextStr += `贷款年限选择：${yearsSelect.value}年（或自定义月数）\n`;
      contextStr += `执行年化利率：${rateVal} %\n`;
      contextStr += `采用的还款方式：${method === 'acpi' ? '等额本息 (每月固定)' : '等额本金 (逐月递减)'}\n`;
      
      const firstMonth = document.getElementById('summaryFirstMonth').textContent;
      const decrease = document.getElementById('summaryDecrease').textContent;
      const totalInt = document.getElementById('summaryTotalInterest').textContent;
      const totalRepay = document.getElementById('summaryTotalRepay').textContent;
      
      contextStr += `推演概览结果：\n`;
      contextStr += `- 首月/月供金额：${firstMonth}\n`;
      contextStr += `- 每月递减金额：${decrease}\n`;
      contextStr += `- 累计支付利息：${totalInt}\n`;
      contextStr += `- 累计本息还款额：${totalRepay}\n`;
    } else if (currentTabId === 'units') {
      const catData = UNIT_CATEGORIES[activeUnitsCategory];
      contextStr += `当前正在进行【${catData.name}】换算。\n`;
      const fields = document.querySelectorAll('.unit-input-field');
      contextStr += `输入及换算对齐数值一览：\n`;
      fields.forEach(f => {
        if (f.value) {
          contextStr += `- ${f.previousElementSibling ? f.previousElementSibling.textContent : f.dataset.unit}: ${f.value}\n`;
        }
      });
    } else if (currentTabId === 'capital') {
      const digitInput = document.getElementById('digitAmountInput').value;
      const cnyCapital = document.getElementById('cnyCapitalText').textContent;
      
      contextStr += `【人民币大写转换模块】：\n`;
      contextStr += `- 阿拉伯数字金额：${digitInput || '未输入'} 元\n`;
      contextStr += `- 转换中文大写结果：${cnyCapital}\n`;
    } else if (currentTabId === 'bmi') {
      const bmiH = document.getElementById('bmiHeightInput').value;
      const bmiW = document.getElementById('bmiWeightInput').value;
      const bmiV = document.getElementById('bmiValText').textContent;
      const bmiS = document.getElementById('bmiStatusText').textContent;
      
      contextStr += `【BMI 身体质量计算模块】：\n`;
      contextStr += `- 输入身高：${bmiH || '未输入'} cm\n`;
      contextStr += `- 输入体重：${bmiW || '未输入'} kg\n`;
      contextStr += `- 计算得出 BMI：${bmiV}\n`;
      contextStr += `- 体质分级状态：${bmiS}\n`;
    }
    
    return contextStr;
  };

  const systemPrompt = `你是一个资深的数学解析、国际金融汇率、房贷理财、物理计量学单位换算以及人体健康管理综合顾问。
请根据用户在当前 DevHelper 「万能计算器」中操作生成的各项指标上下文数据（例如当前的算式输入、最新国际汇率折算、房贷还款计划汇总、物理单位换算对齐、或财务大写和BMI分析），为您提供专业的 AI 智能分析：
1. 如果是计算器模块，请对输入的公式的数学意义、应用场景进行智能剖析，或者在算式过于复杂时提供化简思路或相关常识说明。
2. 如果是汇率换算模块，请提供关于所选币种当前的宏观经济兑换背景、汇率机制常识、旅游/海淘/跨境支付的小贴士。
3. 如果是房贷月供推演模块，请基于等额本息和等额本金两种还款路径的利息落差分析家庭财务支出及提前还贷的财务决策。
4. 如果是物理单位换算模块，请科普对应单位分类（如长度、重量、面积、体积、温度、速度）的历史由来、英美制与公制转换常识，或特定物理量在科学与工程中的实际应用意义。
5. 如果是财务大写模块，请向用户解析大写金额的防篡改常识以及商业票据规范。
6. 如果是 BMI 模块，请根据用户的 BMI 计算值，提供详细的个性化膳食营养、身体管理与运动健康科普建议。
请使用清晰的 Markdown 排版，使用直观的列表或对比表格呈现，使分析报告兼备科学性、商业智慧和极佳的可读性。`;

  // 调用公共 common.js 中封装好的 inline AIPanel 机制
  if (typeof createInlineAIPanel !== 'undefined') {
    createInlineAIPanel('aiPanelMount', getContext, systemPrompt);
  }
}
