// DevHelper Background Service Worker
// 负责处理插件生命周期事件和跨页面通信

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    // 首次安装时初始化默认配置
    chrome.storage.local.set({
      theme: 'dark',
      recentTools: [],
      favoriteTools: [],
      toolSettings: {}
    });
  }
});

// 监听来自 popup 或工具页面的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'openTool') {
    // 在新标签页打开工具页面
    const toolUrl = chrome.runtime.getURL(`pages/${request.tool}.html`);
    chrome.tabs.create({ url: toolUrl });
    sendResponse({ success: true });
  }

  if (request.action === 'getActiveTabInfo') {
    // 获取当前活跃标签页信息
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        sendResponse({
          url: tabs[0].url,
          title: tabs[0].title,
          tabId: tabs[0].id
        });
      }
    });
    return true; // 保持消息通道开放
  }

  if (request.action === 'copyToClipboard') {
    // 使用 offscreen 复制到剪贴板（MV3 兼容方式）
    navigator.clipboard.writeText(request.text).then(() => {
      sendResponse({ success: true });
    }).catch(() => {
      sendResponse({ success: false });
    });
    return true;
  }

  if (request.action === 'captureVisibleTab') {
    // 先查询当前活动窗口 ID，再对该窗口截图
    // 注意：直接传 null 作为 windowId 在 Chrome MV3 某些版本会触发 DOMException
    chrome.windows.getCurrent({ populate: false }, (currentWindow) => {
      if (chrome.runtime.lastError || !currentWindow) {
        sendResponse({ error: chrome.runtime.lastError?.message || '无法获取当前窗口' });
        return;
      }
      try {
        chrome.tabs.captureVisibleTab(currentWindow.id, { format: 'png' }, (dataUrl) => {
          if (chrome.runtime.lastError) {
            sendResponse({ error: chrome.runtime.lastError.message });
          } else {
            sendResponse({ dataUrl });
          }
        });
      } catch (e) {
        // captureVisibleTab 在窗口非活跃或受保护时可能同步抛出 DOMException
        sendResponse({ error: e.message || 'captureVisibleTab 异常' });
      }
    });
    return true;
  }
});

// 记录最近使用的工具
async function recordRecentTool(toolId) {
  const result = await chrome.storage.local.get(['recentTools']);
  let recentTools = result.recentTools || [];

  // 移除重复项后插入到头部
  recentTools = recentTools.filter(id => id !== toolId);
  recentTools.unshift(toolId);

  // 最多保存 10 个
  if (recentTools.length > 10) {
    recentTools = recentTools.slice(0, 10);
  }

  await chrome.storage.local.set({ recentTools });
}
