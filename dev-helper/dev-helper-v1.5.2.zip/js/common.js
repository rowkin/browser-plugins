/**
 * DevHelper - 公共工具函数（CSP 安全版）
 * 所有工具页面共享：Toast、复制、导航栏创建、主题切换、AI 设置
 * 注意：不能使用 onclick="" 内联事件，必须使用 addEventListener
 */

// ─── 浏览器原生运行兼容环境 Mock (供本地预览/截图使用) ─────────────────
if (typeof chrome === 'undefined') {
  window.chrome = {};
}
if (!chrome.runtime) {
  chrome.runtime = {
    getURL: function(path) {
      // 兼容从 pages/ 目录跳转其他页面的相对路径
      if (path.startsWith('pages/')) {
        return path.replace('pages/', '');
      }
      return path;
    }
  };
}
if (!chrome.tabs) {
  chrome.tabs = {
    create: function(opts) {
      if (opts && opts.url) {
        window.open(opts.url, '_blank');
      }
    }
  };
}
if (!chrome.storage) {
  chrome.storage = {
    local: {
      get: function(keys, callback) {
        const res = {};
        const keyList = Array.isArray(keys) ? keys : [keys];
        keyList.forEach(k => {
          const val = localStorage.getItem('mock-chrome-storage-' + k);
          if (val !== null) {
            try {
              res[k] = JSON.parse(val);
            } catch {
              res[k] = val;
            }
          }
        });
        if (callback) {
          callback(res);
        }
        return Promise.resolve(res);
      },
      set: function(items, callback) {
        Object.keys(items).forEach(k => {
          localStorage.setItem('mock-chrome-storage-' + k, JSON.stringify(items[k]));
        });
        if (callback) {
          callback();
        }
        return Promise.resolve();
      }
    }
  };
}

/* ==================== 主题管理 ==================== */

/**
 * 初始化主题（从 localStorage 读取用户偏好）
 * 默认为 light 模式
 */
function initTheme() {
  const manual = localStorage.getItem('devhelper-theme-manual') === 'true';
  let theme = 'light';
  if (manual) {
    theme = localStorage.getItem('devhelper-theme') || 'light';
  } else {
    const hour = new Date().getHours();
    theme = (hour >= 6 && hour < 18) ? 'light' : 'dark';
    localStorage.setItem('devhelper-theme', theme);
  }
  document.documentElement.setAttribute('data-theme', theme);
  return theme;
}

/**
 * 切换 light / dark 主题
 */
function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'light';
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('devhelper-theme', next);
  localStorage.setItem('devhelper-theme-manual', 'true');

  // 同步到 chrome.storage（如果可用）
  if (typeof chrome !== 'undefined' && chrome.storage) {
    chrome.storage.local.set({ 'devhelper-theme': next, 'devhelper-theme-manual': 'true' }).catch(() => {});
  }

  // 更新所有主题图标
  document.querySelectorAll('.theme-toggle-icon').forEach(el => {
    el.textContent = next === 'dark' ? '☀️' : '🌙';
  });
}

/* ==================== Toast 通知 ==================== */

/**
 * 显示 Toast 通知
 * @param {string} message
 * @param {'success'|'error'|'info'} type
 * @param {number} duration 毫秒
 */
function showToast(message, type = 'success', duration = 2500) {
  let container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const icons = {
    success: '<svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>',
    error:   '<svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>',
    info:    '<svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/></svg>',
  };

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  // innerHTML 中无事件处理器，CSP 安全
  toast.innerHTML = `${icons[type] || icons.info}<span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('removing');
    setTimeout(() => toast.remove(), 200);
  }, duration);
}

/* ==================== 复制工具 ==================== */

/**
 * 复制文本到剪贴板
 * @param {string} text
 * @param {HTMLElement|null} btn 触发复制的按钮（可选，提供视觉反馈）
 */
async function copyText(text, btn = null) {
  try {
    await navigator.clipboard.writeText(text);
    showToast('已复制到剪贴板');
    if (btn) {
      const orig = btn.innerHTML;
      btn.innerHTML = '<svg viewBox="0 0 20 20" fill="currentColor" width="15" height="15"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>';
      btn.classList.add('copy-success');
      setTimeout(() => {
        btn.innerHTML = orig;
        btn.classList.remove('copy-success');
      }, 1800);
    }
  } catch {
    showToast('复制失败，请手动选择', 'error');
  }
}

/* ==================== 导航栏 ==================== */

const LOGO_SVG = `<svg viewBox="0 0 32 32" fill="none">
  <rect width="32" height="32" rx="8" fill="url(#ng)"/>
  <path d="M8 12L13 17L8 22M15 22H24" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
  <defs>
    <linearGradient id="ng" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#6366f1"/>
      <stop offset="100%" stop-color="#8b5cf6"/>
    </linearGradient>
  </defs>
</svg>`;

/**
 * 创建统一导航栏（CSP 安全 - 所有事件用 addEventListener）
 * @param {string} toolName 当前工具名称
 */
function createNavbar(toolName) {
  // 初始化主题（在创建导航前确保主题已设置）
  const theme = initTheme();

  const navbar = document.createElement('nav');
  navbar.className = 'navbar';

  // 不使用 onclick="" 内联事件，只用结构 HTML
  navbar.innerHTML = `
    <div class="navbar-brand" id="navHome" role="button" tabindex="0">
      <div class="navbar-logo">${LOGO_SVG}</div>
      <span class="navbar-name">DevHelper</span>
    </div>
    <div class="navbar-divider"></div>
    <span class="navbar-title">${toolName}</span>
    <div class="navbar-spacer"></div>
    <div class="navbar-actions">
      <button class="btn btn-ghost btn-sm" id="navAIAssist" title="AI 助手">
        <svg viewBox="0 0 20 20" fill="currentColor" width="15" height="15"><path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"/></svg>
        AI 助手
      </button>
      <button class="btn btn-ghost btn-sm" id="navAISettings" title="AI 设置">
        <svg viewBox="0 0 20 20" fill="currentColor" width="15" height="15"><path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/></svg>
        AI 设置
      </button>
      <button class="theme-toggle" id="navThemeToggle" title="切换主题">
        <span class="theme-toggle-icon">${theme === 'dark' ? '☀️' : '🌙'}</span>
      </button>
    </div>`;

  document.body.prepend(navbar);

  // 所有事件用 addEventListener，CSP 安全
  // 点击品牌跳转至全景工具导航页（在当前标签页中跳转，避免新开标签页）
  navbar.querySelector('#navHome').addEventListener('click', () => {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) {
      const url = chrome.runtime.getURL('pages/index.html');
      if (url && url.startsWith('chrome-extension://')) {
        window.location.href = url;
        return;
      }
    }
    // 本地开发预览环境下的相对路径跳转兼容
    window.location.href = 'index.html';
  });

  navbar.querySelector('#navAIAssist').addEventListener('click', () => {
    if (typeof chrome !== 'undefined' && chrome.runtime) {
      chrome.tabs.create({ url: chrome.runtime.getURL('pages/ai-assistant.html') });
    }
  });

  navbar.querySelector('#navAISettings').addEventListener('click', showAISettingsModal);

  navbar.querySelector('#navThemeToggle').addEventListener('click', toggleTheme);
}

/* ==================== AI 设置模态框 ==================== */

/**
 * 显示 AI 设置模态框（CSP 安全）
 */
async function showAISettingsModal() {
  // 兼容：AI 服务可能未加载
  const config = (typeof DevHelperAI !== 'undefined') ? await DevHelperAI.getAIConfig() : {};
  const builtinAvailable = (typeof DevHelperAI !== 'undefined') ? await DevHelperAI.checkBuiltinAI() : false;

  let overlay = document.getElementById('aiSettingsOverlay');
  if (overlay) { overlay.remove(); }

  overlay = document.createElement('div');
  overlay.id = 'aiSettingsOverlay';
  overlay.className = 'modal-overlay';
  overlay.style.zIndex = '10010';

  const box = document.createElement('div');
  box.className = 'modal-box';

  // 构造表单 DOM（不使用 onclick）
  const titleRow = document.createElement('div');
  titleRow.style.cssText = 'display:flex;align-items:center;justify-content:space-between;margin-bottom:20px';

  const titleEl = document.createElement('h2');
  titleEl.style.cssText = 'font-size:17px;font-weight:700;color:var(--text-primary)';
  titleEl.textContent = '⚙️ AI 设置';

  const closeBtn = document.createElement('button');
  closeBtn.style.cssText = 'border:none;background:transparent;color:var(--text-secondary);cursor:pointer;font-size:22px;line-height:1;padding:0 4px';
  closeBtn.textContent = '×';
  closeBtn.addEventListener('click', () => overlay.remove());

  titleRow.appendChild(titleEl);
  titleRow.appendChild(closeBtn);

  // Provider 选择
  const providerGroup = document.createElement('div');
  providerGroup.className = 'form-group';
  const providerLabel = document.createElement('label');
  providerLabel.className = 'form-label';
  providerLabel.textContent = 'AI 服务商';
  const providerSelect = document.createElement('select');
  providerSelect.id = 'aiProvider';
  providerSelect.className = 'form-input form-select';

  const optBuiltin = document.createElement('option');
  optBuiltin.value = 'builtin';
  optBuiltin.textContent = `Chrome 内置 AI${builtinAvailable ? '' : '（不可用）'}`;
  optBuiltin.disabled = !builtinAvailable;
  if (config.provider === 'builtin') optBuiltin.selected = true;

  const optOpenAI = document.createElement('option');
  optOpenAI.value = 'openai';
  optOpenAI.textContent = '自定义（OpenAI 兼容）';
  if (config.provider !== 'builtin') optOpenAI.selected = true;

  providerSelect.appendChild(optBuiltin);
  providerSelect.appendChild(optOpenAI);
  providerGroup.appendChild(providerLabel);
  providerGroup.appendChild(providerSelect);

  // OpenAI 字段组
  const openaiFields = document.createElement('div');
  openaiFields.id = 'openaiFields';
  openaiFields.style.display = (config.provider === 'builtin') ? 'none' : '';

  const createField = (id, label, type, placeholder, value = '') => {
    const group = document.createElement('div');
    group.className = 'form-group';
    const lbl = document.createElement('label');
    lbl.className = 'form-label';
    lbl.textContent = label;
    const input = document.createElement('input');
    input.id = id;
    input.type = type;
    input.className = 'form-input';
    input.placeholder = placeholder;
    input.value = value;
    group.appendChild(lbl);
    group.appendChild(input);
    return group;
  };

  openaiFields.appendChild(createField('aiApiKey', 'API Key', 'password', '请输入 API Key', config.apiKey || ''));
  openaiFields.appendChild(createField('aiApiUrl', 'API URL', 'text', 'https://api.openai.com/v1/chat/completions', config.apiUrl || ''));
  openaiFields.appendChild(createField('aiModel', '模型名称', 'text', 'gpt-4o-mini', config.model || ''));

  const hint = document.createElement('p');
  hint.style.cssText = 'font-size:12px;color:var(--text-tertiary);margin-bottom:16px';
  hint.textContent = '支持任何 OpenAI Chat Completions 兼容 API（SiliconFlow、Azure 等）';
  openaiFields.appendChild(hint);

  // Provider 切换联动
  providerSelect.addEventListener('change', (e) => {
    openaiFields.style.display = e.target.value === 'builtin' ? 'none' : '';
  });

  // 保存按钮
  const saveBtn = document.createElement('button');
  saveBtn.className = 'btn btn-primary';
  saveBtn.style.width = '100%';
  saveBtn.textContent = '保存设置';
  saveBtn.addEventListener('click', async () => {
    const provider = providerSelect.value;
    if (typeof DevHelperAI !== 'undefined') {
      await DevHelperAI.saveAIConfig({
        provider,
        apiKey:  box.querySelector('#aiApiKey')?.value || '',
        apiUrl:  box.querySelector('#aiApiUrl')?.value || 'https://api.openai.com/v1/chat/completions',
        model:   box.querySelector('#aiModel')?.value || 'gpt-4o-mini',
      });
    }
    showToast('AI 设置已保存');
    overlay.remove();
  });

  box.appendChild(titleRow);
  box.appendChild(providerGroup);
  box.appendChild(openaiFields);
  box.appendChild(saveBtn);

  overlay.appendChild(box);
  document.body.appendChild(overlay);

  // 点击遮罩关闭
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
}

/* ==================== AI 解读面板 ==================== */

/**
 * 在工具页面底部创建悬浮抽屉式 AI 解读面板（CSP 安全，自适应所有页面）
 * @param {string} containerId 原挂载容器 ID（此时我们会隐藏此容器，改用全局 Body 悬浮抽屉）
 * @param {function} getContext 获取当前内容的函数
 * @param {string} systemPrompt 工具专属系统提示
 */
function createInlineAIPanel(containerId, getContext, systemPrompt) {
  // 1. 如果页面原本声明了容器，将其彻底隐藏，以释放页面纵向空间
  const origContainer = document.getElementById(containerId);
  if (origContainer) {
    origContainer.style.display = 'none';
  }

  // 2. 注入抽屉与悬浮球所需的专属 CSS 样式（如果还没注入的话）
  const styleId = 'ai-drawer-custom-styles';
  if (!document.getElementById(styleId)) {
    const styleEl = document.createElement('style');
    styleEl.id = styleId;
    styleEl.textContent = `
      /* 悬浮球 Trigger */
      .ai-floating-trigger {
        position: fixed;
        bottom: 24px;
        right: 24px;
        width: 48px;
        height: 48px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary, #6366f1), var(--accent, #8b5cf6));
        color: #ffffff;
        box-shadow: 0 4px 16px rgba(99, 102, 241, 0.35);
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        z-index: 9999;
        transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275), box-shadow 0.3s;
        border: none;
        outline: none;
      }
      .ai-floating-trigger:hover {
        transform: scale(1.1);
        box-shadow: 0 6px 20px rgba(99, 102, 241, 0.5);
      }
      .ai-floating-trigger:active {
        transform: scale(0.95);
      }
      .ai-floating-trigger svg {
        width: 22px;
        height: 22px;
        animation: ai-pulse 2s infinite alternate;
      }
      @keyframes ai-pulse {
        0% { transform: scale(1); }
        100% { transform: scale(1.15); filter: drop-shadow(0 0 4px rgba(255, 255, 255, 0.6)); }
      }

      /* 气泡提示 */
      .ai-floating-tooltip {
        position: absolute;
        right: 60px;
        background: var(--bg-surface, #ffffff);
        border: 1px solid var(--border-light, #eef0f6);
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        border-radius: 6px;
        padding: 6px 10px;
        font-size: 11px;
        font-weight: 700;
        color: var(--text-primary, #1e293b);
        white-space: nowrap;
        opacity: 0;
        pointer-events: none;
        transform: translateX(10px);
        transition: opacity 0.2s, transform 0.2s;
      }
      .ai-floating-trigger:hover .ai-floating-tooltip {
        opacity: 1;
        transform: translateX(0);
      }

      /* 遮罩背景 */
      .ai-drawer-overlay {
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.3);
        backdrop-filter: blur(2px);
        z-index: 10000;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.3s ease;
      }
      .ai-drawer-overlay.open {
        opacity: 1;
        pointer-events: auto;
      }

      /* 抽屉侧边栏 */
      .ai-drawer-container {
        position: fixed;
        top: 0;
        right: 0;
        width: 420px;
        max-width: 85vw;
        height: 100vh;
        background: var(--bg-surface, #ffffff);
        border-left: 1px solid var(--border-light, #eef0f6);
        box-shadow: -6px 0 30px rgba(0, 0, 0, 0.1);
        z-index: 10001;
        display: flex;
        flex-direction: column;
        transform: translateX(100%);
        transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-sizing: border-box;
      }
      .ai-drawer-container.open {
        transform: translateX(0);
      }

      /* 抽屉头部 */
      .ai-drawer-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 16px 20px;
        border-bottom: 1px solid var(--border-light, #eef0f6);
        background: var(--bg-elevated, #f8fafc);
      }
      .ai-drawer-title {
        font-size: 15px;
        font-weight: 800;
        color: var(--primary, #6366f1);
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .ai-drawer-actions {
        display: flex;
        align-items: center;
        gap: 6px;
      }

      /* 抽屉控制面板 */
      .ai-drawer-control {
        padding: 12px 20px;
        background: var(--bg-elevated, #f8fafc);
        border-bottom: 1px solid var(--border-light, #eef0f6);
        display: flex;
        align-items: center;
        justify-content: space-between;
      }

      /* 抽屉内容区 */
      .ai-drawer-body {
        flex: 1;
        padding: 20px;
        overflow-y: auto;
        font-size: 13px;
        line-height: 1.6;
        color: var(--text-secondary, #475569);
      }

      /* 骨架屏闪烁动画 */
      @keyframes ai-skeleton-loading {
        0% { background-position: 150% 50%; }
        100% { background-position: -50% 50%; }
      }
      .ai-skeleton-line {
        height: 14px;
        margin-bottom: 12px;
        border-radius: 4px;
        background: linear-gradient(90deg, var(--bg-elevated, #f1f5f9) 25%, var(--border-light, #e2e8f0) 37%, var(--bg-elevated, #f1f5f9) 63%);
        background-size: 400% 100%;
        animation: ai-skeleton-loading 1.4s ease infinite;
      }
    `;
    document.head.appendChild(styleEl);
  }

  // 3. 构建悬浮 Trigger 按钮
  const triggerBtn = document.createElement('button');
  triggerBtn.className = 'ai-floating-trigger';
  triggerBtn.innerHTML = `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>
      <path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z" fill="currentColor" fill-opacity="0.2"/>
    </svg>
    <div class="ai-floating-tooltip">✨ AI 智能解读</div>
  `;

  // 4. 构建 Overlay 与 Drawer 主体
  const overlay = document.createElement('div');
  overlay.className = 'ai-drawer-overlay';

  const drawer = document.createElement('div');
  drawer.className = 'ai-drawer-container';

  // 4.1 头部
  const header = document.createElement('div');
  header.className = 'ai-drawer-header';
  
  const title = document.createElement('div');
  title.className = 'ai-drawer-title';
  title.innerHTML = `🪄 <span>AI 智能分析解读</span>`;
  
  const actions = document.createElement('div');
  actions.className = 'ai-drawer-actions';
  
  // 齿轮配置 AI
  const configBtn = document.createElement('button');
  configBtn.className = 'btn btn-sm btn-ghost btn-icon';
  configBtn.style.padding = '4px 6px';
  configBtn.title = '配置 AI 服务';
  configBtn.innerHTML = '⚙️';
  configBtn.addEventListener('click', showAISettingsModal);
  
  // 关闭按钮
  const closeBtn = document.createElement('button');
  closeBtn.className = 'btn btn-sm btn-ghost';
  closeBtn.style.fontSize = '16px';
  closeBtn.style.padding = '2px 8px';
  closeBtn.textContent = '×';
  
  actions.appendChild(configBtn);
  actions.appendChild(closeBtn);
  header.appendChild(title);
  header.appendChild(actions);

  // 4.2 控制条
  const control = document.createElement('div');
  control.className = 'ai-drawer-control';
  
  const statusSpan = document.createElement('span');
  statusSpan.style.cssText = 'font-size: 11px; color: var(--text-tertiary);';
  statusSpan.textContent = '等待分析触发...';
  
  const runBtn = document.createElement('button');
  runBtn.className = 'btn btn-sm btn-primary';
  runBtn.style.cssText = 'font-size:11px; padding: 4px 12px;';
  runBtn.textContent = '开始分析';
  
  control.appendChild(statusSpan);
  control.appendChild(runBtn);

  // 4.3 内容展示区
  const body = document.createElement('div');
  body.className = 'ai-drawer-body';
  body.innerHTML = `<div style="text-align: center; padding: 40px 10px; color: var(--text-tertiary);">
    <div style="font-size: 32px; margin-bottom: 12px;">💡</div>
    点击右侧的<b>「开始分析」</b>按钮，AI 将根据本页面的网络指标/代码输出为您生成专业的解读和优化建议。
  </div>`;

  drawer.appendChild(header);
  drawer.appendChild(control);
  drawer.appendChild(body);

  // 5. 组装并挂载到 Body 确保全层级置顶
  document.body.appendChild(triggerBtn);
  document.body.appendChild(overlay);
  document.body.appendChild(drawer);

  // 6. 交互联动事件绑定
  function openDrawer() {
    overlay.classList.add('open');
    drawer.classList.add('open');
  }

  function closeDrawer() {
    overlay.classList.remove('open');
    drawer.classList.remove('open');
  }

  triggerBtn.addEventListener('click', openDrawer);
  overlay.addEventListener('click', closeDrawer);
  closeBtn.addEventListener('click', closeDrawer);

  // 7. AI 分析请求逻辑
  runBtn.addEventListener('click', async () => {
    const context = getContext();
    if (!context?.trim()) {
      showToast('获取不到当前需要分析的上下文数据，请确认本页数据已渲染', 'info');
      return;
    }

    // 优雅流光骨架屏（Shimmer Skeleton）
    body.innerHTML = `
      <div style="padding: 10px 0;">
        <div style="display:flex; align-items:center; gap: 10px; margin-bottom: 24px;">
          <div class="loading-spinner" style="margin: 0; width: 16px; height: 16px; border-width: 2px;"></div>
          <span style="font-size: 13px; font-weight: 700; color: var(--primary);">AI 正在诊断并生成分析报告...</span>
        </div>
        <div class="ai-skeleton-line" style="width: 85%;"></div>
        <div class="ai-skeleton-line" style="width: 95%;"></div>
        <div class="ai-skeleton-line" style="width: 70%;"></div>
        <div class="ai-skeleton-line" style="width: 80%;"></div>
      </div>
    `;
    
    runBtn.disabled = true;
    runBtn.textContent = '分析中...';
    statusSpan.textContent = 'AI 正在分析中...';

    try {
      if (typeof DevHelperAI === 'undefined') {
        throw new Error('AI 基础服务未加载，请刷新页面重试');
      }
      let lastChunk = '';
      const result = await DevHelperAI.callAI(systemPrompt, context, (chunk) => {
        // 首字防抖保护：有意义的流式字符返回时再替换掉骨架屏，解决多秒留白问题
        if (!chunk?.trim()) return;
        lastChunk = chunk;
        body.innerHTML = renderInlineMarkdown(chunk);
      });
      // 诊断完成后，使用完整返回的 result 或最后的 chunk 做一次终极渲染覆盖，确保内容 100% 完整
      const finalReport = result || lastChunk;
      if (finalReport) {
        body.innerHTML = renderInlineMarkdown(finalReport);
      }
      statusSpan.textContent = '诊断分析完成';
    } catch (err) {
      body.innerHTML = `
        <div style="padding: 16px; background: rgba(239, 68, 68, 0.05); border: 1px dashed var(--danger); border-radius: 6px; color: var(--danger); margin-top: 10px;">
          <strong>AI 分析出错：</strong><br>
          <span style="font-size: 12px;">${err.message}</span>
        </div>
      `;
      // 插入 AI 设定按钮
      const setBtn = document.createElement('button');
      setBtn.className = 'btn btn-sm btn-ghost';
      setBtn.style.marginTop = '12px';
      setBtn.textContent = '⚙️ 去配置 AI API 设置';
      setBtn.addEventListener('click', showAISettingsModal);
      body.appendChild(setBtn);
      
      statusSpan.textContent = '分析异常中断';
    } finally {
      runBtn.disabled = false;
      runBtn.textContent = '重新分析';
    }
  });
}

/* ==================== 轻量 Markdown 渲染（AI 解读面板专用）==================== */

/**
 * 将 Markdown 文本转换为安全 HTML（不依赖任何第三方库）
 * 支持：代码块、内联代码、粗/斜体、标题、有序/无序列表、分隔线、换行
 */
function renderInlineMarkdown(text) {
  if (!text) return '';

  // XSS 防御：转义原始 HTML 字符
  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  // 设计理念：
  // 1. 占位符机制：由于代码块和内联代码中可能存在大量的 Markdown 敏感字符（如表格分割线 `|`、列表 `-` 等），
  //    为了避免这些内容在后续的 Block/Inline 解析中被误杀破坏，我们在最开始将它们提取到数组中，并以占位符占位，在最后阶段再进行还原。
  
  // 提取代码块为占位符
  const codeBlocks = [];
  let r = text.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) => {
    const id = `__CODE_BLOCK_${codeBlocks.length}__`;
    codeBlocks.push(`<pre style="background:var(--bg-elevated);border:1px solid var(--border-light);border-radius:6px;padding:10px 12px;font-family:var(--mono-font,monospace);font-size:12px;overflow-x:auto;margin:8px 0;white-space:pre-wrap"><code>${esc(code.trim())}</code></pre>`);
    return id;
  });

  // 提取行内代码为占位符
  const inlineCodes = [];
  r = r.replace(/`([^\n`]+)`/g, (_, code) => {
    const id = `__INLINE_CODE_${inlineCodes.length}__`;
    inlineCodes.push(`<code style="background:var(--bg-elevated);padding:1px 5px;border-radius:3px;font-family:var(--mono-font,monospace);font-size:12px">${esc(code)}</code>`);
    return id;
  });

  // 2. 表格流式解析：由于 AI 返回是流式的，表格可能处于不完整状态。
  //    在此我们使用逐行扫描，如果遇到表头和分隔符行则开启表格状态，当遇到非表格行或文本结束时自动闭合表格。
  function buildTableHtml(header, alignments, rows) {
    let tableHtml = '<div style="overflow-x:auto;margin:12px 0;"><table style="width:100%;border-collapse:collapse;font-size:13px;border:1px solid var(--border-light)">';
    tableHtml += '<thead><tr style="background:var(--bg-elevated);border-bottom:2px solid var(--border-light)">';
    header.forEach((h, idx) => {
      const align = alignments[idx] ? ` align="${alignments[idx]}"` : '';
      const alignStyle = alignments[idx] ? `text-align:${alignments[idx]};` : '';
      tableHtml += `<th${align} style="${alignStyle}padding:8px 10px;font-weight:600;border:1px solid var(--border-light)">${h}</th>`;
    });
    tableHtml += '</tr></thead><tbody>';
    rows.forEach((row, rowIdx) => {
      const bg = rowIdx % 2 === 0 ? '' : 'background:var(--bg-elevated);';
      tableHtml += `<tr style="${bg}border-bottom:1px solid var(--border-light)">`;
      for (let idx = 0; idx < header.length; idx++) {
        const cellVal = row[idx] || '';
        const align = alignments[idx] ? ` align="${alignments[idx]}"` : '';
        const alignStyle = alignments[idx] ? `text-align:${alignments[idx]};` : '';
        tableHtml += `<td${align} style="${alignStyle}padding:8px 10px;border:1px solid var(--border-light)">${cellVal}</td>`;
      }
      tableHtml += '</tr>';
    });
    tableHtml += '</tbody></table></div>';
    return tableHtml;
  }

  const lines = r.split('\n');
  const processedLines = [];
  let inTable = false;
  let tableHeader = null;
  let tableAlignments = [];
  let tableRows = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    // 表格行判定：必须以 | 开头和结尾，且内部至少有一个有效分隔符
    const isTableRow = line.startsWith('|') && line.endsWith('|') && line.split('|').length > 2;

    if (isTableRow) {
      const cells = line.split('|').map(s => s.trim()).slice(1, -1);

      if (!inTable) {
        // 向前看一行，如果是类似 `| --- | :---: |` 的分割线，则确认当前行为表头
        const nextLine = (lines[i + 1] || '').trim();
        const isDelimiterRow = nextLine.startsWith('|') && nextLine.endsWith('|') && 
                               nextLine.replace(/[\s|:\-]/g, '') === '';
        
        if (isDelimiterRow) {
          inTable = true;
          tableHeader = cells;
          
          // 解析对齐方式
          const delimCells = nextLine.split('|').map(s => s.trim()).slice(1, -1);
          tableAlignments = delimCells.map(cell => {
            if (cell.startsWith(':') && cell.endsWith(':')) return 'center';
            if (cell.endsWith(':')) return 'right';
            if (cell.startsWith(':')) return 'left';
            return '';
          });
          tableRows = [];
          i++; // 跳过已解析的分隔符行
          continue;
        }
      } else {
        tableRows.push(cells);
        continue;
      }
    }

    // 边界条件：处于表格态但当前行不再是表格行，此时闭合表格
    if (inTable && !isTableRow) {
      processedLines.push(buildTableHtml(tableHeader, tableAlignments, tableRows));
      inTable = false;
      tableHeader = null;
      tableAlignments = [];
      tableRows = [];
    }

    processedLines.push(lines[i]);
  }

  // 循环结束后，若仍处于表格中，强制闭合渲染
  if (inTable) {
    processedLines.push(buildTableHtml(tableHeader, tableAlignments, tableRows));
  }

  r = processedLines.join('\n');

  // 3. 标题
  r = r
    .replace(/^### (.+)$/gm, '<h3 style="font-size:13px;font-weight:700;margin:10px 0 4px;color:var(--text-primary)">$1</h3>')
    .replace(/^## (.+)$/gm,  '<h2 style="font-size:14px;font-weight:700;margin:12px 0 6px;color:var(--primary)">$1</h2>')
    .replace(/^# (.+)$/gm,   '<h1 style="font-size:16px;font-weight:800;margin:14px 0 8px;color:var(--primary)">$1</h1>');

  // 4. 有序列表（连续行）
  r = r.replace(/((?:^\d+\. .+\n?)+)/gm, (block) => {
    const items = block.trim().split('\n').map(l => `<li style="margin:3px 0">${l.replace(/^\d+\.\s*/, '')}</li>`).join('\n');
    return `<ol style="padding-left:20px;margin:6px 0">\n${items}\n</ol>\n`;
  });

  // 5. 无序列表（连续行）
  r = r.replace(/((?:^[-*] .+\n?)+)/gm, (block) => {
    const items = block.trim().split('\n').map(l => `<li style="margin:3px 0">${l.replace(/^[-*]\s*/, '')}</li>`).join('\n');
    return `<ul style="padding-left:20px;margin:6px 0">\n${items}\n</ul>\n`;
  });

  // 6. 还原内联代码占位符与粗/斜体等标记（此时内联内容仍需要享受加粗斜体转换）
  r = r
    .replace(/\*\*\*([^\n]+?)\*\*\*/g, '<strong><em>$1</em></strong>')
    .replace(/\*\*([^\n]+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*([^\n]+?)\*/g,  '<em>$1</em>')
    .replace(/~~([^\n]+?)~~/g,  '<del>$1</del>');

  // 7. 分隔线
  r = r.replace(/^---$/gm, '<hr style="border:none;border-top:1px solid var(--border-light);margin:12px 0">');

  // 8. 恢复代码块及内联代码的占位符（保证其中的标签以 esc 转义后的形式原样输出）
  for (let idx = 0; idx < inlineCodes.length; idx++) {
    r = r.replaceAll(`__INLINE_CODE_${idx}__`, inlineCodes[idx]);
  }
  for (let idx = 0; idx < codeBlocks.length; idx++) {
    r = r.replaceAll(`__CODE_BLOCK_${idx}__`, codeBlocks[idx]);
  }

  // 9. 换行（非 HTML 标签前）
  r = r.replace(/\n(?!<)/g, '<br>');

  return r;
}

/* ==================== 全局暴露 ==================== */
window.showToast = showToast;
window.copyText = copyText;
window.createNavbar = createNavbar;
window.createInlineAIPanel = createInlineAIPanel;
window.showAISettingsModal = showAISettingsModal;
window.toggleTheme = toggleTheme;
window.initTheme = initTheme;
window.renderInlineMarkdown = renderInlineMarkdown;

/* ==================== 全局一键清空输入框交互 ==================== */

/**
 * 全局初始化一键清空输入框交互
 * 扫描页面所有非只读、非禁用的文本输入框和文本域，动态注入悬浮的“×”清空按钮
 */
function initGlobalClearButtons() {
  // 选取所有文本域及主要类型的文本输入框，并过滤出没有 type 属性的默认文本框
  const inputs = document.querySelectorAll(
    'textarea, input[type="text"], input[type="search"], input[type="url"], input[type="password"], input:not([type])'
  );
  
  inputs.forEach(el => {
    // 边界条件：只读、禁用、隐藏或声明了 no-clear 排除类的不做处理
    if (el.readOnly || el.disabled || el.type === 'hidden') return;
    if (el.classList.contains('no-clear')) return;
    
    // 边界条件：检查是否已经包裹过，防止在页面动态渲染时重复执行
    if (el.dataset.hasClear === 'true') return;
    const parent = el.parentElement;
    if (!parent) return;
    
    // 创建一键清空的外部 Wrapper 容器以保证清空按钮绝对在输入框内部定位
    const wrapper = document.createElement('div');
    wrapper.className = 'input-clear-wrapper';
    
    // 获取输入框的计算样式以复制关键布局属性，防止包裹后原本的弹性布局（Flex）失效
    const elStyle = window.getComputedStyle(el);
    
    // 1. 若输入框原本是 flex 的子项，使 wrapper 承接同样的 flex 特性以防容器尺寸塌陷
    if (elStyle.flex && elStyle.flex !== '0 1 auto' && elStyle.flex !== 'none') {
      wrapper.style.flex = elStyle.flex;
    } else {
      // 分别复制 flex-grow/shrink 属性，增强在复杂布局下的适配效果
      if (elStyle.flexGrow && elStyle.flexGrow !== '0') {
        wrapper.style.flexGrow = elStyle.flexGrow;
      }
      if (elStyle.flexShrink && elStyle.flexShrink !== '1') {
        wrapper.style.flexShrink = elStyle.flexShrink;
      }
    }
    
    // 2. 复制宽度、高度、外边距，并将 display 模式设为 input 的外显流布局样式
    wrapper.style.width = elStyle.width;
    wrapper.style.height = elStyle.height;
    wrapper.style.margin = elStyle.margin;
    wrapper.style.display = elStyle.display === 'block' ? 'block' : 'inline-block';
    
    // 3. 将输入框设为宽度 100% 且外边距清零，同时设为 block 消除行内元素基线留白导致的高度误差
    el.style.width = '100%';
    el.style.margin = '0';
    el.style.display = 'block';
    
    // 创建“×”悬浮清空按钮
    const clearBtn = document.createElement('span');
    clearBtn.className = 'input-clear-btn';
    clearBtn.innerHTML = '×';
    clearBtn.title = '清空内容';
    
    // 根据是 textarea 还是普通 input 决定应用的悬浮布局类
    const isTextarea = el.tagName.toLowerCase() === 'textarea';
    clearBtn.classList.add(isTextarea ? 'is-textarea' : 'is-input');
    
    // 避让机制：若为多行文本框稍微偏左以避开拉伸手柄；若为单行的 datetime-local 避开内置图标
    let rightOffset = 12;
    if (isTextarea) {
      rightOffset = 18; // 避开 textarea 右下角的拉伸手柄
    } else if (el.type === 'datetime-local') {
      rightOffset = 30; // 避开单行内置的调整/日历按钮
    } else {
      // 检查原父容器中是否含有浮动在右侧的功能按钮（例如“复制”按钮等）
      const hasSiblingBtn = parent.querySelector('.base-copy-btn') || 
                            parent.querySelector('.copy-btn') || 
                            parent.querySelector('button.btn') ||
                            parent.querySelector('.btn-icon') ||
                            el.classList.contains('base-input'); // 针对特殊的 base-input 类名做兜底判定
      if (hasSiblingBtn) {
        rightOffset = 48; // 偏移 48px 避开右侧复制/功能按钮位置
      }
    }
    clearBtn.style.right = rightOffset + 'px';
    
    // 智能防遮挡：动态检查并增大输入框的右内边距，确保长文本不会被清空按钮遮挡
    const currentPaddingRight = parseFloat(elStyle.paddingRight) || 0;
    const neededPadding = rightOffset + 18;
    if (currentPaddingRight < neededPadding) {
      el.style.paddingRight = neededPadding + 'px';
    }
    
    // 执行 DOM 包裹挂载操作，将 wrapper 插入原本 el 的位置，并把 el 和 clearBtn 装入 wrapper
    parent.insertBefore(wrapper, el);
    wrapper.appendChild(el);
    wrapper.appendChild(clearBtn);
    
    // 标记为已处理
    el.dataset.hasClear = 'true';
    
    // 控制清空按钮“有内容”状态的逻辑（配合 CSS :hover/:focus-within 实现智能显隐）
    const toggleBtn = () => {
      if (el.value.length > 0) {
        clearBtn.classList.add('has-value');
      } else {
        clearBtn.classList.remove('has-value');
      }
    };
    
    // 监听输入和变更事件以实时展示/隐藏清空按钮
    el.addEventListener('input', toggleBtn);
    el.addEventListener('change', toggleBtn);
    
    // 绑定清空事件
    clearBtn.addEventListener('click', (e) => {
      e.stopPropagation(); // 阻止事件冒泡
      el.value = '';       // 清空输入框内容
      toggleBtn();
      el.focus();          // 重新聚焦输入框
      
      // 关键逻辑：手动触发原生的 input 与 change 事件，以激活该输入框在对应页面上绑定的关联交互（如实时计算、转换）
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    });
    
    // 初始化时执行一次，以便在页面带入初始默认值时显示清空按钮
    toggleBtn();
  });
}

window.initGlobalClearButtons = initGlobalClearButtons;
window.renderInlineMarkdown = renderInlineMarkdown;

// 页面 DOM 加载完成后自动触发初始化
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initGlobalClearButtons);
} else {
  initGlobalClearButtons();
}


