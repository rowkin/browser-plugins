(function() {
  if (window.DevHelperScreenshotHelperInitialized) {
    return;
  }
  window.DevHelperScreenshotHelperInitialized = true;

  let overlay = null;
  let canvas = null;
  let ctx = null;
  let isDrawing = false;
  let startX = 0;
  let startY = 0;
  let currentX = 0;
  let currentY = 0;

  // 原始状态记录与滚动目标（长截图用）
  let originalScrollX = 0;
  let originalScrollY = 0;
  let scrollTarget = null; // 当前识别到的真正负责滚动的容器（null 表示降级使用 window）
  let originalScrollTargetStyle = null; // 记录原滚动容器的样式以备还原
  let hiddenElements = []; // 临时隐藏的 fixed/sticky 元素列表

  // 监听来自扩展程序的消息
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'startAreaSelect') {
      startAreaSelection(sendResponse);
      return true; // 保持通道开放，用于异步响应选区
    }

    if (request.action === 'extractDOMText') {
      const type = request.type || 'visible';
      let text = '';
      if (type === 'visible') {
        text = getTextsInRect({
          x: 0,
          y: 0,
          width: window.innerWidth,
          height: window.innerHeight
        });
      } else {
        text = document.body.innerText || '';
      }
      sendResponse({ status: 'success', text });
      return false;
    }

    if (request.action === 'prepareScroll') {
      scrollTarget = findScrollContainer();
      const isWindow = !scrollTarget;

      // 1. 记录初始滚动位置
      originalScrollX = isWindow ? (window.scrollX || window.pageXOffset) : scrollTarget.scrollLeft;
      originalScrollY = isWindow ? (window.scrollY || window.pageYOffset) : scrollTarget.scrollTop;

      // 2. 注入 CSS 强制隐藏滚动条并关闭平滑滚动，防止滚动延迟导致截图内容重复
      let styleTag = document.getElementById('devhelper-screenshot-style');
      if (!styleTag) {
        styleTag = document.createElement('style');
        styleTag.id = 'devhelper-screenshot-style';
        styleTag.innerHTML = `
          html, body {
            scroll-behavior: auto !important;
          }
          ::-webkit-scrollbar {
            display: none !important;
            width: 0 !important;
            height: 0 !important;
          }
        `;
        document.documentElement.appendChild(styleTag);
      }

      // 如果有具体的滚动容器，也要对它强制去除平滑滚动
      if (!isWindow) {
        originalScrollTargetStyle = {
          scrollBehavior: scrollTarget.style.scrollBehavior || ''
        };
        scrollTarget.style.scrollBehavior = 'auto';
      }

      // 3. 扫描并临时隐藏所有 position 为 fixed 或 sticky 的浮动元素，防止它们在每一帧拼接时重复出现
      hiddenElements = [];
      const allElements = document.getElementsByTagName('*');
      for (let i = 0; i < allElements.length; i++) {
        const el = allElements[i];
        
        // 排除滚动容器本身及其父容器，防止隐藏了主滚动框里的内容
        if (!isWindow && (el === scrollTarget || el.contains(scrollTarget))) {
          continue;
        }

        try {
          const displayStyle = window.getComputedStyle(el);
          const position = displayStyle.position;
          if ((position === 'fixed' || position === 'sticky') && displayStyle.visibility !== 'hidden' && displayStyle.display !== 'none') {
            hiddenElements.push({
              element: el,
              originalVisibility: el.style.visibility
            });
            el.style.visibility = 'hidden';
          }
        } catch (e) {
          // 忽略无权限或已销毁的 DOM 节点
        }
      }

      // 4. 获取准确的页面物理尺寸
      const totalWidth = isWindow ? Math.max(
        document.documentElement.scrollWidth,
        document.body.scrollWidth,
        document.documentElement.clientWidth
      ) : scrollTarget.scrollWidth;

      const totalHeight = isWindow ? Math.max(
        document.documentElement.scrollHeight,
        document.body.scrollHeight,
        document.documentElement.clientHeight
      ) : scrollTarget.scrollHeight;

      const viewportWidth = isWindow ? window.innerWidth : scrollTarget.clientWidth;
      const viewportHeight = isWindow ? window.innerHeight : scrollTarget.clientHeight;

      let containerRect = null;
      if (!isWindow) {
        const rect = scrollTarget.getBoundingClientRect();
        containerRect = {
          left: rect.left,
          top: rect.top,
          width: rect.width,
          height: rect.height
        };
      }

      sendResponse({
        totalWidth,
        totalHeight,
        viewportWidth,
        viewportHeight,
        dpr: window.devicePixelRatio || 1,
        containerRect
      });
    }

    if (request.action === 'scrollTo') {
      const isWindow = !scrollTarget;
      if (isWindow) {
        window.scrollTo(0, request.y);
      } else {
        scrollTarget.scrollTop = request.y;
      }
      
      // 等待滚动完成：先等 500ms 让浏览器有足够时间完成惯性滚动和懒加载触发，
      // 再通过 RAF 确保至少一帧渲染完成后再回调，保证截图内容已被绘制到屏幕上
      setTimeout(() => {
        requestAnimationFrame(() => {
          const actualY = isWindow ? (window.scrollY || window.pageYOffset) : scrollTarget.scrollTop;
          const currentTotalHeight = isWindow ? Math.max(
            document.documentElement.scrollHeight,
            document.body.scrollHeight,
            document.documentElement.clientHeight
          ) : scrollTarget.scrollHeight;

          const viewportH = isWindow ? window.innerHeight : scrollTarget.clientHeight;
          // 精确计算是否已到达底部（允许 2px 误差，应对亚像素和 DPR 导致的细微偏差）
          const isBottom = (actualY + viewportH) >= (currentTotalHeight - 2);

          sendResponse({
            success: true,
            actualY,
            currentTotalHeight,
            isBottom
          });
        });
      }, 500);
      return true;
    }

    if (request.action === 'restoreScroll') {
      // 1. 恢复临时隐藏的 fixed/sticky 元素
      hiddenElements.forEach(item => {
        if (item.element) {
          item.element.style.visibility = item.originalVisibility;
        }
      });
      hiddenElements = [];

      // 2. 移除注入的隐藏滚动条 style 标签并恢复滚动容器样式
      const styleTag = document.getElementById('devhelper-screenshot-style');
      if (styleTag) styleTag.remove();

      const isWindow = !scrollTarget;
      if (!isWindow && originalScrollTargetStyle) {
        scrollTarget.style.scrollBehavior = originalScrollTargetStyle.scrollBehavior;
        originalScrollTargetStyle = null;
      }

      // 3. 恢复原始滚动位置
      if (isWindow) {
        window.scrollTo(originalScrollX, originalScrollY);
      } else {
        scrollTarget.scrollTop = originalScrollY;
        scrollTarget.scrollLeft = originalScrollX;
      }
      
      scrollTarget = null;
      sendResponse({ success: true });
    }
  });

  // 开始区域选择模式
  function startAreaSelection(onCompleteCallback) {
    if (overlay) return;

    // 创建全屏蒙版
    overlay = document.createElement('div');
    overlay.id = 'devhelper-screenshot-overlay';
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      z-index: 999999999;
      background: rgba(0, 0, 0, 0.4);
      cursor: crosshair;
      user-select: none;
      -webkit-user-select: none;
    `;

    canvas = document.createElement('canvas');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    canvas.style.cssText = 'position: absolute; top: 0; left: 0; pointer-events: none;';
    ctx = canvas.getContext('2d');
    overlay.appendChild(canvas);
    document.body.appendChild(overlay);

    // 绘制全黑透明层
    drawOverlay();

    // 绑定鼠标事件
    overlay.addEventListener('mousedown', onMouseDown);
    overlay.addEventListener('mousemove', onMouseMove);
    overlay.addEventListener('mouseup', onMouseUp);
    
    // 监听 ESC 取消
    window.addEventListener('keydown', onKeyDown);

    function onMouseDown(e) {
      if (e.button !== 0) return; // 只响应左键
      isDrawing = true;
      startX = e.clientX;
      startY = e.clientY;
      currentX = startX;
      currentY = startY;
    }

    function onMouseMove(e) {
      if (!isDrawing) return;
      currentX = e.clientX;
      currentY = e.clientY;
      drawSelection();
    }

    function onMouseUp(e) {
      if (!isDrawing) return;
      isDrawing = false;
      
      const x = Math.min(startX, currentX);
      const y = Math.min(startY, currentY);
      const width = Math.abs(startX - currentX);
      const height = Math.abs(startY - currentY);

      // DOM 区域文本智能提取（逆向提取，100% 准确）
      let extractedText = '';
      if (width > 3 && height > 3) {
        extractedText = getTextsInRect({ x, y, width, height });
      }

      cleanup();

      // 仅当截取区域面积大于 10 像素时才进行截图，否则忽略（当做误触）
      if (width > 3 && height > 3) {
        onCompleteCallback({
          status: 'success',
          rect: {
            x,
            y,
            width,
            height,
            dpr: window.devicePixelRatio || 1,
            extractedText
          }
        });
      } else {
        onCompleteCallback({ status: 'cancel' });
      }
    }

    function onKeyDown(e) {
      if (e.key === 'Escape') {
        cleanup();
        onCompleteCallback({ status: 'cancel' });
      }
    }

    function cleanup() {
      window.removeEventListener('keydown', onKeyDown);
      if (overlay) {
        overlay.removeEventListener('mousedown', onMouseDown);
        overlay.removeEventListener('mousemove', onMouseMove);
        overlay.removeEventListener('mouseup', onMouseUp);
        overlay.remove();
        overlay = null;
        canvas = null;
        ctx = null;
      }
    }
  }

  // 绘制蒙版及指示说明
  function drawOverlay() {
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // 绘制使用说明
    ctx.fillStyle = '#ffffff';
    ctx.font = '14px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('拖拽鼠标选择区域，按 ESC 退出', canvas.width / 2, 40);
  }

  // 绘制选区高亮框
  function drawSelection() {
    if (!ctx) return;
    drawOverlay();

    const x = Math.min(startX, currentX);
    const y = Math.min(startY, currentY);
    const w = Math.abs(startX - currentX);
    const h = Math.abs(startY - currentY);

    // 挖空选区
    ctx.clearRect(x, y, w, h);

    // 绘制选区边框
    ctx.strokeStyle = '#6366f1'; // primary theme color
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, w, h);

    // 绘制选区尺寸信息
    if (w > 20 && h > 20) {
      ctx.fillStyle = '#6366f1';
      const label = `${w} x ${h}`;
      ctx.font = '12px var(--mono-font, monospace)';
      ctx.textAlign = 'left';
      ctx.fillRect(x, y - 22, ctx.measureText(label).width + 12, 20);
      ctx.fillStyle = '#ffffff';
      ctx.fillText(label, x + 6, y - 7);
    }
  }

  // 逆向 DOM 提取选区内的所有可见文本节点内容
  function getTextsInRect(rect) {
    const texts = [];
    try {
      const walk = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
      let node;
      while (node = walk.nextNode()) {
        const parent = node.parentElement;
        if (!parent) continue;
        
        // 过滤无关的非渲染标签及本截图蒙版本身
        const tagName = parent.tagName.toUpperCase();
        if (['SCRIPT', 'STYLE', 'NOSCRIPT', 'IFRAME'].includes(tagName)) continue;
        if (parent.closest('#devhelper-screenshot-overlay')) continue;

        const range = document.createRange();
        range.selectNodeContents(node);
        const clientRects = range.getClientRects();
        
        for (let i = 0; i < clientRects.length; i++) {
          const r = clientRects[i];
          // 判定文本段的物理渲染矩形是否与框选区域相交
          const intersect = !(r.right < rect.x || 
                              r.left > (rect.x + rect.width) || 
                              r.bottom < rect.y || 
                              r.top > (rect.y + rect.height));
          if (intersect) {
            const val = node.nodeValue.trim();
            if (val && !texts.includes(val)) {
              texts.push(val);
            }
            break;
          }
        }
      }
    } catch (err) {
      console.warn('DOM 文本提取解析异常:', err);
    }
    return texts.join('\n').trim();
  }

  // 查找真正发生垂直滚动的容器元素
  // 策略：优先 window 滚动（绝大多数页面），只有当 document 本身高度 <= 视口高度时才查找子容器
  function findScrollContainer() {
    const docScrollHeight = Math.max(
      document.documentElement.scrollHeight,
      document.body.scrollHeight
    );
    const viewportHeight = window.innerHeight;

    // 如果 document 本身可以滚动（内容高于视口），直接使用 window 滚动（最常见场景）
    if (docScrollHeight > viewportHeight + 10) {
      return null; // null = 使用 window
    }

    // 页面本身不可滚动，才去查找内容区子容器（单页应用内嵌滚动容器场景）
    const candidates = [];
    const elements = document.getElementsByTagName('*');
    const screenArea = window.innerWidth * window.innerHeight;
    
    for (let i = 0; i < elements.length; i++) {
      const el = elements[i];
      try {
        const style = window.getComputedStyle(el);
        const overflowY = style.overflowY;
        const position = style.position;
        const isScrollable = overflowY === 'auto' || overflowY === 'scroll';
        
        // 排除 fixed/absolute 定位的弹层（如模态框、drawer 等）
        if (position === 'fixed' || position === 'absolute') continue;
        
        if (isScrollable && el.scrollHeight > el.clientHeight && el.clientHeight > 100) {
          const elArea = el.clientWidth * el.clientHeight;
          // 只考虑面积 >= 屏幕面积 40% 的主内容区容器，排除小型滚动组件
          if (elArea >= screenArea * 0.40) {
            candidates.push({
              element: el,
              scrollHeight: el.scrollHeight,
              clientHeight: el.clientHeight,
              area: elArea
            });
          }
        }
      } catch (e) {
        // 忽略跨域等不可读节点
      }
    }
    
    if (candidates.length > 0) {
      // 按面积从大到小，取最大的主内容滚动容器
      candidates.sort((a, b) => b.area - a.area);
      return candidates[0].element;
    }
    
    return null; // 降级到 window
  }
})();
