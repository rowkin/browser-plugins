/**
 * 编解码工具 - 外部逻辑脚本（CSP 安全）
 */
(function () {
  'use strict';

  createNavbar('编解码工具');

  const results = {};

  // 编解码函数
  const codec = {
    url: {
      encode: s => { try { return encodeURIComponent(s); } catch { return '编码失败'; } },
      decode: s => { try { return decodeURIComponent(s); } catch { return '解码失败'; } },
    },
    base64: {
      encode: s => { try { return btoa(unescape(encodeURIComponent(s))); } catch { return '编码失败'; } },
      decode: s => { try { return decodeURIComponent(escape(atob(s))); } catch { return '解码失败'; } },
    },
    unicode: {
      encode: s => s.split('').map(c => c.charCodeAt(0) > 127 ? '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0') : c).join(''),
      decode: s => s.replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16))),
    },
    html: {
      encode: s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;'),
      decode: s => { const d = document.createElement('textarea'); d.innerHTML = s; return d.value; },
    },
  };

  function getInput() { return document.getElementById('mainInput').value; }

  function runCodec(type, op) {
    const input = getInput();
    if (!input) { showToast('请先输入内容', 'info'); return; }
    const res = codec[type][op](input);
    results[type] = res;
    document.getElementById(`result-${type}`).textContent = res;
  }

  // 绑定编解码按钮
  document.querySelectorAll('[data-type]').forEach(btn => {
    btn.addEventListener('click', () => {
      runCodec(btn.dataset.type, btn.dataset.op);
    });
  });

  // 绑定复制按钮
  document.querySelectorAll('[data-copy]').forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.dataset.copy;
      const text = results[type] || '';
      if (text && text !== '-') copyText(text, btn);
      else showToast('没有可复制的内容', 'info');
    });
  });

  // 清空
  document.getElementById('btnClearAll').addEventListener('click', () => {
    document.getElementById('mainInput').value = '';
    ['url', 'base64', 'unicode', 'html'].forEach(t => {
      document.getElementById(`result-${t}`).textContent = '-';
      results[t] = '';
    });
  });

  // 自动解析
  document.getElementById('btnEncodeAll').addEventListener('click', () => {
    const input = getInput();
    if (!input) { showToast('请先输入内容', 'info'); return; }
    Object.keys(codec).forEach(type => {
      let res;
      // 智能判断：如果看起来像已编码内容则解码，否则编码
      if (type === 'base64' && /^[A-Za-z0-9+/]+=*$/.test(input.trim()) && input.length % 4 === 0) {
        res = codec.base64.decode(input);
      } else if (type === 'url' && /%[0-9A-Fa-f]{2}/.test(input)) {
        res = codec.url.decode(input);
      } else if (type === 'unicode' && /\\u[0-9a-fA-F]{4}/.test(input)) {
        res = codec.unicode.decode(input);
      } else {
        res = codec[type].encode(input);
      }
      results[type] = res;
      document.getElementById(`result-${type}`).textContent = res;
    });
    showToast('自动解析完成');
  });

  // AI 解读
  createInlineAIPanel(
    'aiPanelMount',
    () => {
      const input = getInput();
      const resTexts = Object.entries(results).filter(([, v]) => v).map(([k, v]) => `${k}: ${v}`).join('\n');
      return `原始内容: ${input}\n\n编解码结果:\n${resTexts}`;
    },
    'You are a data encoding expert. Analyze: identify encoding types used, explain the original content, highlight any sensitive fields (tokens, credentials), and provide security recommendations. Reply in Chinese.'
  );
})();
