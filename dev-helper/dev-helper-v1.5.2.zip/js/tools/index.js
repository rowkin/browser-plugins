/**
 * DevHelper 全景工具导航页逻辑
 * 功能：工具卡片渲染、分类过滤、搜索、AI 环境就绪检测
 */

// 工具列表（与 popup.js 共享数据）
const TOOLS = [
  { id: 'json-format',   name: 'JSON 格式化', desc: '美化、压缩、校验 JSON 数据', icon: '{ }', color: 'color-indigo', category: 'data',    tags: ['开发工具类', '系统内置', 'AI扩展'],  shortcut: '⌥1' },
  { id: 'json-diff',     name: 'JSON 对比',   desc: '两段 JSON 的差异对比分析',  icon: 'DI',  color: 'color-violet', category: 'data',    tags: ['开发工具类', '系统内置'] },
  { id: 'encode-decode', name: '编解码工具',  desc: 'URL、Base64、Unicode、Hex 互转', icon: 'ENC', color: 'color-cyan', category: 'encode', tags: ['开发工具类', '已安装', 'AI解读'],  shortcut: '⌥2' },
  { id: 'jwt-parser',    name: 'JWT 解析',    desc: '解析和验证 JWT Token 结构',  icon: 'JWT', color: 'color-sky',    category: 'encode',  tags: ['安全开发', '系统内置'] },
  { id: 'hash-calc',     name: '哈希计算',    desc: 'MD5、SHA1、SHA256 哈希值计算', icon: '#', color: 'color-teal',   category: 'encode',  tags: ['安全开发', '已安装'] },
  { id: 'timestamp',     name: '时间戳转换',  desc: 'Unix 时间戳与日期字符串互转', icon: '⏱', color: 'color-amber',  category: 'convert', tags: ['格式转换', '系统内置'],  shortcut: '⌥3' },
  { id: 'color-convert', name: '颜色转换',    desc: 'HEX / RGB / HSL / HSV 互转', icon: '🎨', color: 'color-pink',   category: 'convert', tags: ['开发工具类', '系统内置'] },
  { id: 'number-base',   name: '进制转换',    desc: '2~36 进制数字互转',          icon: '01',  color: 'color-orange', category: 'convert', tags: ['格式转换', '系统内置'] },
  { id: 'api-tester',    name: 'API 调试',    desc: '轻量 Postman，支持 GET/POST/PUT/DELETE', icon: 'API', color: 'color-emerald', category: 'dev', tags: ['开发工具类', '系统内置', 'AI解读'], shortcut: '⌥4' },
  { id: 'code-beautify',    name: '代码格式化',      desc: 'JS/CSS/HTML/JSON 代码美化',               icon: 'JS',  color: 'color-indigo', category: 'dev',      tags: ['开发工具类', '已安装'] },
  { id: 'markdown-editor',  name: 'Markdown 编辑器', desc: '实时预览 · 代码高亮 · Mermaid 图表渲染',  icon: 'MD',  color: 'color-teal',   category: 'dev',      tags: ['开发工具类', '系统内置', 'AI扩展'] },
  { id: 'regex-test',       name: '正则测试',        desc: '正则表达式在线调试匹配',                  icon: 'RE',  color: 'color-violet', category: 'dev',      tags: ['开发工具类', '系统内置'] },
  { id: 'qrcode',        name: '二维码工具',  desc: '生成/解码二维码，支持自定义', icon: 'QR',  color: 'color-cyan',  category: 'generate',tags: ['图形图像', '已安装'] },
  { id: 'uuid-gen',      name: 'UUID 生成器', desc: 'UUID v4、雪花 ID、NanoID 批量生成', icon: 'ID', color: 'color-sky', category: 'generate', tags: ['图形图像', '已安装'] },
  { id: 'password-gen',  name: '密码生成器',  desc: '按规则生成安全随机密码',    icon: '🔐',  color: 'color-rose',   category: 'generate',tags: ['安全开发', '系统内置'] },
  { id: 'img-base64',    name: '图片 Base64', desc: '图片与 Base64 字符串互转',  icon: 'IMG', color: 'color-amber',  category: 'image',   tags: ['图形图像', '系统内置'] },
  { id: 'screenshot',    name: '屏幕截图',    desc: '选区 / 整页 / 可视区截图，支持 AI 多模态视觉解析与文字提取', icon: '📸', color: 'color-indigo', category: 'image',   tags: ['图形图像', 'AI解读', '系统内置'] },
  { id: 'page-timing',   name: '页面性能检测', desc: '深度检测页面加载性能，分析核心 Web 指标并生成优化建议', icon: '⚡', color: 'color-orange', category: 'dev', tags: ['开发工具类', '系统内置', 'AI解读'], shortcut: '⌥5' },
  { id: 'ip-speed',      name: 'IP 与网速检测', desc: '查询内外网 IP 地址与网络延迟，测试网络实时下载与上传速度', icon: '🌐', color: 'color-indigo', category: 'dev', tags: ['开发工具类', '系统内置', 'AI解读'], shortcut: '⌥6' },
  { id: 'universal-calculator', name: '万能计算器', desc: '多功能计算器面板，支持实时汇率换算与房贷月供多维推演', icon: '🧮', color: 'color-indigo', category: 'convert', tags: ['格式转换', '系统内置'] },
];

const CATEGORIES = [
  { id: 'all',     label: '全部' },
  { id: 'data',    label: '📊 数据处理' },
  { id: 'encode',  label: '🔐 编解码' },
  { id: 'convert', label: '🔄 格式转换' },
  { id: 'dev',     label: '🛠 开发工具' },
  { id: 'generate',label: '✨ 生成工具' },
  { id: 'image',   label: '🖼 图片工具' },
];

let currentCategory = 'all';
let searchQuery = '';
let favoriteToolsList = [];

// ─── 主题 ──────────────────────────────────────

function initIndexTheme() {
  const manual = localStorage.getItem('devhelper-theme-manual') === 'true';
  let theme = 'light';
  if (manual) {
    theme = localStorage.getItem('devhelper-theme') || 'light';
  } else {
    const hour = new Date().getHours();
    theme = (hour >= 6 && hour < 18) ? 'light' : 'dark';
    localStorage.setItem('devhelper-theme', theme);
  }
  document.documentElement.setAttribute('data-theme', theme);
  updateThemeToggleBtn(theme);
}

function updateThemeToggleBtn(theme) {
  const btn = document.getElementById('themeToggleBtn');
  if (btn) btn.textContent = theme === 'dark' ? '☀️' : '🌙';
}

// ─── 工具卡片渲染 ────────────────────────────────

function renderTools(filter = '', category = 'all') {
  const grid = document.getElementById('toolsGrid');
  const q = filter.toLowerCase().trim();

  const filtered = TOOLS.filter(t => {
    const matchCat = category === 'all' || t.category === category;
    const matchQuery = !q || t.name.toLowerCase().includes(q) || t.desc.toLowerCase().includes(q) || t.id.includes(q);
    return matchCat && matchQuery;
  });

  grid.innerHTML = '';
  if (filtered.length === 0) {
    grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--text-tertiary)">没有找到匹配的工具 🔍</div>`;
    return;
  }

  filtered.forEach(tool => {
    const card = document.createElement('a');
    card.className = 'tool-card';
    card.href = tool.id + '.html';
    const isFav = favoriteToolsList.includes(tool.id);
    card.innerHTML = `
      <button class="tool-favorite-btn${isFav ? ' favorited' : ''}" title="收藏/取消收藏">
        ${isFav ? '★' : '☆'}
      </button>
      <div class="tool-card-icon ${tool.color}">${tool.icon}</div>
      <div class="tool-card-body">
        <div class="tool-card-title">${tool.name}</div>
        <div class="tool-card-desc">${tool.desc}</div>
      </div>
      <div class="tool-card-footer">
        <div class="tool-tags">
          ${tool.tags ? tool.tags.map(tag => `<span class="tool-pill-tag">${tag}</span>`).join('') : ''}
        </div>
        <div style="display:flex;align-items:center;gap:6px">
          <span class="tool-arrow">→</span>
        </div>
      </div>`;
    
    const favBtn = card.querySelector('.tool-favorite-btn');
    favBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      if (favoriteToolsList.includes(tool.id)) {
        favoriteToolsList = favoriteToolsList.filter(id => id !== tool.id);
        favBtn.classList.remove('favorited');
        favBtn.textContent = '☆';
        showToast('已取消收藏');
      } else {
        favoriteToolsList.push(tool.id);
        favBtn.classList.add('favorited');
        favBtn.textContent = '★';
        showToast('已加入收藏');
      }
      await chrome.storage.local.set({ favoriteTools: favoriteToolsList });
    });

    grid.appendChild(card);
  });
}

// ─── 分类标签 ────────────────────────────────────

function renderCategories() {
  const tabs = document.getElementById('categoryTabs');
  tabs.innerHTML = '';
  CATEGORIES.forEach(cat => {
    const btn = document.createElement('button');
    btn.className = 'category-tab' + (cat.id === currentCategory ? ' active' : '');
    btn.textContent = cat.label;
    btn.addEventListener('click', () => {
      currentCategory = cat.id;
      document.querySelectorAll('.category-tab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderTools(searchQuery, currentCategory);
    });
    tabs.appendChild(btn);
  });
}

// ─── AI 就绪环境检测 ──────────────────────────────

let builtinAIInstallTimer = null;

function startBuiltinAIPolling() {
  if (builtinAIInstallTimer) return;
  showToast('🔄 已启动本地 AI 自动检测，待模型下载/开启完毕后系统将自动激活...', 'info', 4000);
  
  builtinAIInstallTimer = setInterval(async () => {
    let nowAvailable = false;
    try {
      if (window.LanguageModel) {
        const avail = await window.LanguageModel.availability();
        if (avail === 'available') nowAvailable = true;
      } else if (window.ai?.languageModel) {
        const caps = await window.ai.languageModel.capabilities();
        if (caps.available === 'readily') nowAvailable = true;
      }
    } catch (e) {
      console.log('Gemini Nano 自动轮询中...', e);
    }
    
    if (nowAvailable) {
      clearInterval(builtinAIInstallTimer);
      builtinAIInstallTimer = null;
      
      const builtinDot = document.getElementById('checkBuiltinDot');
      const builtinStatus = document.getElementById('checkBuiltinStatus');
      if (builtinDot) builtinDot.className = 'ai-check-dot ok';
      if (builtinStatus) builtinStatus.textContent = 'Gemini Nano 已就绪（本地离线推理）';
      
      // 自动切换为内置模型
      const modelSelect = document.getElementById('sidebarModelSelect');
      if (modelSelect) {
        modelSelect.value = 'builtin';
        chrome.storage.local.get(['aiConfig'], (data) => {
          const config = data.aiConfig || {};
          config.provider = 'builtin';
          chrome.storage.local.set({ aiConfig: config });
        });
      }
      
      showToast('🎉 恭喜！本地 AI (Gemini Nano) 已下载并自动激活！', 'success', 5000);
      updateReadinessStatus(true);
    }
  }, 2500);
}

async function runAIReadinessCheck() {
  // 1. 检测 Chrome 内置 AI (Gemini Nano)
  const builtinDot = document.getElementById('checkBuiltinDot');
  const builtinStatus = document.getElementById('checkBuiltinStatus');

  let builtinOk = false;
  try {
    if (window.LanguageModel) {
      const avail = await window.LanguageModel.availability();
      if (avail === 'available') {
        builtinDot.className = 'ai-check-dot ok';
        builtinStatus.textContent = 'Gemini Nano 已可用（本地离线推理）';
        builtinOk = true;
      } else if (avail === 'downloadable') {
        builtinDot.className = 'ai-check-dot warn';
        builtinStatus.innerHTML = 'Gemini Nano 可下载 &nbsp;<span class="ai-check-action" id="downloadModelLink">一键后台下载并激活</span>';
        document.getElementById('downloadModelLink')?.addEventListener('click', () => {
          builtinDot.className = 'ai-check-dot loading';
          builtinStatus.innerHTML = '正在唤起后台下载（请确保磁盘可用空间 >= 10GB）...';
          showToast('🚀 已唤起下载。请确保磁盘有 10GB 以上空闲空间，否则 Chrome 可能会因空间不足挂起下载。', 'info', 7000);
          
          // 异步触发下载，直接调用 create 并设置输出语言唤起后台下载，无需 await 阻塞前台
          window.LanguageModel.create({
            expectedOutputLanguages: ['en'],
            expectedOutputs: [{ type: 'text', languages: ['en'] }]
          }).catch(err => {
            console.log('后台唤起下载已执行或被取消，属于正常下载初始化:', err);
          });
          
          startBuiltinAIPolling();
        });
        builtinOk = false;
      } else {
        builtinDot.className = 'ai-check-dot warn';
        builtinStatus.innerHTML = '硬件或策略限制 &nbsp;<span class="ai-check-action" id="enableAILink">查看开启步骤</span>';
        document.getElementById('enableAILink')?.addEventListener('click', () => {
          showBuiltinAIGuide();
          startBuiltinAIPolling();
        });
        builtinOk = false;
      }
    } else if (window.ai?.languageModel) {
      const caps = await window.ai.languageModel.capabilities();
      if (caps.available === 'readily') {
        builtinDot.className = 'ai-check-dot ok';
        builtinStatus.textContent = 'Gemini Nano 已可用（本地离线推理）';
        builtinOk = true;
      } else if (caps.available === 'after-download') {
        builtinDot.className = 'ai-check-dot warn';
        builtinStatus.innerHTML = 'Gemini Nano 可下载 &nbsp;<span class="ai-check-action" id="downloadModelLink">一键后台下载并激活</span>';
        document.getElementById('downloadModelLink')?.addEventListener('click', () => {
          builtinDot.className = 'ai-check-dot loading';
          builtinStatus.innerHTML = '正在唤起后台下载（请确保磁盘可用空间 >= 10GB）...';
          showToast('🚀 已唤起下载。请确保磁盘有 10GB 以上空闲空间，否则 Chrome 可能会因空间不足挂起下载。', 'info', 7000);
          
          // 异步触发下载，直接调用 create 并设置输出语言唤起后台下载
          window.ai.languageModel.create({
            expectedOutputLanguages: ['en'],
            expectedOutputs: [{ type: 'text', languages: ['en'] }]
          }).catch(err => {
            console.log('后台唤起下载已执行或被取消，属于正常下载初始化:', err);
          });
          
          startBuiltinAIPolling();
        });
        builtinOk = false;
      } else {
        builtinDot.className = 'ai-check-dot warn';
        builtinStatus.innerHTML = '需开启 Chrome Flags &nbsp;<span class="ai-check-action" id="enableFlagsLink">一键跳转配置</span>';
        document.getElementById('enableFlagsLink')?.addEventListener('click', () => {
          showBuiltinAIGuide();
          startBuiltinAIPolling();
        });
        builtinOk = false;
      }
    } else {
      builtinDot.className = 'ai-check-dot error';
      builtinStatus.innerHTML = '未检测到内置 AI API &nbsp;<span class="ai-check-action" id="enableFlagsLink2">查看开启方法并检测</span>';
      document.getElementById('enableFlagsLink2')?.addEventListener('click', () => {
        showBuiltinAIGuide();
        startBuiltinAIPolling();
      });
      builtinOk = false;
    }
  } catch {
    builtinDot.className = 'ai-check-dot error';
    builtinStatus.textContent = '检测失败（扩展环境受限）';
    builtinOk = false;
  }

  // 2. 检测自定义 API 配置
  const customDot = document.getElementById('checkCustomDot');
  const customStatus = document.getElementById('checkCustomStatus');

  try {
    const data = await chrome.storage.local.get(['aiConfig']);
    const config = data.aiConfig;
    if (config?.apiKey && config.apiKey.length > 8) {
      customDot.className = 'ai-check-dot ok';
      const maskedKey = config.apiKey.slice(0, 6) + '…' + config.apiKey.slice(-4);
      customStatus.textContent = `已配置：${maskedKey} | 模型：${config.model || '默认'}`;
    } else {
      customDot.className = 'ai-check-dot warn';
      customStatus.innerHTML = '未配置 API Key &nbsp;<span class="ai-check-action" id="configApiLink">立即配置</span>';
      document.getElementById('configApiLink')?.addEventListener('click', () => {
        if (typeof showAISettingsModal === 'function') showAISettingsModal();
      });
    }
  } catch {
    customDot.className = 'ai-check-dot error';
    customStatus.textContent = '配置读取失败';
  }

  // 3. 更新总状态展示
  updateReadinessStatus(builtinOk);
}

function updateReadinessStatus(builtinOk) {
  const badge = document.getElementById('aiStatusBadge');
  const tagline = document.getElementById('readinessTagline');
  const desc = document.getElementById('readinessDesc');
  const actions = document.getElementById('readinessActions');

  chrome.storage.local.get(['aiConfig'], (data) => {
    const hasCustomApi = !!(data.aiConfig?.apiKey?.length > 8);
    const isReady = builtinOk || hasCustomApi;

    if (isReady) {
      badge.className = 'ai-status-card-badge ready';
      badge.innerHTML = '✅ AI 已就绪';
      tagline.textContent = builtinOk ? 'DevHelper AI 已就绪，Gemini Nano 可用' : 'DevHelper AI 已就绪，自定义 API 已配置';
      desc.textContent = '所有 AI 增强功能可正常使用，包括工具 AI 解读和 AI 助手。';
      actions.innerHTML = `
        <a href="ai-assistant.html" class="btn btn-primary" style="font-size:12px;padding:6px 12px">🤖 侧边独立助手</a>
        <button class="btn btn-ghost" id="redetectBtn" style="font-size:12px;padding:6px 12px">🔄 重新检测</button>`;
    } else {
      badge.className = 'ai-status-card-badge partial';
      badge.innerHTML = '⚠️ 待配置';
      tagline.textContent = 'AI 功能待配置，部分能力受限';
      desc.textContent = '可配置自定义 API（如火山引擎 Coding Plan Lite）或开启 Chrome 内置 AI。';
      actions.innerHTML = `
        <button class="btn btn-primary" id="quickConfigBtn" style="font-size:12px;padding:6px 12px">⚡ 快速配置 AI</button>
        <button class="btn btn-ghost" id="redetectBtn" style="font-size:12px;padding:6px 12px">🔄 重新检测</button>`;
      document.getElementById('quickConfigBtn')?.addEventListener('click', () => {
        if (typeof showAISettingsModal === 'function') showAISettingsModal();
      });
    }

    document.getElementById('redetectBtn')?.addEventListener('click', () => {
      // 重置检测状态
      ['checkBuiltinDot', 'checkCustomDot'].forEach(id => {
        document.getElementById(id).className = 'ai-check-dot loading';
      });
      ['checkBuiltinStatus', 'checkCustomStatus'].forEach(id => {
        document.getElementById(id).textContent = '检测中…';
      });
      badge.className = 'ai-status-card-badge';
      badge.innerHTML = '⏳ 检测中';
      actions.innerHTML = '';
      runAIReadinessCheck();
    });
  });
}

// ─── Chrome Flags 引导弹窗 ────────────────────────

function showBuiltinAIGuide() {
  const overlay = document.createElement('div');
  overlay.style.cssText = `position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;display:flex;align-items:center;justify-content:center`;
  overlay.innerHTML = `
    <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:16px;padding:28px;max-width:480px;width:90%;box-shadow:0 24px 80px rgba(0,0,0,.2)">
      <div style="font-size:18px;font-weight:800;color:var(--text-primary);margin-bottom:8px">🧠 开启 Chrome 内置 AI</div>
      <p style="font-size:13px;color:var(--text-secondary);line-height:1.7;margin-bottom:16px">
        Chrome 内置 Gemini Nano 模型，无需 API Key，完全本地离线推理。按以下步骤开启：
      </p>
      <ol style="font-size:13px;color:var(--text-primary);line-height:2;padding-left:20px;margin-bottom:20px">
        <li>打开 <code style="background:var(--bg-elevated);padding:1px 6px;border-radius:4px">chrome://flags/#prompt-api-for-gemini-nano</code><br>设置为 <strong>Enabled</strong></li>
        <li>打开 <code style="background:var(--bg-elevated);padding:1px 6px;border-radius:4px">chrome://flags/#optimization-guide-on-device-model</code><br>设置为 <strong>Enabled BypassPerfRequirement</strong></li>
        <li>重启 Chrome，然后访问 <code style="background:var(--bg-elevated);padding:1px 6px;border-radius:4px">chrome://components/</code> 点击「Optimization Guide On Device Model」→「检查更新」触发模型下载</li>
      </ol>
      <div style="font-size:11px;color:var(--text-tertiary);margin-top:12px;margin-bottom:16px;line-height:1.4">
        💡 提示：模型下载与解压需要约 10GB 以上磁盘可用空间。如果下载无响应、被挂起或控制台报 Space 不足的 Warning，请检查并清理磁盘剩余空间。
      </div>
      <div style="display:flex;gap:10px">
        <button class="btn btn-primary" id="openFlagsBtn">打开 Flags 页面</button>
        <button class="btn btn-ghost" id="closeGuideBtn">关闭并且开始检测</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  document.getElementById('closeGuideBtn').addEventListener('click', () => {
    overlay.remove();
    startBuiltinAIPolling();
  });
  document.getElementById('openFlagsBtn').addEventListener('click', () => {
    chrome.tabs.create({ url: 'chrome://flags/#prompt-api-for-gemini-nano' });
    overlay.remove();
    startBuiltinAIPolling();
  });
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
}

// ─── 右侧 AI 助手聊天逻辑 ──────────────────────────

let sidebarMessages = [];
let isSidebarGenerating = false;

function initSidebarChat() {
  const msgInput = document.getElementById('sidebarMsgInput');
  const sendBtn = document.getElementById('btnSidebarSend');
  const clearBtn = document.getElementById('btnClearSidebarChat');
  const settingsBtn = document.getElementById('btnSidebarSettings');
  const chatMessages = document.getElementById('sidebarChatMessages');
  const modelSelect = document.getElementById('sidebarModelSelect');

  if (!msgInput || !sendBtn) return;

  // 自动调整输入框高度
  msgInput.addEventListener('input', () => {
    if (!msgInput.value) {
      msgInput.style.height = '18px';
    } else {
      msgInput.style.height = 'auto';
      msgInput.style.height = Math.min(80, msgInput.scrollHeight) + 'px';
    }
  });

  // 回车发送，Shift+Enter 换行
  msgInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendSidebarMessage();
    }
  });

  sendBtn.addEventListener('click', sendSidebarMessage);

  clearBtn?.addEventListener('click', () => {
    sidebarMessages = [];
    chatMessages.innerHTML = `
      <div style="font-size:12px;color:var(--text-secondary);text-align:center;margin-top:20px;padding: 10px;line-height:1.6">
        👋 你好！我是你的专属 AI 助手。可以在此处快速提问，也可以直接进行工具解读。
      </div>`;
    chrome.storage.local.set({ sidebarMessages: [] }).catch(() => {});
  });

  settingsBtn?.addEventListener('click', () => {
    if (typeof showAISettingsModal === 'function') showAISettingsModal();
  });

  // 初始化并监听模型切换 Select 状态
  if (modelSelect) {
    chrome.storage.local.get(['aiConfig'], (data) => {
      const config = data.aiConfig || {};
      if (config.provider) {
        modelSelect.value = config.provider;
      }
    });

    modelSelect.addEventListener('change', async (e) => {
      const val = e.target.value;
      if (val === 'builtin') {
        let builtinAvailable = false;
        try {
          if (window.LanguageModel) {
            const avail = await window.LanguageModel.availability();
            builtinAvailable = avail === 'available';
          } else if (window.ai?.languageModel) {
            const caps = await window.ai.languageModel.capabilities();
            builtinAvailable = caps.available !== 'no';
          }
        } catch {}

        if (!builtinAvailable) {
          showToast('⚠️ 本地内置 AI 尚未就绪，请先根据就绪卡片引导开启/下载模型！', 'error', 4500);
          modelSelect.value = 'openai'; // 回滚
          return;
        }
      } else if (val === 'openai') {
        const data = await chrome.storage.local.get(['aiConfig']);
        const config = data.aiConfig || {};
        if (!config.apiKey || config.apiKey.length < 8) {
          showToast('💡 请配置自定义 API 接口和 Key (例如火山引擎/OpenAI)', 'info', 4000);
          if (typeof showAISettingsModal === 'function') showAISettingsModal();
        }
      }

      chrome.storage.local.get(['aiConfig'], (data) => {
        const config = data.aiConfig || {};
        config.provider = val;
        chrome.storage.local.set({ aiConfig: config }).then(() => {
          showToast(`已切换至：${val === 'builtin' ? 'Chrome 内置 AI' : '自定义 API'}`);
          runAIReadinessCheck();
        });
      });
    });
  }

  // 从 Storage 恢复历史记录
  chrome.storage.local.get(['sidebarMessages'], (data) => {
    if (data.sidebarMessages && data.sidebarMessages.length > 0) {
      sidebarMessages = data.sidebarMessages;
      chatMessages.innerHTML = '';
      sidebarMessages.forEach(m => {
        appendSidebarBubble(m.role, m.content);
      });
      scrollSidebarToBottom();
    }
  });
}

function appendSidebarBubble(role, content) {
  const chatMessages = document.getElementById('sidebarChatMessages');
  const bubble = document.createElement('div');
  bubble.className = `chat-bubble ${role}`;
  const avatar = role === 'user' ? '👤' : '🤖';
  bubble.innerHTML = `
    <div class="chat-bubble-avatar">${avatar}</div>
    <div class="chat-bubble-content">${renderInlineMarkdown(content)}</div>
  `;
  chatMessages.appendChild(bubble);
  return bubble;
}

function appendSidebarThinking() {
  const chatMessages = document.getElementById('sidebarChatMessages');
  const el = document.createElement('div');
  el.className = 'chat-bubble assistant';
  el.innerHTML = `
    <div class="chat-bubble-avatar">🤖</div>
    <div class="chat-bubble-content">
      <div class="thinking-dots-sm"><span></span><span></span><span></span></div>
    </div>`;
  chatMessages.appendChild(el);
  scrollSidebarToBottom();
  return el;
}

function scrollSidebarToBottom() {
  const chatMessages = document.getElementById('sidebarChatMessages');
  if (chatMessages) chatMessages.scrollTop = chatMessages.scrollHeight;
}

async function sendSidebarMessage() {
  const msgInput = document.getElementById('sidebarMsgInput');
  const chatMessages = document.getElementById('sidebarChatMessages');
  const sendBtn = document.getElementById('btnSidebarSend');
  const text = msgInput.value.trim();

  if (!text || isSidebarGenerating) return;

  // 移除空会话提示
  if (sidebarMessages.length === 0) {
    chatMessages.innerHTML = '';
  }

  msgInput.value = '';
  msgInput.style.height = '18px';

  appendSidebarBubble('user', text);
  sidebarMessages.push({ role: 'user', content: text });
  scrollSidebarToBottom();

  isSidebarGenerating = true;
  sendBtn.disabled = true;

  const thinkingEl = appendSidebarThinking();
  const systemPrompt = `你是 DevHelper AI，七九在线科技的专属技术助手。
高度擅长：前端开发、后端开发、API 调试、代码审查等。
回答要求：
1. 回答尽量简洁，适合在侧边栏聊天框中阅读。
2. 回答要点并给出清晰的代码示例。
3. 重点突出，逻辑严谨。
4. 请务必使用简体中文进行回答，若有英文术语或原代码，提供双语对照形式展示。`;

  let aiBubble = null;
  try {
    const historyCtx = sidebarMessages.slice(-8).map(m => `${m.role === 'user' ? '用户' : 'AI'}: ${m.content}`).join('\n');
    const prompt = sidebarMessages.length > 1
      ? `对话历史:\n${historyCtx}\n\n请回答最后一条用户问题`
      : text;

    let fullReply = '';
    aiBubble = document.createElement('div');
    aiBubble.className = 'chat-bubble assistant';

    const avatarEl = document.createElement('div');
    avatarEl.className = 'chat-bubble-avatar';
    avatarEl.textContent = '🤖';

    const bubbleContent = document.createElement('div');
    bubbleContent.className = 'chat-bubble-content';

    aiBubble.appendChild(avatarEl);
    aiBubble.appendChild(bubbleContent);

    await DevHelperAI.callAI(systemPrompt, prompt, (chunk) => {
      if (thinkingEl && thinkingEl.parentNode) {
        thinkingEl.remove();
      }
      if (!aiBubble.parentNode) {
        chatMessages.appendChild(aiBubble);
      }
      fullReply = chunk;
      bubbleContent.innerHTML = renderInlineMarkdown(chunk);
      scrollSidebarToBottom();
    });

    sidebarMessages.push({ role: 'assistant', content: fullReply });
    chrome.storage.local.set({ sidebarMessages }).catch(() => {});
  } catch (err) {
    if (thinkingEl && thinkingEl.parentNode) {
      thinkingEl.remove();
    }
    // 如果气泡已添加到页面，直接在里面显示错误
    if (aiBubble && aiBubble.parentNode) {
      const bContent = aiBubble.querySelector('.chat-bubble-content');
      if (bContent) {
        bContent.innerHTML = `<span style="color:var(--error);font-weight:600">❌ AI 调用失败：${err.message}</span>`;
        const configBtn = document.createElement('button');
        configBtn.className = 'btn btn-sm btn-ghost';
        configBtn.style.marginTop = '4px';
        configBtn.style.display = 'block';
        configBtn.textContent = '⚙️ 配置 API Key';
        configBtn.addEventListener('click', () => {
          if (typeof showAISettingsModal === 'function') showAISettingsModal();
        });
        bContent.appendChild(configBtn);
      }
    } else {
      // 否则，新建一个气泡展示错误
      const errorBubble = appendSidebarBubble('assistant', `❌ AI 调用失败：${err.message}`);
      const configBtn = document.createElement('button');
      configBtn.className = 'btn btn-sm btn-ghost';
      configBtn.style.marginTop = '4px';
      configBtn.style.display = 'block';
      configBtn.textContent = '⚙️ 配置 API Key';
      configBtn.addEventListener('click', () => {
        if (typeof showAISettingsModal === 'function') showAISettingsModal();
      });
      errorBubble.querySelector('.chat-bubble-content').appendChild(configBtn);
    }
  } finally {
    isSidebarGenerating = false;
    sendBtn.disabled = false;
  }
}

// ─── 事件绑定 ────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  initIndexTheme();

  // 主题切换
  document.getElementById('themeToggleBtn')?.addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme') || 'light';
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('devhelper-theme', next);
    localStorage.setItem('devhelper-theme-manual', 'true');
    updateThemeToggleBtn(next);
    try { chrome.storage.local.set({ 'devhelper-theme': next, 'devhelper-theme-manual': 'true' }); } catch {}
  });

  // 注册页面内 AI 助手全局键盘快捷键监听器
  document.addEventListener('keydown', (e) => {
    // 录入输入时不拦截单纯的内容输入（没有修饰键时）
    if ((e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') && 
        !e.ctrlKey && !e.altKey && !e.metaKey) {
      return;
    }
    
    chrome.storage.local.get(['custom-ai-shortcut'], (res) => {
      const shortcut = res['custom-ai-shortcut'] || 'Alt+Shift+A';
      
      const parts = shortcut.split('+');
      const wantCtrl = parts.includes('Ctrl');
      const wantShift = parts.includes('Shift');
      const wantAlt = parts.includes('Alt');
      const wantMeta = parts.includes('Meta');
      const wantKey = parts[parts.length - 1].toUpperCase();
      
      const gotCtrl = e.ctrlKey;
      const gotShift = e.shiftKey;
      const gotAlt = e.altKey;
      const gotMeta = e.metaKey;
      
      let gotKey = e.key;
      if (gotKey === ' ') gotKey = 'Space';
      else if (gotKey.length === 1) gotKey = gotKey.toUpperCase();
      
      if (
        wantCtrl === gotCtrl &&
        wantShift === gotShift &&
        wantAlt === gotAlt &&
        wantMeta === gotMeta &&
        wantKey === gotKey
      ) {
        e.preventDefault();
        e.stopPropagation();
        
        const mainLayout = document.querySelector('.main-layout');
        if (mainLayout) {
          mainLayout.classList.toggle('hide-right');
        }
      }
    });
  });

  // 搜索
  document.getElementById('searchInput')?.addEventListener('input', (e) => {
    searchQuery = e.target.value;
    renderTools(searchQuery, currentCategory);
  });

  // 获取收藏夹数据后再开始渲染，防止渲染时状态丢失
  chrome.storage.local.get(['favoriteTools'], (data) => {
    favoriteToolsList = data.favoriteTools || [];

    // 渲染工具
    renderCategories();
    renderTools();

    // AI 就绪检测
    runAIReadinessCheck();

    // 初始化侧边栏 AI 助手
    initSidebarChat();
  });
});
