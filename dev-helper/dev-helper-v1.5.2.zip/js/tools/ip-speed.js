/**
 * DevHelper - IP 与网速检测工具逻辑
 */

// 默认测速源：cdnjs 的 React 开发版 (约 100KB) 和 three.js (约 600KB)
const DEFAULT_SPEED_TEST_FILE = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';

// 网络评估状态
function evaluateNetwork(ping, jitter, download, upload) {
  if (!download) return { level: '未知', class: 'status-poor' };
  
  let score = 0;
  // 下载速度权重 (0-4)
  if (download >= 80) score += 4;
  else if (download >= 40) score += 3;
  else if (download >= 15) score += 2;
  else if (download >= 5) score += 1;
  
  // 延迟权重 (0-3)
  if (ping > 0) {
    if (ping <= 30) score += 3;
    else if (ping <= 80) score += 2;
    else if (ping <= 180) score += 1;
  } else {
    score += 1; // 兜底
  }
  
  // 抖动权重 (0-2)
  if (jitter > 0) {
    if (jitter <= 8) score += 2;
    else if (jitter <= 25) score += 1;
  } else {
    score += 1; // 兜底
  }

  if (score >= 7) return { level: '极佳', class: 'status-excellent' };
  if (score >= 4) return { level: '良好', class: 'status-warning' };
  return { level: '较差', class: 'status-poor' };
}

// ─── 探测局域网内网 IP ──────────────────────────────
async function getLocalIP() {
  return new Promise((resolve) => {
    try {
      const pc = new RTCPeerConnection({ iceServers: [] });
      pc.createDataChannel('');
      pc.createOffer().then(offer => pc.setLocalDescription(offer)).catch(() => resolve('未知'));
      
      pc.onicecandidate = (ice) => {
        if (!ice || !ice.candidate || !ice.candidate.candidate) {
          resolve('未知 (局域网隔离)');
          return;
        }
        const candidate = ice.candidate.candidate;
        // 匹配 IPv4 地址
        const ipRegex = /([0-9]{1,3}(\.[0-9]{1,3}){3})/;
        const match = ipRegex.exec(candidate);
        if (match) {
          resolve(match[1]);
          pc.close();
        }
      };
      
      // 1.5秒超时兜底
      setTimeout(() => {
        resolve('未知 (探测超时)');
        try { pc.close(); } catch {}
      }, 1500);
    } catch (e) {
      resolve('无法检测 (浏览器安全限制)');
    }
  });
}

// ─── 内网 IP 物理归属识别 ────────────────────────────
function getLocalIpAttribute(ip) {
  if (!ip || ip.includes('探测') || ip.includes('未知') || ip.includes('无法')) {
    return '局域网内部网络';
  }
  if (ip.startsWith('10.')) {
    return 'A类私有网络 (大型企业内部局域网)';
  }
  if (ip.startsWith('192.168.')) {
    return 'C类私有网络 (家庭/小微办公局域网)';
  }
  if (ip.startsWith('172.')) {
    const secondOctet = parseInt(ip.split('.')[1], 10);
    if (secondOctet >= 16 && secondOctet <= 31) {
      return 'B类私有网络 (中型企业局域网)';
    }
  }
  if (ip.startsWith('127.')) {
    return '环回环路本地地址 (Loopback)';
  }
  if (ip.startsWith('169.254.')) {
    return '链路本地自配置地址 (DHCP获取失败)';
  }
  return '局域网专有地址段';
}

// ─── 获取公网外网 IP 及地理位置 ──────────────────────
async function getPublicIP() {
  const apis = [
    {
      // 1. B站 IP 接口，国内畅通，信息详细且格式规整
      url: 'https://api.live.bilibili.com/client/v1/Ip/getIpInfo',
      parser: (res) => {
        if (res && res.code === 0 && res.data) {
          return {
            ip: res.data.ip || '-',
            country: res.data.country || '-',
            city: `${res.data.province || ''} ${res.data.city || ''}`.trim() || '-',
            isp: res.data.isp || '-'
          };
        }
        throw new Error('格式不符合预期');
      }
    },
    { 
      // 2. freeipapi，国外优质的高可用免费公开 IP 地理服务 (支持 HTTPS)
      url: 'https://freeipapi.com/api/json/', 
      parser: (res) => ({ 
        ip: res.ipAddress || '-', 
        country: res.countryName || '-', 
        city: `${res.regionName || ''} ${res.cityName || ''}`.trim() || '-', 
        isp: '-' 
      }) 
    },
    { 
      // 3. ipapi.co，经典的备用 IP 地址库
      url: 'https://ipapi.co/json/', 
      parser: (res) => ({ 
        ip: res.ip || '-', 
        country: res.country_name || '-', 
        city: `${res.region || ''} ${res.city || ''}`.trim() || '-', 
        isp: res.org || '-' 
      }) 
    },
    {
      // 4. 百度公开 IP 检测接口，在国内极度稳定
      url: 'https://opendata.baidu.com/api.php?query=self&co=&resource_id=6006&oe=utf8&format=json',
      parser: (res) => {
        if (res && res.data && res.data[0]) {
          const item = res.data[0];
          let city = '-';
          let isp = '-';
          if (item.location) {
            const parts = item.location.trim().split(/\s+/);
            city = parts[0] || '-';
            isp = parts[1] || '-';
          }
          return {
            ip: item.clientIP || '-',
            country: '中国',
            city: city,
            isp: isp
          };
        }
        throw new Error('格式不符合预期');
      }
    },
    {
      // 5. ipinfo.io，提供基础 IP 信息及运营商 AS 解析
      url: 'https://ipinfo.io/json',
      parser: (res) => {
        let isp = res.org || '-';
        if (isp.includes(' ')) {
          isp = isp.substring(isp.indexOf(' ') + 1);
        }
        return {
          ip: res.ip || '-',
          country: res.country || '-',
          city: `${res.region || ''} ${res.city || ''}`.trim() || '-',
          isp: isp
        };
      }
    },
    { 
      // 6. 最基础的 IP 获取端点进行最后的兜底
      url: 'https://api.ipify.org?format=json', 
      parser: (res) => ({ 
        ip: res.ip || '-', 
        country: '未知', 
        city: '未知', 
        isp: '未知' 
      }) 
    }
  ];
  
  for (const api of apis) {
    try {
      // 增加超时信号，防卡死
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);
      
      const response = await fetch(api.url, { 
        method: 'GET',
        signal: controller.signal,
        cache: 'no-store' 
      });
      clearTimeout(timeoutId);
      
      if (response.ok) {
        const json = await response.json();
        return api.parser(json);
      }
    } catch (e) {
      console.log(`公网 IP 检测源备用切换 (源 ${api.url} 不可用):`, e.message);
    }
  }
  return { ip: '检测失败，请检查网络连接', country: '未知', city: '未知', isp: '未知' };
}

// ─── 测延迟与抖动 ──────────────────────────────────
async function testPingAndJitter(testUrl) {
  const pings = [];
  // 连续测量 5 次
  for (let i = 0; i < 5; i++) {
    const start = performance.now();
    try {
      // 发送轻量的 HEAD 请求，带上随机数以防缓存
      await fetch(`${testUrl}?t=${Math.random()}`, { 
        method: 'HEAD', 
        cache: 'no-store',
        mode: 'no-cors'
      });
      pings.push(performance.now() - start);
    } catch (e) {
      // 降级使用 GET
      try {
        await fetch(`${testUrl}?t=${Math.random()}`, { 
          method: 'GET', 
          cache: 'no-store', 
          mode: 'no-cors'
        });
        pings.push(performance.now() - start);
      } catch (err) {
        // 请求失败则丢弃该帧
      }
    }
    // 间隔 80ms
    await new Promise(r => setTimeout(r, 80));
  }
  
  if (pings.length === 0) return { ping: 0, jitter: 0 };
  
  const avgPing = pings.reduce((a, b) => a + b, 0) / pings.length;
  
  // 计算抖动 Jitter：相邻测量的延迟差绝对值的平均值
  let jitterSum = 0;
  for (let i = 1; i < pings.length; i++) {
    jitterSum += Math.abs(pings[i] - pings[i - 1]);
  }
  const jitter = pings.length > 1 ? jitterSum / (pings.length - 1) : 0;
  
  return { ping: Math.round(avgPing), jitter: Math.round(jitter) };
}

// ─── 下载速度测速 ──────────────────────────────────
function testDownloadSpeed(fileUrl, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const startTime = performance.now();
    
    // 随机数防缓存
    xhr.open('GET', `${fileUrl}?t=${Math.random()}`, true);
    xhr.responseType = 'blob';
    
    xhr.onprogress = (e) => {
      if (e.lengthComputable && e.loaded > 0) {
        const now = performance.now();
        const elapsedSeconds = (now - startTime) / 1000;
        if (elapsedSeconds > 0) {
          // 转换为 Mbps (bits per second)
          const speedMbps = (e.loaded * 8) / (1024 * 1024) / elapsedSeconds;
          const progress = (e.loaded / e.total) * 100;
          onProgress({ speed: speedMbps, progress });
        }
      }
    };
    
    xhr.onload = () => {
      const endTime = performance.now();
      const elapsedSeconds = (endTime - startTime) / 1000;
      const sizeBits = xhr.response.size * 8;
      const speedMbps = sizeBits / (1024 * 1024) / (elapsedSeconds || 1);
      resolve(speedMbps);
    };
    
    xhr.onerror = () => {
      reject(new Error('下载测速源连接失败'));
    };
    
    xhr.send();
  });
}

// ─── 上传速度测速 ──────────────────────────────────
function testUploadSpeed(onProgress) {
  const uploadUrl = 'https://httpbin.org/post';
  const bufferSize = 1 * 1024 * 1024; // 1MB 随机二进制数据
  const data = new Uint8Array(bufferSize);
  
  // 遵循 Web Crypto API 规范：单次 getRandomValues 调用限制最大字节数不超过 65536
  const chunkSize = 65536; // 64KB
  const temp = new Uint8Array(chunkSize);
  for (let offset = 0; offset < bufferSize; offset += chunkSize) {
    crypto.getRandomValues(temp);
    data.set(temp, offset);
  }
  
  const blob = new Blob([data], { type: 'application/octet-stream' });
  
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const startTime = performance.now();
    
    xhr.open('POST', uploadUrl, true);
    
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable && e.loaded > 0) {
        const now = performance.now();
        const elapsedSeconds = (now - startTime) / 1000;
        if (elapsedSeconds > 0) {
          const speedMbps = (e.loaded * 8) / (1024 * 1024) / elapsedSeconds;
          const progress = (e.loaded / e.total) * 100;
          onProgress({ speed: speedMbps, progress });
        }
      }
    };
    
    xhr.onload = () => {
      const endTime = performance.now();
      const elapsedSeconds = (endTime - startTime) / 1000;
      const speedMbps = (bufferSize * 8) / (1024 * 1024) / (elapsedSeconds || 1);
      resolve(speedMbps);
    };
    
    xhr.onerror = () => {
      reject(new Error('上传端点连接失败'));
    };
    
    xhr.send(blob);
  });
}

// ─── 仪表盘 UI 控制 ────────────────────────────────
const MAX_SPEED_CAP = 100; // 仪表盘最大表盘刻度 (100 Mbps)

function setGaugeSpeed(speed) {
  const circle = document.getElementById('gaugeCircle');
  const speedText = document.getElementById('speedText');
  if (!circle || !speedText) return;
  
  // 限制数值显示
  speedText.textContent = speed.toFixed(1);
  
  // 映射到圆环进度。
  // 圆周长是 2 * PI * r = 2 * 3.14159 * 90 ≈ 565.48
  // 仪表盘是 3/4 圆。满刻度时 dashoffset 应等于 141 (565.48 * 0.25)
  // 0 刻度时 dashoffset 应等于 565
  const percent = Math.min(speed / MAX_SPEED_CAP, 1);
  const range = 565 - 141; // 424
  const offset = 565 - (percent * range);
  
  circle.style.strokeDashoffset = offset;
}

// ─── 历史记录存储与渲染 ──────────────────────────────
async function loadHistory() {
  const data = await chrome.storage.local.get(['ipSpeedHistory']);
  const history = data.ipSpeedHistory || [];
  renderHistoryTable(history);
}

function renderHistoryTable(history) {
  const container = document.getElementById('historyList');
  if (!container) return;
  
  if (history.length === 0) {
    container.innerHTML = `<tr><td colspan="5" style="text-align:center;color:var(--text-tertiary);padding: 20px;">暂无历史测速记录 📈</td></tr>`;
    return;
  }
  
  container.innerHTML = '';
  // 只展示最近 8 条
  history.slice(0, 8).forEach(item => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${item.time}</td>
      <td style="color:var(--primary); font-weight:700;">${item.download.toFixed(1)} Mbps</td>
      <td style="color:var(--accent); font-weight:700;">${item.upload.toFixed(1)} Mbps</td>
      <td>${item.ping} ms</td>
      <td><span class="status-badge ${item.evalClass}">${item.evalLevel}</span></td>
    `;
    container.appendChild(tr);
  });
}

async function saveToHistory(download, upload, ping, jitter) {
  const evalResult = evaluateNetwork(ping, jitter, download, upload);
  const record = {
    time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    download,
    upload,
    ping,
    evalLevel: evalResult.level,
    evalClass: evalResult.class
  };
  
  const data = await chrome.storage.local.get(['ipSpeedHistory']);
  const history = data.ipSpeedHistory || [];
  history.unshift(record); // 放在头部
  
  // 限制 30 条
  const trimmed = history.slice(0, 30);
  await chrome.storage.local.set({ ipSpeedHistory: trimmed });
  renderHistoryTable(trimmed);
}

// ─── 核心测试工作流 ────────────────────────────────
let isTesting = false;

async function startNetworkDiagnostics() {
  if (isTesting) return;
  isTesting = true;
  
  const btn = document.getElementById('btnStartTest');
  const speedText = document.getElementById('speedText');
  const unitText = document.getElementById('unitText');
  const evaluationTag = document.getElementById('speedEvaluation');
  const downloadUrlInput = document.getElementById('downloadUrlInput');
  
  const pingVal = document.getElementById('pingVal');
  const jitterVal = document.getElementById('jitterVal');
  const downloadVal = document.getElementById('downloadVal');
  const uploadVal = document.getElementById('uploadVal');
  
  btn.disabled = true;
  btn.innerHTML = `<div class="loading-spinner" style="width:12px; height:12px; border-width:1.5px;"></div> 测速中...`;
  
  // 恢复状态
  evaluationTag.style.display = 'none';
  pingVal.innerHTML = `-<span class="submetric-unit">ms</span>`;
  jitterVal.innerHTML = `-<span class="submetric-unit">ms</span>`;
  downloadVal.innerHTML = `-<span class="submetric-unit">Mbps</span>`;
  uploadVal.innerHTML = `-<span class="submetric-unit">Mbps</span>`;
  setGaugeSpeed(0);
  
  // 优先采用自定义下载测速文件
  const testDownloadUrl = downloadUrlInput.value.trim() || DEFAULT_SPEED_TEST_FILE;
  // 提取测速主机地址以进行 ping 延迟测试
  let pingHost = 'https://cdnjs.cloudflare.com';
  try {
    const urlObj = new URL(testDownloadUrl);
    pingHost = `${urlObj.protocol}//${urlObj.host}`;
  } catch {}
  
  try {
    // 1. IP 探测阶段
    document.getElementById('localIpVal').textContent = '探测中...';
    document.getElementById('publicIpVal').textContent = '探测中...';
    
    const [localIp, publicIpData] = await Promise.all([
      getLocalIP(),
      getPublicIP()
    ]);
    
    document.getElementById('localIpVal').textContent = localIp;
    document.getElementById('localIpAttr').textContent = getLocalIpAttribute(localIp);
    document.getElementById('publicIpVal').textContent = publicIpData.ip;
    document.getElementById('ipCountry').textContent = publicIpData.country;
    document.getElementById('ipCity').textContent = publicIpData.city;
    document.getElementById('ipIsp').textContent = publicIpData.isp;

    // 默认将外网 IP 回填至自定义查询框，便于用户直接参考
    const customIpInput = document.getElementById('customIpInput');
    if (customIpInput && publicIpData.ip && publicIpData.ip !== '-' && !publicIpData.ip.includes('失败')) {
      customIpInput.placeholder = publicIpData.ip;
      if (!customIpInput.value) {
        customIpInput.value = publicIpData.ip;
      }
    }
    
    // 2. Ping 延迟阶段
    unitText.textContent = '测试延迟';
    const { ping, jitter } = await testPingAndJitter(pingHost);
    pingVal.innerHTML = `${ping}<span class="submetric-unit">ms</span>`;
    jitterVal.innerHTML = `${jitter}<span class="submetric-unit">ms</span>`;
    
    // 3. 下载速度测速阶段
    unitText.textContent = '下载中';
    let finalDownload = 0;
    try {
      finalDownload = await testDownloadSpeed(testDownloadUrl, (prog) => {
        setGaugeSpeed(prog.speed);
      });
      downloadVal.innerHTML = `${finalDownload.toFixed(1)}<span class="submetric-unit">Mbps</span>`;
    } catch (err) {
      showToast('下载测速失败: ' + err.message, 'error');
      downloadVal.innerHTML = `<span style="color:var(--danger)">失败</span>`;
    }
    
    // 4. 上传速度测速阶段
    unitText.textContent = '上传中';
    let finalUpload = 0;
    try {
      finalUpload = await testUploadSpeed((prog) => {
        setGaugeSpeed(prog.speed);
      });
      uploadVal.innerHTML = `${finalUpload.toFixed(1)}<span class="submetric-unit">Mbps</span>`;
    } catch (err) {
      showToast('上传测速失败: ' + err.message, 'error');
      uploadVal.innerHTML = `<span style="color:var(--danger)">失败</span>`;
    }
    
    // 5. 测速完成，进行打分
    setGaugeSpeed(finalDownload);
    unitText.textContent = 'Mbps';
    
    const evalResult = evaluateNetwork(ping, jitter, finalDownload, finalUpload);
    evaluationTag.textContent = evalResult.level;
    evaluationTag.className = `speed-state-tag ${evalResult.class}`;
    evaluationTag.style.display = 'inline-block';
    
    // 6. 保存历史
    await saveToHistory(finalDownload, finalUpload, ping, jitter);
    showToast('诊断测速完成！');
    
  } catch (e) {
    showToast('测试出错: ' + e.message, 'error');
  } finally {
    isTesting = false;
    btn.disabled = false;
    btn.innerHTML = `<span>⚡</span> 重新测速与检测`;
  }
}

// ─── 初始化页面 ──────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // 1. 挂载公共导航栏
  if (typeof createNavbar === 'function') {
    createNavbar('IP 与网速检测');
  }
  
  // 2. 初始化高级设置折叠交互
  const configHeader = document.getElementById('configHeader');
  const configBody = document.getElementById('configBody');
  const configArrow = document.getElementById('configToggleArrow');
  
  configHeader.addEventListener('click', () => {
    const isOpen = configBody.classList.toggle('open');
    configArrow.textContent = isOpen ? '▲' : '▼';
  });
  
  // 3. 绑定测试按钮
  const btnStart = document.getElementById('btnStartTest');
  btnStart.addEventListener('click', startNetworkDiagnostics);
  
  // 4. 绑定复制按钮
  document.getElementById('btnCopyLocalIp').addEventListener('click', (e) => {
    const val = document.getElementById('localIpVal').textContent;
    copyText(val, e.target);
  });
  
  document.getElementById('btnCopyPublicIp').addEventListener('click', (e) => {
    const val = document.getElementById('publicIpVal').textContent;
    copyText(val, e.target);
  });
  
  // 5. 清空历史记录
  document.getElementById('btnClearHistory').addEventListener('click', async () => {
    if (confirm('确认清空所有历史测速记录吗？')) {
      await chrome.storage.local.remove(['ipSpeedHistory']);
      renderHistoryTable([]);
      showToast('历史记录已清空');
    }
  });
  
  // 6. 加载历史数据并自动开始检测
  loadHistory();
  startNetworkDiagnostics();
  
  // 7. 挂载 AI 解读面板
  if (typeof createInlineAIPanel === 'function') {
    createInlineAIPanel(
      'aiPanelMount',
      () => {
        // 构建 AI 诊断上下文信息
        const localIp = document.getElementById('localIpVal').textContent;
        const publicIp = document.getElementById('publicIpVal').textContent;
        const country = document.getElementById('ipCountry').textContent;
        const city = document.getElementById('ipCity').textContent;
        const isp = document.getElementById('ipIsp').textContent;
        
        const ping = document.getElementById('pingVal').textContent;
        const jitter = document.getElementById('jitterVal').textContent;
        const download = document.getElementById('downloadVal').textContent;
        const upload = document.getElementById('uploadVal').textContent;
        
        return `【网络诊断信息】
- 本地内网 IP: ${localIp}
- 公网外网 IP: ${publicIp}
- 归属地: ${country} ${city}
- 运营商: ${isp}
- Ping 延迟: ${ping}
- Jitter 抖动: ${jitter}
- 下载带宽: ${download}
- 上传带宽: ${upload}`;
      },
      `你是一个资深网络工程师。请根据用户提供的网络诊断指标（内网IP、外网IP、归属地、延迟、抖动、下载与上传速度等），分析网络状况：
1. 评估当前网络品质（延迟抖动是否正常，上传下载带宽是否对称、在什么水平）。
2. 根据 IP 归属地，判断是否存在跨运营商访问、网络出口路由是否最优。
3. 给开发人员提出日常调试和网络优化的专业建议。
请用简体中文简明扼要地回复。`
    );
  }

  // 8. 绑定自定义 IP 查询模块交互
  const customIpInput = document.getElementById('customIpInput');
  const btnSearchIp = document.getElementById('btnSearchIp');
  const searchResultArea = document.getElementById('searchResultArea');
  
  async function doCustomIpSearch() {
    const ip = customIpInput.value.trim();
    if (!ip) {
      showToast('请输入有效的 IP 地址', 'error');
      return;
    }
    
    btnSearchIp.disabled = true;
    btnSearchIp.innerHTML = `<div class="loading-spinner" style="width:12px; height:12px; border-width:1.5px; margin-right: 0;"></div>`;
    
    try {
      const result = await queryCustomIP(ip);
      document.getElementById('searchIpVal').textContent = result.ip;
      document.getElementById('searchCountry').textContent = result.country;
      document.getElementById('searchCity').textContent = result.city;
      document.getElementById('searchIsp').textContent = result.isp;
      searchResultArea.style.display = 'block';
      showToast('查询成功！');
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      btnSearchIp.disabled = false;
      btnSearchIp.innerHTML = `<span>🔍</span> 查询`;
    }
  }
  
  btnSearchIp.addEventListener('click', doCustomIpSearch);
  customIpInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      doCustomIpSearch();
    }
  });
});

// ─── 自定义 IP 地理查询 ────────────────────────────────
async function queryCustomIP(ip) {
  const ipv4Regex = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/;
  const ipv6Regex = /^([\da-fA-F]{1,4}:){7}[\da-fA-F]{1,4}$/;
  
  if (!ipv4Regex.test(ip) && !ipv6Regex.test(ip)) {
    throw new Error('请输入格式正确的 IPv4 或 IPv6 地址');
  }
  
  const queryApis = [
    { 
      url: `https://freeipapi.com/api/json/${ip}`, 
      parser: (res) => ({ 
        ip: res.ipAddress || ip, 
        country: res.countryName || '-', 
        city: `${res.regionName || ''} ${res.cityName || ''}`.trim() || '-', 
        isp: '-' 
      }) 
    },
    { 
      url: `https://ipapi.co/${ip}/json/`, 
      parser: (res) => ({ 
        ip: res.ip || ip, 
        country: res.country_name || '-', 
        city: `${res.region || ''} ${res.city || ''}`.trim() || '-', 
        isp: res.org || '-' 
      }) 
    },
    {
      url: `https://opendata.baidu.com/api.php?query=${ip}&co=&resource_id=6006&oe=utf8&format=json`,
      parser: (res) => {
        if (res && res.data && res.data[0]) {
          const item = res.data[0];
          let city = '-';
          let isp = '-';
          if (item.location) {
            const parts = item.location.trim().split(/\s+/);
            city = parts[0] || '-';
            isp = parts[1] || '-';
          }
          return {
            ip: ip,
            country: '中国',
            city: city,
            isp: isp
          };
        }
        throw new Error('未解析到有效归属地信息');
      }
    },
    {
      url: `https://ipinfo.io/${ip}/json`,
      parser: (res) => {
        let isp = res.org || '-';
        if (isp.includes(' ')) {
          isp = isp.substring(isp.indexOf(' ') + 1);
        }
        return {
          ip: res.ip || ip,
          country: res.country || '-',
          city: `${res.region || ''} ${res.city || ''}`.trim() || '-',
          isp: isp
        };
      }
    }
  ];
  
  for (const api of queryApis) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);
      
      const response = await fetch(api.url, { 
        method: 'GET',
        signal: controller.signal,
        cache: 'no-store' 
      });
      clearTimeout(timeoutId);
      
      if (response.ok) {
        const json = await response.json();
        return api.parser(json);
      }
    } catch (e) {
      console.warn(`IP 查询接口请求失败: ${api.url}`, e);
    }
  }
  throw new Error('查询失败，所有备用 IP 位置解析源均未响应');
}
