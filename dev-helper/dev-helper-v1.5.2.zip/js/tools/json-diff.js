/**
 * JSON 对比工具业务逻辑（CSP 安全）
 */
(function () {
  'use strict';

  createNavbar('JSON 对比');

  const jsonInputA = document.getElementById('jsonInputA');
  const jsonInputB = document.getElementById('jsonInputB');
  const btnCompare = document.getElementById('btnCompare');
  const btnAIReview = document.getElementById('btnAIReview');
  const btnClearAll = document.getElementById('btnClearAll');
  
  const btnSampleA = document.getElementById('btnSampleA');
  const btnSampleB = document.getElementById('btnSampleB');

  const resultPanel = document.getElementById('resultPanel');
  const diffOutput = document.getElementById('diffOutput');

  const aiSummaryBox = document.getElementById('aiSummaryBox');
  const aiSummaryContent = document.getElementById('aiSummaryContent');

  // 默认示例数据
  const sampleA = {
    "name": "DevHelper",
    "version": "1.0.0",
    "status": "active",
    "features": ["format", "encode", "qrcode"],
    "settings": {
      "theme": "dark",
      "port": 8080,
      "enableAI": true
    }
  };

  const sampleB = {
    "name": "DevHelper",
    "version": "1.1.0",
    "author": "79 Online Technology",
    "features": ["format", "encode", "diff", "image-base64"],
    "settings": {
      "theme": "system",
      "port": 8080,
      "enableAI": true,
      "maxTokens": 2048
    }
  };

  // 绑定示例填充
  btnSampleA.addEventListener('click', () => {
    jsonInputA.value = JSON.stringify(sampleA, null, 2);
  });
  btnSampleB.addEventListener('click', () => {
    jsonInputB.value = JSON.stringify(sampleB, null, 2);
  });

  // 核心对比按钮
  btnCompare.addEventListener('click', () => {
    const rawA = jsonInputA.value.trim();
    const rawB = jsonInputB.value.trim();

    if (!rawA || !rawB) {
      alert('请确保两个输入框都填入了 JSON 字符串！');
      return;
    }

    let objA, objB;
    try {
      objA = JSON.parse(rawA);
    } catch (e) {
      alert('原 JSON A 语法错误，无法解析！');
      return;
    }

    try {
      objB = JSON.parse(rawB);
    } catch (e) {
      alert('新 JSON B 语法错误，无法解析！');
      return;
    }

    // 执行差异计算
    const diffHtml = generateDiffHtml(objA, objB);
    diffOutput.innerHTML = diffHtml;
    resultPanel.style.display = 'block';

    // 启用 AI 审计按钮
    btnAIReview.disabled = false;
    aiSummaryBox.style.display = 'none';
  });

  // 差异计算函数：按字段深度遍历比较
  function generateDiffHtml(objA, objB) {
    const lines = [];
    
    // 简单的扁平化与深对比算法
    function traverse(a, b, indent = 0) {
      const pad = '&nbsp;'.repeat(indent);
      
      // 判断类型
      const typeA = typeof a;
      const typeB = typeof b;

      if (a === null || b === null || typeA !== 'object' || typeB !== 'object') {
        // 基本类型对比
        if (a === b) {
          return `<span class="diff-unchanged">${pad}${formatVal(a)}</span>`;
        } else {
          return `<span class="diff-modified">${pad}- ${formatVal(a)} <br> ${pad}+ ${formatVal(b)}</span>`;
        }
      }

      // 如果都是对象
      const isArrayA = Array.isArray(a);
      const isArrayB = Array.isArray(b);

      if (isArrayA && isArrayB) {
        // 数组对比：简单处理
        const maxLen = Math.max(a.length, b.length);
        lines.push(`${pad}[`);
        for (let i = 0; i < maxLen; i++) {
          if (i >= a.length) {
            lines.push(`<span class="diff-added">${pad}&nbsp;&nbsp;+ ${formatVal(b[i])}</span>`);
          } else if (i >= b.length) {
            lines.push(`<span class="diff-removed">${pad}&nbsp;&nbsp;- ${formatVal(a[i])}</span>`);
          } else {
            if (a[i] === b[i]) {
              lines.push(`<span class="diff-unchanged">${pad}&nbsp;&nbsp;${formatVal(a[i])}</span>`);
            } else {
              lines.push(`<span class="diff-modified">${pad}&nbsp;&nbsp;- ${formatVal(a[i])} <br> ${pad}&nbsp;&nbsp;+ ${formatVal(b[i])}</span>`);
            }
          }
        }
        lines.push(`${pad}]`);
        return lines.join('<br>');
      }

      if (!isArrayA && !isArrayB) {
        // 字典对象对比
        const keys = Array.from(new Set([...Object.keys(a), ...Object.keys(b)]));
        lines.push(`${pad}{`);
        keys.forEach(key => {
          const hasA = key in a;
          const hasB = key in b;

          if (hasA && !hasB) {
            lines.push(`<span class="diff-removed">${pad}&nbsp;&nbsp;"${key}": - ${formatVal(a[key])}</span>`);
          } else if (!hasA && hasB) {
            lines.push(`<span class="diff-added">${pad}&nbsp;&nbsp;"${key}": + ${formatVal(b[key])}</span>`);
          } else {
            const valA = a[key];
            const valB = b[key];
            if (typeof valA === 'object' && valA !== null && typeof valB === 'object' && valB !== null) {
              lines.push(`${pad}&nbsp;&nbsp;"${key}":`);
              traverse(valA, valB, indent + 4);
            } else if (valA === valB) {
              lines.push(`<span class="diff-unchanged">${pad}&nbsp;&nbsp;"${key}": ${formatVal(valA)}</span>`);
            } else {
              lines.push(`<span class="diff-modified">${pad}&nbsp;&nbsp;"${key}": <br>${pad}&nbsp;&nbsp;&nbsp;&nbsp;- ${formatVal(valA)} <br>${pad}&nbsp;&nbsp;&nbsp;&nbsp;+ ${formatVal(valB)}</span>`);
            }
          }
        });
        lines.push(`${pad}}`);
        return lines.join('<br>');
      }

      // 类型不一致
      return `<span class="diff-modified">${pad}- ${formatVal(a)} (类型: ${isArrayA ? '数组' : typeA}) <br> ${pad}+ ${formatVal(b)} (类型: ${isArrayB ? '数组' : typeB})</span>`;
    }

    function formatVal(v) {
      if (typeof v === 'string') return `"${v}"`;
      if (v === null) return 'null';
      return String(v);
    }

    return traverse(objA, objB);
  }

  // 🤖 AI 智能总结差异 逻辑
  btnAIReview.addEventListener('click', () => {
    const rawA = jsonInputA.value.trim();
    const rawB = jsonInputB.value.trim();

    if (!rawA || !rawB) return;

    aiSummaryBox.style.display = 'block';
    aiSummaryContent.textContent = '正在呼叫 AI 助手，深度审计两份 JSON 的差异变化...';

    const prompt = `请帮我对比分析以下两份 JSON 的差异：
原 JSON A:
${rawA}

新 JSON B:
${rawB}

请用非常简明扼要的中文，总结出主要的差异变动（包括新增、删除和被修改的属性），并审计此次变动可能对系统接口数据造成的兼容性或风险评估（如是否包含废弃字段、是否会导致旧版调用报错等）。字数控制在 150 字内。`;

    if (window.DevHelperAI && typeof window.DevHelperAI.callAI === 'function') {
      const systemPrompt = "你是一个 JSON 数据对比审计专家。请对比给定的两份 JSON 数据并用简体中文分段总结主要变动及兼容性风险。";
      window.DevHelperAI.callAI(systemPrompt, prompt, (chunk) => {
        aiSummaryContent.innerHTML = formatMarkdown(chunk);
      });
    } else {
      aiSummaryContent.textContent = '错误：DevHelperAI 服务未正常挂载，请重新加载扩展。';
    }
  });

  // 简单的 Markdown 换行及代码高亮格式化
  function formatMarkdown(text) {
    return text
      .replace(/\n/g, '<br>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/`(.*?)`/g, '<code style="background:rgba(0,0,0,0.06);padding:2px 4px;border-radius:3px;">$1</code>');
  }

  // 清空全部
  btnClearAll.addEventListener('click', () => {
    jsonInputA.value = '';
    jsonInputB.value = '';
    diffOutput.innerHTML = '';
    resultPanel.style.display = 'none';
    aiSummaryBox.style.display = 'none';
    btnAIReview.disabled = true;
  });

  createInlineAIPanel(
    'aiPanelMount',
    () => {
      const a = jsonInputA.value.trim();
      const b = jsonInputB.value.trim();
      if (!a || !b) return '';
      return `JSON A:\n${a}\n\nJSON B:\n${b}`;
    },
    'You are a senior data architect. Compare the two JSON inputs: summarize the schema changes, analyze API backward compatibility risks, detect security/privacy issues (e.g. exposed credentials), and provide best practices for versioning. Reply in Chinese.'
  );
})();
