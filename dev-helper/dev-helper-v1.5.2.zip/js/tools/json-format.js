/**
 * JSON 格式化工具 - 外部逻辑脚本（CSP 安全）
 * 从 pages/json-format.html 提取的内联脚本
 */

// 页面初始化（DOM 加载完后执行）
(function () {
  'use strict';

  // 创建导航栏
  createNavbar('JSON 格式化');

  let currentMode = 'format';

  // 切换模式标签
  document.querySelectorAll('[data-mode]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('[data-mode]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentMode = btn.dataset.mode;
      document.getElementById('btnProcess').textContent = btn.textContent;
    });
  });

  /** 计算 JSON 节点数 */
  function countNodes(obj, count = 0) {
    if (typeof obj === 'object' && obj !== null) {
      for (const k in obj) count = countNodes(obj[k], count + 1);
    }
    return count;
  }

  /** 执行 JSON 处理 */
  function processJSON() {
    const input = document.getElementById('inputArea').value.trim();
    const output = document.getElementById('outputArea');
    const statusDot = document.getElementById('statusDot');
    const statusText = document.getElementById('statusText');
    const sizeInfo = document.getElementById('sizeInfo');

    if (!input) { showToast('请输入 JSON 内容', 'info'); return; }

    try {
      const parsed = JSON.parse(input);
      if (currentMode === 'format') {
        const formatted = JSON.stringify(parsed, null, 2);
        output.textContent = formatted;
        sizeInfo.textContent = `${formatted.length} 字符 · ${countNodes(parsed)} 节点`;
      } else if (currentMode === 'compress') {
        const compressed = JSON.stringify(parsed);
        output.textContent = compressed;
        sizeInfo.textContent = `压缩后 ${compressed.length} 字符`;
      } else if (currentMode === 'validate') {
        output.textContent = '✅ JSON 格式合法\n\n' + JSON.stringify(parsed, null, 2);
      } else if (currentMode === 'escape') {
        output.textContent = JSON.stringify(JSON.stringify(parsed));
      }
      statusDot.className = 'status-dot ok';
      statusText.textContent = 'JSON 合法';
    } catch (err) {
      output.textContent = '';
      statusDot.className = 'status-dot err';
      statusText.textContent = err.message;
      showToast('JSON 解析失败', 'error');
    }
  }

  // 绑定按钮事件（addEventListener，CSP 安全）
  document.getElementById('btnProcess').addEventListener('click', processJSON);

  document.getElementById('btnClear').addEventListener('click', () => {
    document.getElementById('inputArea').value = '';
    document.getElementById('outputArea').textContent = '';
    document.getElementById('statusDot').className = 'status-dot';
    document.getElementById('statusText').textContent = '等待输入';
    document.getElementById('sizeInfo').textContent = '-';
  });

  document.getElementById('btnSample').addEventListener('click', () => {
    document.getElementById('inputArea').value = JSON.stringify({
      name: 'DevHelper', version: '1.1.0', author: '七九在线科技',
      tools: ['JSON格式化', '编解码', 'API调试'], ai: true, year: 2026,
    });
    processJSON();
  });

  document.getElementById('btnPaste').addEventListener('click', async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) { document.getElementById('inputArea').value = text; processJSON(); }
    } catch { showToast('无法读取剪贴板', 'error'); }
  });

  document.getElementById('btnCopy').addEventListener('click', (e) => {
    copyText(document.getElementById('outputArea').textContent, e.currentTarget);
  });

  document.getElementById('btnDownload').addEventListener('click', () => {
    const text = document.getElementById('outputArea').textContent;
    if (!text) { showToast('没有内容可下载', 'info'); return; }
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
    a.download = 'output.json';
    a.click();
    URL.revokeObjectURL(a.href);
  });

  // 实时格式化（防抖 300ms）
  let debounceTimer;
  document.getElementById('inputArea').addEventListener('input', () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      if (document.getElementById('inputArea').value.trim().length > 2) processJSON();
    }, 300);
  });

  // AI 解读面板
  createInlineAIPanel(
    'aiPanelMount',
    () => document.getElementById('outputArea').textContent || document.getElementById('inputArea').value,
    'You are a JSON data analyst. Analyze the given JSON: describe its structure and purpose, identify key fields and their data types, flag potential issues or missing fields, and note any security concerns. Reply in Chinese, concisely.'
  );

  // 兼容自动载入示例（用于生成截图）
  if (new URLSearchParams(window.location.search).get('sample') === 'true') {
    document.getElementById('inputArea').value = JSON.stringify({
      name: 'DevHelper', version: '1.1.0', author: '七九在线科技',
      tools: ['JSON格式化', '编解码', 'API调试'], ai: true, year: 2026,
    }, null, 2);
    processJSON();
  }
})();

