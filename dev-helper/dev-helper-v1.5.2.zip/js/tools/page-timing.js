/**
 * DevHelper - 页面性能检测工具
 * 功能：通过 chrome.scripting.executeScript 获取目标页面的 timing 信息并生成可视化图表与优化建议，内嵌 AI 深度诊断。
 */

// 优秀的阈值常数定义 (毫秒)
const THRESHOLDS = {
  fp: { excellent: 1000, poor: 2500 },
  fcp: { excellent: 1500, poor: 3000 },
  domReady: { excellent: 2000, poor: 4000 },
  load: { excellent: 3000, poor: 6000 }
};

// 模拟的 Mock 演示数据（供离线/无权限/预览时展示）
const MOCK_PERFORMANCE_DATA = {
  title: "七九在线科技 (79team) 官方网站 - 创新引领未来",
  url: "https://www.79team.com/home",
  userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  connection: {
    effectiveType: "4g",
    downlink: 10,
    rtt: 50
  },
  nextHopProtocol: "h2",
  decodedBodySize: 45210, // 44 KB
  redirectStart: 0,
  redirectEnd: 0,
  fetchStart: 0,
  domainLookupStart: 5,
  domainLookupEnd: 32,      // DNS 27ms
  connectStart: 32,
  connectEnd: 112,          // TCP 80ms
  secureConnectionStart: 56, // SSL 56ms (SSL 实际耗时 112-56=56ms)
  requestStart: 115,
  responseStart: 420,       // TTFB 305ms
  responseEnd: 465,         // HTML 下载 45ms
  domInteractive: 950,      // DOM 解析 485ms
  domContentLoadedEventStart: 1100,
  domContentLoadedEventEnd: 1180, // DOMContentLoaded 相对 fetchStart 1180ms
  domComplete: 1850,
  loadEventStart: 1850,
  loadEventEnd: 2150,       // onLoad 相对 fetchStart 2150ms
  firstPaint: 435,          // FP 435ms
  firstContentfulPaint: 950, // FCP 950ms
  memory: {
    usedJSHeapSize: 28500000,
    totalJSHeapSize: 42300000,
    jsHeapSizeLimit: 2170000000
  },
  metaHeaders: [
    { name: "Content-Security-Policy", content: "default-src 'self'" }
  ]
};

document.addEventListener('DOMContentLoaded', async () => {
  // 1. 初始化导航栏
  if (typeof createNavbar === 'function') {
    createNavbar('页面性能检测');
  }

  // 2. 绑定事件
  const btnDetect = document.getElementById('btnDetect');
  const btnDetectTrigger = document.getElementById('btnDetectTrigger');

  if (btnDetect) {
    btnDetect.addEventListener('click', startDetection);
  }
  if (btnDetectTrigger) {
    btnDetectTrigger.addEventListener('click', startDetection);
  }

  // 3. 自动探测并尝试执行一次检测
  await tryAutoDetect();
});

/**
 * 自动探测目标页面并开始检测
 */
async function tryAutoDetect() {
  const urlParams = new URLSearchParams(window.location.search);
  let tabId = parseInt(urlParams.get('tabId'), 10);

  if (tabId) {
    await performDetection(tabId);
    return;
  }

  // 如果没有 URL 参数，查找当前活跃的普通 Tab
  if (typeof chrome !== 'undefined' && chrome.tabs) {
    try {
      const targetTab = await findTargetTab();
      if (targetTab && targetTab.id) {
        await performDetection(targetTab.id);
        return;
      }
    } catch (e) {
      console.log('自动探测标签页失败，使用 Mock 数据展示', e);
    }
  }

  // 如果找不到（例如在纯浏览器中打开），显示 Mock 数据演示
  console.log('未检测到 Chrome 标签页环境，自动载入 Mock 数据进行界面演示。');
  renderResults(MOCK_PERFORMANCE_DATA);
}

/**
 * 查找适合被检测的活跃或最前排 Tab
 */
async function findTargetTab() {
  const tabs = await chrome.tabs.query({ currentWindow: true });
  const validTabs = tabs.filter(t => 
    t.url && 
    !t.url.startsWith('chrome') && 
    !t.url.startsWith('about') && 
    !t.url.startsWith('file') && 
    !t.url.startsWith('chrome-extension')
  );
  
  // 优先选择最近活跃的普通网页
  const activeTab = validTabs.find(t => t.active);
  return activeTab || validTabs[0];
}

/**
 * 开始检测动作处理器
 */
async function startDetection() {
  if (typeof chrome === 'undefined' || !chrome.tabs) {
    showToast('当前非 Chrome 扩展运行环境，载入演示数据', 'info');
    renderResults(MOCK_PERFORMANCE_DATA);
    return;
  }

  try {
    const targetTab = await findTargetTab();
    if (!targetTab) {
      showToast('未找到可检测的网页标签页', 'error');
      return;
    }
    await performDetection(targetTab.id);
  } catch (e) {
    showToast('检测失败: ' + e.message, 'error');
  }
}

/**
 * 执行具体检测逻辑
 */
async function performDetection(tabId) {
  if (typeof showToast === 'function') {
    showToast('正在向网页注入分析内核，请稍候...', 'info', 1500);
  }

  try {
    // 注入脚本以提取性能元数据
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: getPagePerformanceMetrics
    });

    if (results && results[0] && results[0].result) {
      const data = results[0].result;
      if (data.success) {
        renderResults(data.data);
        if (typeof showToast === 'function') {
          showToast('页面性能数据采集成功！', 'success');
        }
      } else {
        throw new Error(data.error);
      }
    } else {
      throw new Error('未接收到分析内核返回的性能参数');
    }
  } catch (e) {
    console.error('检测失败，载入 Mock 数据兜底展示', e);
    if (typeof showToast === 'function') {
      showToast('检测失败（可能是系统或权限限制），已载入 Mock 演示数据', 'error', 4000);
    }
    renderResults(MOCK_PERFORMANCE_DATA);
  }
}

/**
 * 被注入目标页面的性能数据抓取脚本（运行在 Content Page 环境下）
 */
function getPagePerformanceMetrics() {
  try {
    const t = {};
    const timing = performance.timing;
    const navEntries = performance.getEntriesByType('navigation');
    const paintEntries = performance.getEntriesByType('paint');
    
    t.title = document.title || "未知页面";
    t.url = location.href;
    t.userAgent = navigator.userAgent;
    t.connection = navigator.connection ? {
      effectiveType: navigator.connection.effectiveType,
      downlink: navigator.connection.downlink,
      rtt: navigator.connection.rtt
    } : null;
    
    let base = 0;
    if (navEntries && navEntries.length > 0) {
      const entry = navEntries[0];
      t.redirectStart = entry.redirectStart;
      t.redirectEnd = entry.redirectEnd;
      t.fetchStart = entry.fetchStart;
      t.domainLookupStart = entry.domainLookupStart;
      t.domainLookupEnd = entry.domainLookupEnd;
      t.connectStart = entry.connectStart;
      t.connectEnd = entry.connectEnd;
      t.secureConnectionStart = entry.secureConnectionStart;
      t.requestStart = entry.requestStart;
      t.responseStart = entry.responseStart;
      t.responseEnd = entry.responseEnd;
      t.domInteractive = entry.domInteractive;
      t.domContentLoadedEventStart = entry.domContentLoadedEventStart;
      t.domContentLoadedEventEnd = entry.domContentLoadedEventEnd;
      t.domComplete = entry.domComplete;
      t.loadEventStart = entry.loadEventStart;
      t.loadEventEnd = entry.loadEventEnd;
      t.nextHopProtocol = entry.nextHopProtocol || '';
      t.decodedBodySize = entry.decodedBodySize || 0;
    } else if (timing) {
      // 降级使用 navigationStart 偏移行程相对数据
      base = timing.navigationStart;
      t.redirectStart = timing.redirectStart ? timing.redirectStart - base : 0;
      t.redirectEnd = timing.redirectEnd ? timing.redirectEnd - base : 0;
      t.fetchStart = timing.fetchStart - base;
      t.domainLookupStart = timing.domainLookupStart - base;
      t.domainLookupEnd = timing.domainLookupEnd - base;
      t.connectStart = timing.connectStart - base;
      t.connectEnd = timing.connectEnd - base;
      t.secureConnectionStart = timing.secureConnectionStart ? timing.secureConnectionStart - base : 0;
      t.requestStart = timing.requestStart - base;
      t.responseStart = timing.responseStart - base;
      t.responseEnd = timing.responseEnd - base;
      t.domInteractive = timing.domInteractive - base;
      t.domContentLoadedEventStart = timing.domContentLoadedEventStart - base;
      t.domContentLoadedEventEnd = timing.domContentLoadedEventEnd - base;
      t.domComplete = timing.domComplete - base;
      t.loadEventStart = timing.loadEventStart - base;
      t.loadEventEnd = timing.loadEventEnd - base;
      t.nextHopProtocol = '';
      t.decodedBodySize = 0;
    }
    
    // FP & FCP
    t.firstPaint = 0;
    t.firstContentfulPaint = 0;
    if (paintEntries) {
      paintEntries.forEach(e => {
        if (e.name === 'first-paint') t.firstPaint = e.startTime;
        if (e.name === 'first-contentful-paint') t.firstContentfulPaint = e.startTime;
      });
    }
    
    // JS 内存状况
    if (performance.memory) {
      t.memory = {
        usedJSHeapSize: performance.memory.usedJSHeapSize,
        totalJSHeapSize: performance.memory.totalJSHeapSize,
        jsHeapSizeLimit: performance.memory.jsHeapSizeLimit
      };
    }
    
    // Meta 头探测
    const metas = [];
    document.querySelectorAll('meta').forEach(m => {
      const httpEquiv = m.getAttribute('http-equiv');
      const name = m.getAttribute('name');
      if (httpEquiv) {
        metas.push({ name: httpEquiv, content: m.getAttribute('content') });
      } else if (name && (name.includes('security') || name.includes('csp'))) {
        metas.push({ name: name, content: m.getAttribute('content') });
      }
    });
    t.metaHeaders = metas;
    
    return { success: true, data: t };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

/**
 * 根据抓取的性能指标进行分值判定与界面渲染
 */
function renderResults(data) {
  // 隐藏提示区，展示结果区
  document.getElementById('detectInitialState').style.display = 'none';
  document.getElementById('detectResultContainer').style.display = 'flex';

  // 1. 渲染元数据
  document.getElementById('metaTitle').textContent = data.title;
  document.getElementById('metaUrl').textContent = data.url;
  document.getElementById('metaProtocol').textContent = (data.nextHopProtocol || 'unknown').toUpperCase();
  
  const network = data.connection;
  document.getElementById('metaNetwork').textContent = network 
    ? `${network.effectiveType.toUpperCase()} / RTT: ${network.rtt}ms / 下行: ${network.downlink}Mbps`
    : '未知网络';

  const memory = data.memory;
  document.getElementById('metaMemory').textContent = memory 
    ? `${(memory.usedJSHeapSize / 1024 / 1024).toFixed(1)} MB / 总额 ${(memory.totalJSHeapSize / 1024 / 1024).toFixed(1)} MB`
    : '不支持内存检测';

  // 2. 渲染核心指标环状图组件
  // 算值百分比打分逻辑
  const calcScore = (value, excellent, poor) => {
    if (value <= excellent) return 100;
    if (value >= poor) return 30;
    return Math.round(100 - ((value - excellent) / (poor - excellent)) * 70);
  };

  const updateRing = (idPrefix, value, thresh) => {
    const circle = document.getElementById(`circle` + idPrefix);
    const textVal = document.getElementById(`value` + idPrefix);
    const badge = document.getElementById(`badge` + idPrefix);

    const valMs = Math.round(value);
    textVal.innerHTML = `${valMs}<span class="metric-unit">ms</span>`;

    const score = calcScore(valMs, thresh.excellent, thresh.poor);
    
    // 半径42的圆周长约为263.89
    const circumference = 263.89;
    const offset = circumference - (score / 100) * circumference;
    circle.style.strokeDasharray = `${circumference} ${circumference}`;
    circle.style.strokeDashoffset = offset;

    // 清除状态类
    circle.className.baseVal = 'progress-circle';
    badge.className = 'metric-badge';

    if (valMs <= thresh.excellent) {
      circle.classList.add('progress-excellent');
      badge.classList.add('badge-excellent');
      badge.textContent = '优秀';
    } else if (valMs >= thresh.poor) {
      circle.classList.add('progress-poor');
      badge.classList.add('badge-poor');
      badge.textContent = '较差';
    } else {
      circle.classList.add('progress-warning');
      badge.classList.add('badge-warning');
      badge.textContent = '一般';
    }
  };

  updateRing('FP', data.firstPaint || (data.responseStart - data.fetchStart), THRESHOLDS.fp);
  updateRing('FCP', data.firstContentfulPaint || (data.responseStart - data.fetchStart), THRESHOLDS.fcp);
  updateRing('DomReady', data.domContentLoadedEventEnd - data.fetchStart, THRESHOLDS.domReady);
  updateRing('Load', data.loadEventEnd || data.domComplete || data.responseEnd, THRESHOLDS.load);

  // 3. 渲染网络加载时序瀑布图
  const totalDuration = Math.max(
    data.loadEventEnd || data.domComplete || data.responseEnd,
    100
  );

  const drawBar = (barId, valId, start, end, label) => {
    const bar = document.getElementById(barId);
    const valueEl = document.getElementById(valId);
    const duration = Math.max(end - start, 0);

    const leftPercent = (start / totalDuration) * 100;
    const widthPercent = (duration / totalDuration) * 100;

    bar.style.left = `${leftPercent}%`;
    bar.style.width = `${widthPercent}%`;
    bar.textContent = duration > 15 ? `${Math.round(duration)}ms` : '';
    valueEl.textContent = `${Math.round(duration)} ms`;
  };

  // 分别绘制时序各行
  // 重定向
  drawBar('barRedirect', 'valRedirect', data.redirectStart, data.redirectEnd);
  // DNS 查询
  drawBar('barDns', 'valDns', data.domainLookupStart, data.domainLookupEnd);
  // TCP 握手
  drawBar('barTcp', 'valTcp', data.connectStart, data.connectEnd);
  // SSL 安全建连 (HTTPS 独享)
  if (data.secureConnectionStart > 0) {
    document.getElementById('rowSsl').style.display = 'flex';
    drawBar('barSsl', 'valSsl', data.secureConnectionStart, data.connectEnd);
  } else {
    document.getElementById('rowSsl').style.display = 'none';
  }
  // TTFB
  drawBar('barTtfb', 'valTtfb', data.requestStart, data.responseStart);
  // HTML 下载
  drawBar('barDownload', 'valDownload', data.responseStart, data.responseEnd);
  // DOM 交互解析
  drawBar('barDom', 'valDom', data.responseEnd, data.domInteractive);
  // Dom Ready
  drawBar('barDomready', 'valDomready', data.fetchStart, data.domContentLoadedEventEnd);
  // onLoad
  drawBar('barLoad', 'valLoad', data.fetchStart, data.loadEventEnd || data.domComplete);

  // 绘制底部刻度线尺
  renderRuler(totalDuration);

  // 4. 动态分析得出调优诊断清单
  generateSuggestions(data);

  // 5. 挂载 AI 解读挂件
  setupAIService(data);
}

/**
 * 渲染瀑布图底部刻度尺轴线
 */
function renderRuler(totalDuration) {
  const ruler = document.getElementById('rulerContainer');
  ruler.innerHTML = '';
  const numTicks = 6;
  for (let i = 0; i < numTicks; i++) {
    const ratio = i / (numTicks - 1);
    const timeMs = Math.round(ratio * totalDuration);
    const tick = document.createElement('div');
    tick.className = 'ruler-tick';
    tick.style.left = `${ratio * 100}%`;
    tick.textContent = `${timeMs}ms`;
    ruler.appendChild(tick);
  }
}

/**
 * 生成调优诊断建议 HTML 列表
 */
function generateSuggestions(data) {
  const list = document.getElementById('suggestionList');
  list.innerHTML = '';

  const suggestions = [];

  // DNS 判定
  const dnsTime = data.domainLookupEnd - data.domainLookupStart;
  if (dnsTime > 50) {
    suggestions.push({
      status: dnsTime > 150 ? 'poor' : 'warning',
      title: `DNS 解析延迟较高 (${Math.round(dnsTime)}ms)`,
      desc: '当前域名解析消耗时间偏长。建议在 HTML 头部配置 <code>&lt;link rel="dns-prefetch" href="..."&gt;</code> 预解析核心服务及第三方 API 域名，或者改用具有高 SLA 边缘节点代理的云厂商 DNS 解析服务。'
    });
  } else {
    suggestions.push({
      status: 'excellent',
      title: 'DNS 解析状况良好',
      desc: '域名解析速度在推荐范围 (50ms) 内，网络寻址未成为性能瓶颈。'
    });
  }

  // TCP & SSL 判定
  const tcpTime = data.connectEnd - data.connectStart;
  if (tcpTime > 120) {
    suggestions.push({
      status: tcpTime > 300 ? 'poor' : 'warning',
      title: `TCP 及 SSL 建连耗时高 (${Math.round(tcpTime)}ms)`,
      desc: '网络握手耗时偏高。建议优先开启 HTTP/2 或 HTTP/3 以复用 TCP 连接；此外，针对第三方接口可添加 <code>&lt;link rel="preconnect" href="..."&gt;</code> 进行提前网络握手与 SSL 安全协商。'
    });
  }

  // TTFB (首字节响应) 判定
  const ttfb = data.responseStart - data.requestStart;
  if (ttfb > 500) {
    suggestions.push({
      status: ttfb > 1500 ? 'poor' : 'warning',
      title: `关键指标 warning：TTFB 首字节响应高 (${Math.round(ttfb)}ms)`,
      desc: '服务器生成响应的时间超长。这通常是后端逻辑复杂、数据库查询慢或缺乏页面缓存机制引起的。建议优化后端计算逻辑、添加 Redis 缓存层、优化慢 SQL 查询，或在 CDN 边缘节点实现页面缓存。'
    });
  } else {
    suggestions.push({
      status: 'excellent',
      title: '服务器首字节响应 (TTFB) 优秀',
      desc: '服务器响应非常迅速，这代表您的后端计算性能及服务出口网络情况均极为优秀。'
    });
  }

  // DOM 阻塞判定
  const domParse = data.domInteractive - data.responseEnd;
  if (domParse > 1200) {
    suggestions.push({
      status: 'poor',
      title: `DOM 树解析及首屏渲染阻塞 (${Math.round(domParse)}ms)`,
      desc: 'DOM 解析缓慢。请排查是否在头部引入了过多的同步阻塞式外部 Javascript 脚本（建议使用 <code>async</code> 或 <code>defer</code> 延迟加载），并减少页面中首屏呈现无关的大体积 CSS 文件。'
    });
  }

  // 内存泄漏判定
  if (data.memory) {
    const heapRatio = data.memory.usedJSHeapSize / data.memory.jsHeapSizeLimit;
    if (heapRatio > 0.6) {
      suggestions.push({
        status: 'poor',
        title: 'JS 内存占用率偏高',
        desc: '页面占用了过高的 JS 堆限额，可能存在内存泄露。推荐使用 Chrome DevTools 的 Performance 面板记录 Timeline 运行曲线，审查全局未回收监听器、大闭包对象以及未清除的定时器。'
      });
    }
  }

  // XSS / 点击劫持等安全响应自查
  const hasCsp = data.metaHeaders && data.metaHeaders.some(h => h.name.toLowerCase() === 'content-security-policy');
  if (!hasCsp) {
    suggestions.push({
      status: 'warning',
      title: '检测到缺失内容安全策略 (CSP)',
      desc: '页面 Meta 标签中未设置 <code>Content-Security-Policy</code>。虽然可能已经在 HTTP 响应头中发送，但若没有，建议添加 CSP 策略防范跨站脚本 (XSS) 注入及恶意脚本执行。'
    });
  }

  // 渲染 DOM
  suggestions.forEach(s => {
    const item = document.createElement('div');
    item.className = `suggestion-item ${s.status}`;
    
    let icon = '💡';
    if (s.status === 'excellent') icon = '✅';
    if (s.status === 'warning') icon = '⚠️';
    if (s.status === 'poor') icon = '❌';

    item.innerHTML = `
      <div class="suggestion-icon">${icon}</div>
      <div class="suggestion-content">
        <div class="suggestion-title">${s.title}</div>
        <div class="suggestion-desc">${s.desc}</div>
      </div>
    `;
    list.appendChild(item);
  });
}

/**
 * 挂载并配置 AI 解读面板功能
 */
function setupAIService(data) {
  const mount = document.getElementById('aiPanelMount');
  mount.innerHTML = ''; // 清空

  const systemPrompt = `你是一位资深的 Web 前端架构与性能调优专家。
请根据用户提供的页面网络加载性能指标数据 (JSON) 进行极其深度的专业解读。
数据详情：
- 被检测网页: "${data.title}" (${data.url})
- 协议: ${data.nextHopProtocol || '未知'}
- DNS耗时: ${data.domainLookupEnd - data.domainLookupStart}ms
- TCP耗时: ${data.connectEnd - data.connectStart}ms
- TTFB耗时: ${data.responseStart - data.requestStart}ms
- DOMContentLoaded耗时: ${data.domContentLoadedEventEnd - data.fetchStart}ms
- onload耗时: ${(data.loadEventEnd || data.domComplete || data.responseEnd) - data.fetchStart}ms
- 白屏时间 (FP): ${data.firstPaint || (data.responseStart - data.fetchStart)}ms
- FCP耗时: ${data.firstContentfulPaint || (data.responseStart - data.fetchStart)}ms

要求：
1. 找出最严重的前两个性能瓶颈，给出技术定位原因。
2. 给出切实可行、立竿见影的代码级或服务器级调优方案（提供如 Nginx 缓存、预链接 preconnect、Brotli 压缩、CSS/JS 异步等对应配置示例）。
3. 务必使用简体中文进行回答，若有英文术语或原代码，提供双语对照形式展示。`;

  const getContext = () => {
    return JSON.stringify({
      title: data.title,
      url: data.url,
      metrics: {
        dns: data.domainLookupEnd - data.domainLookupStart,
        tcp: data.connectEnd - data.connectStart,
        ssl: data.secureConnectionStart > 0 ? (data.connectEnd - data.secureConnectionStart) : 0,
        ttfb: data.responseStart - data.requestStart,
        download: data.responseEnd - data.responseStart,
        domParse: data.domInteractive - data.responseEnd,
        domReady: data.domContentLoadedEventEnd - data.fetchStart,
        onload: (data.loadEventEnd || data.domComplete || data.responseEnd) - data.fetchStart,
        fp: data.firstPaint || (data.responseStart - data.fetchStart),
        fcp: data.firstContentfulPaint || (data.responseStart - data.fetchStart)
      },
      nextHopProtocol: data.nextHopProtocol,
      decodedBodySize: data.decodedBodySize
    }, null, 2);
  };

  if (typeof createInlineAIPanel === 'function') {
    createInlineAIPanel('aiPanelMount', getContext, systemPrompt);
  }
}
