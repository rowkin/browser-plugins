/**
 * 密码生成器 - 外部逻辑脚本（CSP 安全）
 */
(function () {
  'use strict';

  createNavbar('密码生成器');

  const opts = { digits: true, lower: true, upper: true, symbols: false, excludeSimilar: false };
  const charSets = {
    digits: '0123456789',
    lower: 'abcdefghijklmnopqrstuvwxyz',
    upper: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    symbols: '!@#$%^&*()_+-=[]{}|;:,.<>?',
  };
  const similar = 'il1Lo0O';

  // 切换开关
  document.querySelectorAll('[data-key]').forEach(el => {
    el.addEventListener('click', () => {
      const key = el.dataset.key;
      opts[key] = !opts[key];
      el.classList.toggle('on', opts[key]);
    });
  });

  const lengthRange = document.getElementById('lengthRange');
  const lengthNum = document.getElementById('lengthNum');
  lengthRange.addEventListener('input', () => { lengthNum.textContent = lengthRange.value; });

  function buildCharSet() {
    let chars = '';
    if (opts.digits) chars += charSets.digits;
    if (opts.lower) chars += charSets.lower;
    if (opts.upper) chars += charSets.upper;
    if (opts.symbols) chars += charSets.symbols;
    if (opts.excludeSimilar) chars = chars.split('').filter(c => !similar.includes(c)).join('');
    return chars;
  }

  function genPassword(len) {
    const chars = buildCharSet();
    if (!chars) { showToast('请至少选择一种字符类型', 'info'); return ''; }
    const arr = new Uint32Array(len);
    crypto.getRandomValues(arr);
    return Array.from(arr, v => chars[v % chars.length]).join('');
  }

  function calcStrength(pw) {
    let score = 0;
    if (pw.length >= 8) score++;
    if (pw.length >= 12) score++;
    if (pw.length >= 20) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[a-z]/.test(pw)) score++;
    if (/[A-Z]/.test(pw)) score++;
    if (/[^a-zA-Z0-9]/.test(pw)) score++;
    const levels = [
      ['极弱', '#ef4444', '10%'],
      ['弱', '#f97316', '25%'],
      ['一般', '#eab308', '50%'],
      ['强', '#22c55e', '75%'],
      ['非常强', '#10b981', '100%'],
    ];
    return levels[Math.min(4, Math.floor(score / 1.4))];
  }

  // 当前生成的所有密码数组，用于一键复制全部功能
  let currentPasswords = [];

  function generate() {
    const len = parseInt(lengthRange.value);
    const count = Math.min(20, parseInt(document.getElementById('countInput').value) || 1);
    const list = document.getElementById('pwList');
    list.innerHTML = '';
    let lastPw = '';
    currentPasswords = [];

    for (let i = 0; i < count; i++) {
      const pw = genPassword(len);
      if (!pw) return;
      lastPw = pw;
      currentPasswords.push(pw);

      const div = document.createElement('div');
      div.className = 'pw-display';
      const span = document.createElement('span');
      span.className = 'pw-text';
      span.textContent = pw;
      const copyBtn = document.createElement('button');
      copyBtn.className = 'btn btn-ghost btn-sm btn-icon';
      copyBtn.title = '复制';
      copyBtn.innerHTML = '<svg viewBox="0 0 20 20" fill="currentColor"><path d="M8 3a1 1 0 011-1h2a1 1 0 110 2H9a1 1 0 01-1-1z"/><path d="M6 3a2 2 0 00-2 2v11a2 2 0 002 2h8a2 2 0 002-2V5a2 2 0 00-2-2 3 3 0 01-3 3H9a3 3 0 01-3-3z"/></svg>';
      copyBtn.addEventListener('click', e => copyText(pw, e.currentTarget));
      div.appendChild(span);
      div.appendChild(copyBtn);
      list.appendChild(div);
    }

    // 动态控制“复制全部”按钮的显示与隐藏：只有在生成多条密码时才展示
    const btnCopyAll = document.getElementById('btnCopyAll');
    if (btnCopyAll) {
      btnCopyAll.style.display = currentPasswords.length > 1 ? 'inline-block' : 'none';
    }

    if (lastPw) {
      const [label, color, width] = calcStrength(lastPw);
      document.getElementById('strengthFill').style.cssText = `width:${width};background:${color};transition:all .4s`;
      document.getElementById('strengthLabel').textContent = label;
      document.getElementById('strengthLabel').style.color = color;
    }
  }

  document.getElementById('btnGenerate').addEventListener('click', generate);

  // 一键复制全部生成的密码
  document.getElementById('btnCopyAll').addEventListener('click', (e) => {
    if (currentPasswords.length > 0) {
      copyText(currentPasswords.join('\n'), e.currentTarget);
    }
  });

  generate(); // 初始生成

  createInlineAIPanel(
    'aiPanelMount',
    () => {
      const pw = document.querySelector('.pw-text')?.textContent || '';
      return `密码: ${pw}\n长度: ${lengthRange.value}\n配置: 数字=${opts.digits} 小写=${opts.lower} 大写=${opts.upper} 特殊符号=${opts.symbols}`;
    },
    'You are a cybersecurity expert. Analyze this password configuration: evaluate entropy and crack time, compare to NIST guidelines, and suggest improvements for password policy. Reply in Chinese.'
  );
})();
