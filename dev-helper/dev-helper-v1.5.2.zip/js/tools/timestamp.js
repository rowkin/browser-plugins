/**
 * 时间戳转换工具 - 外部逻辑脚本（CSP 安全）
 */
(function () {
  'use strict';

  createNavbar('时间戳转换');

  let showMs = false;

  function updateNow() {
    const n = Date.now();
    document.getElementById('nowTs').textContent = showMs ? n : Math.floor(n / 1000);
    document.getElementById('nowDate').textContent = new Date(n).toLocaleString('zh-CN');
  }

  setInterval(updateNow, 1000);
  updateNow();

  document.getElementById('btnToggleMs').addEventListener('click', function () {
    showMs = !showMs;
    this.textContent = showMs ? '切换秒级' : '切换毫秒';
    updateNow();
  });

  document.getElementById('btnCopyNow').addEventListener('click', () => {
    copyText(String(document.getElementById('nowTs').textContent));
  });

  function getRelativeTime(date) {
    const diff = Date.now() - date.getTime();
    const abs = Math.abs(diff);
    const suffix = diff > 0 ? '前' : '后';
    if (abs < 60000) return `${Math.floor(abs / 1000)} 秒${suffix}`;
    if (abs < 3600000) return `${Math.floor(abs / 60000)} 分钟${suffix}`;
    if (abs < 86400000) return `${Math.floor(abs / 3600000)} 小时${suffix}`;
    return `${Math.floor(abs / 86400000)} 天${suffix}`;
  }

  document.getElementById('btnConvert1').addEventListener('click', () => {
    let ts = parseInt(document.getElementById('tsInput').value);
    if (!ts) { showToast('请输入时间戳', 'info'); return; }
    if (ts.toString().length <= 10) ts *= 1000;
    const d = new Date(ts);
    document.getElementById('r1local').textContent = d.toLocaleString('zh-CN');
    document.getElementById('r1utc').textContent = d.toUTCString();
    document.getElementById('r1iso').textContent = d.toISOString();
    document.getElementById('r1rel').textContent = getRelativeTime(d);
    document.getElementById('res1').style.display = 'grid';
  });

  // 初始化日期输入
  document.getElementById('dateInput').value = new Date().toISOString().slice(0, 16);

  document.getElementById('btnConvert2').addEventListener('click', () => {
    const val = document.getElementById('dateInput').value;
    if (!val) { showToast('请选择日期时间', 'info'); return; }
    const ms = new Date(val).getTime();
    document.getElementById('r2sec').textContent = Math.floor(ms / 1000);
    document.getElementById('r2ms').textContent = ms;
    document.getElementById('res2').style.display = 'grid';
  });

  // 点击结果项复制
  document.querySelectorAll('.result-item').forEach(el => {
    el.addEventListener('click', () => {
      const v = el.querySelector('.result-value')?.textContent;
      if (v && v !== '-') copyText(v);
    });
  });

  // 世界时区
  const zones = [
    { n: 'UTC', tz: 'UTC' },
    { n: '北京/上海', tz: 'Asia/Shanghai' },
    { n: '东京', tz: 'Asia/Tokyo' },
    { n: '伦敦', tz: 'Europe/London' },
    { n: '纽约', tz: 'America/New_York' },
    { n: '洛杉矶', tz: 'America/Los_Angeles' },
  ];
  const grid = document.getElementById('zonesGrid');
  zones.forEach(z => {
    const el = document.createElement('div');
    el.className = 'zone-item';
    el.innerHTML = `<div class="zone-name">${z.n}</div><div class="zone-time" data-tz="${z.tz}">-</div>`;
    grid.appendChild(el);
  });
  function updateZones() {
    document.querySelectorAll('[data-tz]').forEach(el => {
      el.textContent = new Date().toLocaleString('zh-CN', { timeZone: el.dataset.tz, hour12: false });
    });
  }
  setInterval(updateZones, 1000);
  updateZones();

  createInlineAIPanel(
    'aiPanelMount',
    () => {
      const ts = document.getElementById('tsInput').value;
      const local = document.getElementById('r1local')?.textContent;
      return ts ? `时间戳: ${ts}\n本地时间: ${local || '-'}\n当前时间: ${new Date().toISOString()}` : `当前时间戳: ${Date.now()}`;
    },
    'You are a time zone expert. Analyze the given timestamp, explain its meaning in different time zones, calculate the relative time, and note any anomalies. Reply in Chinese.'
  );
})();
