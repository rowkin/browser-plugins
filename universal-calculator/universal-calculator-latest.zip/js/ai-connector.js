/**
 * 万能计算器 AI 智能诊断连接层
 * 支持与 Chrome 内置 AI (Gemini Nano) 及自定义大模型 (如 Kimi, Volcano) 对接，具备多模态和参数自适应功能
 */
(function () {
  const AI_PROVIDERS = {
    BUILTIN: 'builtin',
    CUSTOM: 'custom'
  };

  /** 从本地存储中读取 AI 配置 */
  async function getAIConfig() {
    return new Promise((resolve) => {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get('aiConfig', (result) => {
          if (result.aiConfig) {
            resolve(result.aiConfig);
            return;
          }
          // 默认未配置时选用内置 AI
          resolve({
            provider: AI_PROVIDERS.BUILTIN,
            apiKey: '',
            apiUrl: '',
            model: ''
          });
        });
      } else {
        // 脱机或非插件环境默认选用内置 AI (Mock层会接管)
        resolve({
          provider: AI_PROVIDERS.BUILTIN,
          apiKey: '',
          apiUrl: '',
          model: ''
        });
      }
    });
  }

  /** 保存 AI 配置 */
  async function saveAIConfig(config) {
    return new Promise((resolve) => {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ aiConfig: config }, () => {
          resolve(true);
        });
      } else {
        // 本地环境直接存入 localStorage 作为备用
        localStorage.setItem('aiConfig', JSON.stringify(config));
        resolve(true);
      }
    });
  }

  /** 调用内置 AI */
  async function callBuiltinAI(systemPrompt, userPrompt, onChunk = null) {
    const hasAI = typeof window.ai !== 'undefined' && 
                 (typeof window.ai.languageModel !== 'undefined' || 
                  typeof window.ai.assistant !== 'undefined' || 
                  typeof window.LanguageModel !== 'undefined');

    if (!hasAI) {
      // 内置 AI 不可用时，抛出明确错误提示用户配置自定义 API，而非静默降级到 mock 数据
      throw new Error(
        (localStorage.getItem('user_lang') || 'zh') === 'en'
          ? 'Chrome built-in AI (Gemini Nano) is not available in your browser. Please click the ⚙️ gear icon in the top right header and switch to a custom OpenAI-compatible API provider.'
          : '您的浏览器不支持 Chrome 内置 AI (Gemini Nano)。请点击右上角 ⚙️ 设置图标，在 AI 配置弹窗中切换为「自定义 OpenAI 兼容接口」并填写 API Key。'
      );
    }

    let session = null;
    try {
      const options = {
        systemPrompt: systemPrompt
      };
      
      // 适配新版 window.ai.languageModel.create
      if (window.ai.languageModel && typeof window.ai.languageModel.create === 'function') {
        session = await window.ai.languageModel.create(options);
      } else if (window.ai.assistant && typeof window.ai.assistant.create === 'function') {
        session = await window.ai.assistant.create(options);
      } else if (typeof window.LanguageModel !== 'undefined' && typeof window.LanguageModel.create === 'function') {
        session = await window.LanguageModel.create(options);
      } else {
        throw new Error('未在当前浏览器检测到兼容的内置 AI 接口。');
      }

      if (onChunk && typeof session.promptStreaming === 'function') {
        const stream = session.promptStreaming(userPrompt);
        let fullText = '';
        for await (const chunk of stream) {
          fullText = chunk;
          onChunk(fullText);
        }
        session.destroy();
        return fullText;
      }

      const result = await session.prompt(userPrompt);
      if (onChunk) onChunk(result);
      session.destroy();
      return result;
    } catch (err) {
      if (session && typeof session.destroy === 'function') {
        try { session.destroy(); } catch (e) {}
      }
      throw err;
    }
  }

  /** 调用 OpenAI 兼容接口 */
  async function callOpenAI(config, systemPrompt, userPrompt, onChunk = null) {
    if (!config.apiKey) {
      throw new Error(window.i18n ? window.i18n.getMessage('btn_ai_analyze') + '失败: 请先在 AI 设置中配置 API Key' : '请先在 AI 设置中配置 API Key');
    }

    const body = {
      model: config.model || 'gpt-4o-mini',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      stream: !!onChunk,
      max_tokens: 2048
    };

    // 针对 kimi-k / o1 / o3 推理模型自适应跳过 temperature 参数
    const modelLower = (config.model || '').toLowerCase();
    const isReasoningModel = modelLower.includes('kimi-k') || modelLower.includes('o1-') || modelLower.includes('o3-') || modelLower.includes('reasoning');
    if (!isReasoningModel) {
      body.temperature = 0.7;
    }

    let url = config.apiUrl || 'https://api.openai.com/v1/chat/completions';
    if (!url.endsWith('/chat/completions') && !url.includes('/chat/completions?')) {
      url = url.replace(/\/$/, '') + '/chat/completions';
    }

    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${config.apiKey}`
    };

    const response = await fetch(url, {
      method: 'POST',
      headers: headers,
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      const errorText = await response.text();
      let errorMsg = `HTTP Error ${response.status}`;
      try {
        const errorJson = JSON.parse(errorText);
        errorMsg = errorJson.error?.message || errorMsg;
      } catch (e) {}
      throw new Error(errorMsg);
    }

    if (onChunk) {
      const reader = response.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let buffer = '';
      let fullText = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop(); // 保留未读完的半行

        for (const line of lines) {
          const cleanLine = line.trim();
          if (!cleanLine || cleanLine === 'data: [DONE]') continue;

          if (cleanLine.startsWith('data: ')) {
            try {
              const parsed = JSON.parse(cleanLine.substring(6));
              const content = parsed.choices?.[0]?.delta?.content || '';
              if (content) {
                fullText += content;
                onChunk(fullText);
              }
            } catch (e) {}
          }
        }
      }
      return fullText;
    } else {
      const parsed = await response.json();
      const text = parsed.choices?.[0]?.message?.content || '';
      return text;
    }
  }

  /** 模拟流式回复（高保真 Mock 备用，支持中英文自适应） */
  async function simulateStreamResponse(userPrompt, onChunk) {
    const currentLang = localStorage.getItem('user_lang') || 'zh';
    const isEnglish = currentLang === 'en';
    let mockReply = '';
    
    if (userPrompt.includes('BMI') || userPrompt.includes('身高') || userPrompt.includes('Height')) {
      if (isEnglish) {
        mockReply = `### 🩺 Body Mass Index (BMI) Health Analysis

Based on your physical indicators, here is a customized nutrition and lifestyle improvement guide:

#### 🥗 1. Nutrition & Calorie Control
* **Calorie Balance**: Based on your BMI metrics, we recommend focusing on a nutrient-dense, low-glycemic index diet. Maintain moderate portions.
* **Balanced Ratios**: Choose complex carbohydrates (oats, quinoa, brown rice) and lean protein (chicken breast, fish, tofu) to stabilize blood sugar and support muscle health.

#### 🏃‍♂️ 2. Exercise & Fitness Plan
* **Cardiovascular Workout**: Engage in moderate-intensity aerobic exercises (brisk walking, jogging, cycling) 3-4 times a week, 35-45 minutes per session.
* **Resistance Training**: Incorporate core strength exercises (squats, planks, push-ups) twice weekly to boost your metabolism.

#### 📅 3. Daily Habits
* Ensure 7-8 hours of quality sleep daily for hormonal balance. Stay hydrated with at least 2 liters of water daily.`;
      } else {
        mockReply = `### 🩺 BMI 身体健康指数分析

根据您计算出的体质指标，为您提供以下定制的膳食营养与生活作息改善建议：

#### 🥗 1. 膳食营养与热量控制
* **科学膳食**：基于您的 BMI 特征，建议日常饮食以少油、低糖、高膳食纤维为主，避免暴饮暴食。
* **合理配比**：主食建议采用燕麦、糙米等粗粮代替精制碳水；补充优质蛋白质（如鸡胸肉、鱼肉、蛋奶和豆制品），保证基础代谢。

#### 🏃‍♂️ 2. 规律运动锻炼计划
* **有氧燃脂**：建议每周进行 3~4 次中等强度的有氧运动（如快走、慢跑、游泳），每次持续 35~45 分钟。
* **抗阻塑形**：每周配合 2 次核心力量训练（深蹲、平板支撑、俯卧撑），以帮助维持肌肉质量。

#### 📅 3. 科学作息
* 保持每天 7~8 小时高质量睡眠，维持健康的瘦素水平；每日饮水量保持在 2000 毫升左右。`;
      }
    } else if (userPrompt.includes('还款') || userPrompt.includes('贷款') || userPrompt.includes('Mortgage') || userPrompt.includes('repayment')) {
      if (isEnglish) {
        mockReply = `### 🏠 Mortgage Amortization & Asset Allocation Advice

Based on your loan simulation data, here is the professional analysis for your repayment plan:

#### 📊 1. Comparison of Repayment Paths
* **Equal Payments (ACPI)**: The monthly payment remains constant. This option provides high predictability for monthly budgeting, ideal for steady income earners.
* **Equal Principal (ACPD)**: Principal repayments are fixed while interest decreases over time. Although early payments are higher, it significantly reduces the overall interest expense.

#### 💡 2. Financial & Prepayment Strategy
* If your investment returns cannot consistently outperform your mortgage interest rate, prepaying a portion of the loan is a low-risk option to reduce liabilities.
* We recommend keeping your total monthly debt-to-income ratio below 40% to maintain financial stability.`;
      } else {
        mockReply = `### 🏠 房贷月供推演与资产配置建议

根据您的贷款推演数据，为您提供以下科学的资金分配与还款计划参考：

#### 📊 1. 还款方式对比与分析
* **等额本息 (ACPI)**：每月还款额完全相同。适合收入平稳、需要明确每月开销预算的家庭，前期资金压力相对较小。
* **等额本金 (ACPD)**：每月本金固定，利息递减。前期月供金额最高，但随着本金减少，利息支出大幅度节省，适合前期资金充裕的家庭。

#### 💡 2. 理财与提前还贷策略
* 若家庭日常理财年化收益率无法稳健超越贷款年化利率，在资金充裕时，选择部分提前还贷是降低负债利息的有效路径。
* 建议将每月的总房贷支出控制在家庭可支配收入的 40% 以内，以确保稳健的现金流储备。`;
      }
    } else {
      if (isEnglish) {
        mockReply = `### 🧮 Mathematical Expression Explanation

Based on your calculation input, here is the basic algebraic principles applied:

#### 📝 Order of Operations
* Mathematical calculations strictly follow the standard algebraic sequence: Parentheses first, followed by exponents, multiplication and division, and finally addition and subtraction.
* All scientific trigonometric operations (sin, cos, tan) calculate in degree mode by default.

#### 🔬 Logarithmic Properties
* **Natural Logarithm (ln)** operates with the base constant $e$ ($2.71828...$), which is widely applied in compound interest models and growth trend analysis.`;
      } else {
        mockReply = `### 🧮 代数运算法则与原理解析

针对您的计算输入，为您出具以下基础代数运算逻辑科普：

#### 📝 混合运算顺序
* 数学计算严格遵循标准代数顺序：优先计算括号内的算式，其次是乘方，然后是乘除，最后计算加减。
* 科学计算器中的三角函数（sin, cos, tan）在默认状态下均基于角度制（Degrees）进行计算。

#### 🔬 自然对数与指数
* **自然对数 (ln)** 是以常数 $e$ ($2.71828...$) 为底的对数，常应用于复利利息模型、增长曲线以及物理半衰期分析中。`;
      }
    }

    if (onChunk) {
      let currentText = '';
      const chunkSize = 8;
      for (let i = 0; i < mockReply.length; i += chunkSize) {
        currentText += mockReply.slice(i, i + chunkSize);
        onChunk(currentText);
        await new Promise(r => setTimeout(r, 20));
      }
      return currentText;
    }
    return mockReply;
  }

  // 暴露给全局的通用 AI 调用函数
  const UniversalAI = {
    AI_PROVIDERS,
    getAIConfig,
    saveAIConfig,
    async callAI(systemPrompt, userPrompt, onChunk = null) {
      const config = await getAIConfig();
      const currentLang = localStorage.getItem('user_lang') || 'zh';
      const isEnglish = currentLang === 'en';
      
      const constraint = isEnglish
        ? '\n\n【Important Instruction: Please respond in English. Keep the output clean and professional.】'
        : '\n\n【重要指令：请务必使用简体中文进行回答，保持输出排版整洁专业。】';
        
      const enhancedSystem = (systemPrompt || '') + constraint;

      if (config.provider === AI_PROVIDERS.BUILTIN) {
        return callBuiltinAI(enhancedSystem, userPrompt, onChunk);
      } else {
        return callOpenAI(config, enhancedSystem, userPrompt, onChunk);
      }
    }
  };

  window.UniversalAI = UniversalAI;
})();
