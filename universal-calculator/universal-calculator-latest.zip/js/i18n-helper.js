/**
 * 万能计算器 Chrome Extension 国际化 i18n 辅助工具
 */
(function () {
  const i18n = {
    /**
     * 根据 key 获取翻译文本，支持默认回退值
     */
    getMessage(key, defaultVal = '') {
      // 优先从本地翻译字典获取（以便于在运行时动态一键切换 🌐 语言）
      const currentLang = getCurrentLanguage();
      if (LOCAL_FALLBACK_DICTS[currentLang] && LOCAL_FALLBACK_DICTS[currentLang][key]) {
        return LOCAL_FALLBACK_DICTS[currentLang][key];
      }
      if (typeof chrome !== 'undefined' && chrome.i18n) {
        const val = chrome.i18n.getMessage(key);
        if (val) return val;
      }
      return defaultVal || key;
    },

    /**
     * 自动扫描整个 DOM 树，将含有 `data-i18n` 属性的元素进行多语言翻译替换
     */
    initDOMTranslation() {
      const elements = document.querySelectorAll('[data-i18n]');
      elements.forEach((el) => {
        const key = el.getAttribute('data-i18n');
        let translation = this.getMessage(key);

        if (translation) {
          // 如果是 input 或者 textarea，可以翻译其 placeholder 属性
          if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
            el.setAttribute('placeholder', translation);
          } else {
            // 普通元素翻译内容
            el.textContent = translation;
          }
        }
      });
    }
  };

  // 获取当前的语言类别（'zh' 或 'en'），优先采用用户手动设定的 user_lang
  function getCurrentLanguage() {
    const userLang = localStorage.getItem('user_lang');
    if (userLang === 'zh' || userLang === 'en') {
      return userLang;
    }
    if (typeof chrome !== 'undefined' && chrome.i18n) {
      const uiLang = chrome.i18n.getUILanguage().toLowerCase();
      if (uiLang.startsWith('en')) return 'en';
    }
    const navLang = navigator.language.toLowerCase();
    if (navLang.startsWith('en')) return 'en';
    return 'zh';
  }

  // 为本地脱机预览（不通过插件直接双击 index/popup.html）提供的高清翻译回退字典
  const LOCAL_FALLBACK_DICTS = {
    zh: {
      "app_title": "万能计算器",
      "tab_standard": "科学计算",
      "tab_exchange": "实时汇率",
      "tab_mortgage": "房贷月供",
      "tab_unit": "单位换算",
      "tab_capital": "财务大写",
      "tab_bmi": "BMI健康",
      "calc_mode_simple": "切换科学计算",
      "calc_mode_sci": "切换常规计算",
      "btn_calculate": "计算",
      "btn_reset": "重置",
      "btn_cancel": "取消",
      "btn_save": "保存配置",
      "btn_ai_analyze": "AI 深度解析",
      "bmi_user_data_title": "用户数据",
      "bmi_gender_label": "性别",
      "bmi_gender_male": "男",
      "bmi_gender_female": "女",
      "bmi_premium_ai_title": "AI 深度解析卡片",
      "bmi_ai_card_header": "AI 运动与营养深度诊断方案",
      "ai_diagnosing": "正在解析...",
      "ai_loading_text": "AI 专家正在分析您的指标，量身定制方案中...",
      "capital_input_label": "请输入阿拉伯数字金额",
      "cny_placeholder": "请输入数字金额 (如 1234.56)...",
      "bmi_h_label": "身高",
      "bmi_w_label": "体重",
      "bmi_res_label": "您的 BMI 指数：",
      "bmi_status_label": "身体质量分级：",
      "bmi_value_label": "身体质量指数",
      "bmi_tip_1": "每周保持至少 150 分钟的中等强度运动。",
      "bmi_tip_2": "保证膳食营养均衡，多摄入天然食品、优质蛋白质及蔬菜。",
      "bmi_tip_3": "每天补充充足的水分，维持身体代谢健康。",
      "bmi_tip_4": "定期进行体检，持续监测各项身体健康指标。",
      "bmi_tip_5": "保持规律的作息，每天确保 7-8 小时的高质量睡眠。",
      "mortgage_amount_label": "贷款总额 (万元)",
      "mortgage_rate_label": "年利率 (%)",
      "mortgage_years_label": "贷款期限 (年)",
      "mortgage_type_label": "还款方式",
      "mortgage_type_interest": "等额本息 (每月还款相同)",
      "mortgage_type_principal": "等额本金 (首月多逐月递减)",
      "mortgage_result_title": "还款结果推演",
      "mortgage_month_pay": "首月月供",
      "mortgage_total_interest": "总支付利息",
      "mortgage_total_pay": "总还款额",
      "mortgage_detail_btn": "📄 查看逐期还款明细推演表",
      "mortgage_table_term": "期数",
      "mortgage_table_pay": "月供 (元)",
      "mortgage_table_principal": "本金 (元)",
      "mortgage_table_interest": "利息 (元)",
      "mortgage_table_rem_principal": "剩余本金",
      "mortgage_table_rem_interest": "剩余利息",
      "exchange_input_label": "输入金额",
      "exchange_table_title": "常用外币双向对调折算表 (以 100 人民币为基准)",
      "exchange_currency": "币种",
      "exchange_buy": "外币兑换人民币",
      "exchange_sell": "人民币兑换外币",
      "settings_title": "AI 助手配置",
      "settings_provider": "AI 服务商",
      "settings_apikey": "API Key",
      "settings_endpoint": "API 终结点 (Endpoint)",
      "settings_model": "模型名称 (Model)",
      "theme_light": "浅色模式",
      "theme_dark": "深色模式",
      "theme_auto": "跟随系统/时间",
      "unit_cat_length": "长度",
      "unit_cat_weight": "重量",
      "unit_cat_area": "面积",
      "unit_cat_volume": "体积",
      "unit_cat_temperature": "温度",
      "unit_cat_speed": "速度"
    },
    en: {
      "app_title": "Universal Calculator",
      "tab_standard": "Scientific",
      "tab_exchange": "Rates",
      "tab_mortgage": "Mortgage",
      "tab_unit": "Units",
      "tab_capital": "Capital CNY",
      "tab_bmi": "BMI Health",
      "calc_mode_simple": "Scientific Mode",
      "calc_mode_sci": "Simple Mode",
      "btn_calculate": "Calculate",
      "btn_reset": "Reset",
      "btn_cancel": "Cancel",
      "btn_save": "Save Config",
      "btn_ai_analyze": "Get AI Analysis",
      "bmi_user_data_title": "User Data",
      "bmi_gender_label": "Gender",
      "bmi_gender_male": "Male",
      "bmi_gender_female": "Female",
      "bmi_premium_ai_title": "Premium AI Output Card",
      "bmi_ai_card_header": "AI Health & Nutrition Analysis",
      "ai_diagnosing": "Analyzing...",
      "ai_loading_text": "AI expert is analyzing your metrics, customizing plans...",
      "capital_input_label": "Enter Digital Amount",
      "cny_placeholder": "Enter digital amount (e.g. 1234.56)...",
      "bmi_h_label": "Height",
      "bmi_w_label": "Weight",
      "bmi_res_label": "Your BMI Index:",
      "bmi_status_label": "Body Category:",
      "bmi_value_label": "Body Mass Index",
      "bmi_tip_1": "Maintain current physical activity: 150 min/week.",
      "bmi_tip_2": "Ensure balanced nutrition: Focus on whole foods, lean proteins, vegetables.",
      "bmi_tip_3": "Stay hydrated: Drink adequate water daily.",
      "bmi_tip_4": "Schedule regular check-ups to monitor overall wellness.",
      "bmi_tip_5": "Target a consistent sleep schedule (7-8 hours).",
      "mortgage_amount_label": "Loan Amount (10k CNY)",
      "mortgage_rate_label": "Annual Rate (%)",
      "mortgage_years_label": "Loan Term (Years)",
      "mortgage_type_label": "Repayment Type",
      "mortgage_type_interest": "Equal Payments (Principal + Interest)",
      "mortgage_type_principal": "Equal Principal (Decreasing Payments)",
      "mortgage_result_title": "Calculated Result",
      "mortgage_month_pay": "First Month Pay",
      "mortgage_total_interest": "Total Interest",
      "mortgage_total_pay": "Total Payment",
      "mortgage_detail_btn": "📄 View Amortization Schedule Table",
      "mortgage_table_term": "Term",
      "mortgage_table_pay": "Payment (CNY)",
      "mortgage_table_principal": "Principal (CNY)",
      "mortgage_table_interest": "Interest (CNY)",
      "mortgage_table_rem_principal": "Rem. Principal",
      "mortgage_table_rem_interest": "Rem. Interest",
      "exchange_input_label": "Input Amount",
      "exchange_table_title": "Foreign Currency Conversions (Based on 100 CNY)",
      "exchange_currency": "Currency",
      "exchange_buy": "FX to CNY",
      "exchange_sell": "CNY to FX",
      "settings_title": "AI Assistant Settings",
      "settings_provider": "AI Provider",
      "settings_apikey": "API Key",
      "settings_endpoint": "API Endpoint",
      "settings_model": "Model Name",
      "theme_light": "Light Theme",
      "theme_dark": "Dark Theme",
      "theme_auto": "Auto Theme",
      "unit_cat_length": "Length",
      "unit_cat_weight": "Weight",
      "unit_cat_area": "Area",
      "unit_cat_volume": "Volume",
      "unit_cat_temperature": "Temperature",
      "unit_cat_speed": "Speed"
    }
  };

  // 挂载至全局 window 对象，使各个子计算组件可以直接调用
  window.i18n = i18n;

  // ─── 纯 JS 安全数学/Markdown 解析器 ───
  window.renderInlineMarkdown = function(text) {
    if (!text) return '';

    // XSS 防御
    function esc(s) {
      return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
    
    // 提取代码块为占位符
    const codeBlocks = [];
    let r = text.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) => {
      const id = `__CODE_BLOCK_${codeBlocks.length}__`;
      codeBlocks.push(`<pre style="background:var(--bg-elevated);border:1px solid var(--border-light);border-radius:6px;padding:10px 12px;font-family:var(--mono-font,monospace);font-size:12px;overflow-x:auto;margin:8px 0;white-space:pre-wrap"><code>${esc(code.trim())}</code></pre>`);
      return id;
    });

    // 提取行内代码为占位符
    const inlineCodes = [];
    r = r.replace(/`([^\n`]+)`/g, (_, code) => {
      const id = `__INLINE_CODE_${inlineCodes.length}__`;
      inlineCodes.push(`<code style="background:var(--bg-elevated);padding:1px 5px;border-radius:3px;font-family:var(--mono-font,monospace);font-size:12px">${esc(code)}</code>`);
      return id;
    });

    // 表格流式解析
    function buildTableHtml(header, alignments, rows) {
      let tableHtml = '<div style="overflow-x:auto;margin:12px 0;"><table style="width:100%;border-collapse:collapse;font-size:13px;border:1px solid var(--border-light)">';
      tableHtml += '<thead><tr style="background:var(--bg-elevated);border-bottom:2px solid var(--border-light)">';
      header.forEach((h, idx) => {
        const align = alignments[idx] ? ` align="${alignments[idx]}"` : '';
        const alignStyle = alignments[idx] ? `text-align:${alignments[idx]};` : '';
        tableHtml += `<th${align} style="${alignStyle}padding:8px 10px;font-weight:600;border:1px solid var(--border-light)">${h}</th>`;
      });
      tableHtml += '</tr></thead><tbody>';
      rows.forEach((row, rowIdx) => {
        const bg = rowIdx % 2 === 0 ? '' : 'background:var(--bg-elevated);';
        tableHtml += `<tr style="${bg}border-bottom:1px solid var(--border-light)">`;
        for (let idx = 0; idx < header.length; idx++) {
          const cellVal = row[idx] || '';
          const align = alignments[idx] ? ` align="${alignments[idx]}"` : '';
          const alignStyle = alignments[idx] ? `text-align:${alignments[idx]};` : '';
          tableHtml += `<td${align} style="${alignStyle}padding:8px 10px;border:1px solid var(--border-light)">${cellVal}</td>`;
        }
        tableHtml += '</tr>';
      });
      tableHtml += '</tbody></table></div>';
      return tableHtml;
    }

    const lines = r.split('\n');
    const processedLines = [];
    let inTable = false;
    let tableHeader = null;
    let tableAlignments = [];
    let tableRows = [];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      const isTableRow = line.startsWith('|') && line.endsWith('|') && line.split('|').length > 2;

      if (isTableRow) {
        const cells = line.split('|').map(s => s.trim()).slice(1, -1);

        if (!inTable) {
          const nextLine = (lines[i + 1] || '').trim();
          const isDelimiterRow = nextLine.startsWith('|') && nextLine.endsWith('|') && 
                                 nextLine.replace(/[\s|:\-]/g, '') === '';
          
          if (isDelimiterRow) {
            inTable = true;
            tableHeader = cells;
            const delimCells = nextLine.split('|').map(s => s.trim()).slice(1, -1);
            tableAlignments = delimCells.map(cell => {
              if (cell.startsWith(':') && cell.endsWith(':')) return 'center';
              if (cell.endsWith(':')) return 'right';
              if (cell.startsWith(':')) return 'left';
              return '';
            });
            tableRows = [];
            i++;
            continue;
          }
        } else {
          tableRows.push(cells);
          continue;
        }
      }

      if (inTable && !isTableRow) {
        processedLines.push(buildTableHtml(tableHeader, tableAlignments, tableRows));
        inTable = false;
        tableHeader = null;
        tableAlignments = [];
        tableRows = [];
      }

      processedLines.push(lines[i]);
    }

    if (inTable) {
      processedLines.push(buildTableHtml(tableHeader, tableAlignments, tableRows));
    }

    r = processedLines.join('\n');

    // 标题解析（必须按从多到少 # 数顺序处理，防止前缀覆盖）
    r = r
      .replace(/^##### (.+)$/gm, '<h5 style="font-size:11px;font-weight:700;margin:6px 0 2px;color:var(--text-secondary)">$1</h5>')
      .replace(/^#### (.+)$/gm,  '<h4 style="font-size:12px;font-weight:700;margin:8px 0 4px;color:var(--text-secondary)">$1</h4>')
      .replace(/^### (.+)$/gm,   '<h3 style="font-size:13px;font-weight:700;margin:10px 0 4px;color:var(--text-primary)">$1</h3>')
      .replace(/^## (.+)$/gm,    '<h2 style="font-size:14px;font-weight:700;margin:12px 0 6px;color:var(--accent)">$1</h2>')
      .replace(/^# (.+)$/gm,     '<h1 style="font-size:15px;font-weight:800;margin:14px 0 8px;color:var(--accent)">$1</h1>');

    r = r.replace(/((?:^\d+\. .+\n?)+)/gm, (block) => {
      const items = block.trim().split('\n').map(l => `<li style="margin:3px 0">${l.replace(/^\d+\.\s*/, '')}</li>`).join('\n');
      return `<ol style="padding-left:20px;margin:6px 0">\n${items}\n</ol>\n`;
    });

    r = r.replace(/((?:^[-*] .+\n?)+)/gm, (block) => {
      const items = block.trim().split('\n').map(l => `<li style="margin:3px 0">${l.replace(/^[-*]\s*/, '')}</li>`).join('\n');
      return `<ul style="padding-left:20px;margin:6px 0">\n${items}\n</ul>\n`;
    });

    r = r
      .replace(/\*\*\*([^\n]+?)\*\*\*/g, '<strong><em>$1</em></strong>')
      .replace(/\*\*([^\n]+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*([^\n]+?)\*/g,  '<em>$1</em>')
      .replace(/~~([^\n]+?)~~/g,  '<del>$1</del>');

    r = r.replace(/^---$/gm, '<hr style="border:none;border-top:1px solid var(--border-light);margin:12px 0">');

    // 恢复代码块及内联代码的占位符
    for (let idx = 0; idx < inlineCodes.length; idx++) {
      r = r.replaceAll(`__INLINE_CODE_${idx}__`, inlineCodes[idx]);
    }
    for (let idx = 0; idx < codeBlocks.length; idx++) {
      r = r.replaceAll(`__CODE_BLOCK_${idx}__`, codeBlocks[idx]);
    }

    r = r.replace(/\n(?!<)/g, '<br>');
    return r;
  };
})();
