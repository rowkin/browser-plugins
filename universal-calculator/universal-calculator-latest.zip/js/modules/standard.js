/**
 * 科学计算器模块 (无 eval，完全符合 MV3 CSP 规范)
 */
(function () {
  // ─── 纯 JS 安全数学解析器实现 (Shunting-yard + RPN) ───
  function safeEvaluate(expression) {
    let expr = expression
      .replace(/×/g, '*')
      .replace(/÷/g, '/');

    // 补全括号，防止少输入括号报错
    let openBrackets = 0;
    for (let i = 0; i < expr.length; i++) {
      if (expr[i] === '(') openBrackets++;
      if (expr[i] === ')') openBrackets--;
    }
    while (openBrackets > 0) {
      expr += ')';
      openBrackets--;
    }

    // 隐式乘法自动补全
    expr = expr.replace(/(\d)(?=[a-zA-Z\(π])/g, '$1*');
    expr = expr.replace(/(π)(?=[0-9a-zA-Z\(])/g, '$1*');
    expr = expr.replace(/(e)(?=[0-9a-zA-Z\(])/g, '$1*');
    expr = expr.replace(/(\))(?=[0-9a-zA-Z\(π])/g, '$1*');

    // Tokenize
    const tokens = [];
    let i = 0;
    while (i < expr.length) {
      const c = expr[i];
      if (/\s/.test(c)) {
        i++;
        continue;
      }
      
      if (['(', ')', '+', '-', '*', '/', '%', '^'].includes(c)) {
        if (c === '-') {
          const lastToken = tokens[tokens.length - 1];
          if (tokens.length === 0 || ['+', '-', '*', '/', '%', '^', '('].includes(lastToken)) {
            tokens.push('neg');
            i++;
            continue;
          }
        }
        tokens.push(c);
        i++;
      } else if (/[0-9.]/.test(c)) {
        let numStr = '';
        while (i < expr.length && /[0-9.]/.test(expr[i])) {
          numStr += expr[i];
          i++;
        }
        tokens.push(parseFloat(numStr));
      } else if (/[a-zA-Z]/.test(c)) {
        let funcStr = '';
        while (i < expr.length && /[a-zA-Z]/.test(expr[i])) {
          funcStr += expr[i];
          i++;
        }
        tokens.push(funcStr);
      } else if (c === 'π') {
        tokens.push(Math.PI);
        i++;
      } else {
        i++;
      }
    }

    // Shunting-yard 转换逆波兰表达式
    const outputQueue = [];
    const operatorStack = [];
    const operators = {
      '+': { precedence: 2, associativity: 'Left' },
      '-': { precedence: 2, associativity: 'Left' },
      '*': { precedence: 3, associativity: 'Left' },
      '/': { precedence: 3, associativity: 'Left' },
      '%': { precedence: 3, associativity: 'Left' },
      '^': { precedence: 4, associativity: 'Right' },
      'neg': { precedence: 5, associativity: 'Right' }
    };
    const functions = ['sin', 'cos', 'tan', 'sqrt', 'log', 'ln'];

    for (const token of tokens) {
      if (typeof token === 'number') {
        outputQueue.push(token);
      } else if (functions.includes(token)) {
        operatorStack.push(token);
      } else if (token in operators) {
        const o1 = token;
        let o2 = operatorStack[operatorStack.length - 1];
        while (
          o2 &&
          (o2 in operators || functions.includes(o2)) &&
          (functions.includes(o2) ||
            (operators[o1].associativity === 'Left' && operators[o1].precedence <= operators[o2].precedence) ||
            (operators[o1].associativity === 'Right' && operators[o1].precedence < operators[o2].precedence))
        ) {
          outputQueue.push(operatorStack.pop());
          o2 = operatorStack[operatorStack.length - 1];
        }
        operatorStack.push(o1);
      } else if (token === '(') {
        operatorStack.push(token);
      } else if (token === ')') {
        let top = operatorStack[operatorStack.length - 1];
        while (top && top !== '(') {
          outputQueue.push(operatorStack.pop());
          top = operatorStack[operatorStack.length - 1];
        }
        if (!top) throw new Error('括号不匹配');
        operatorStack.pop();
        if (functions.includes(operatorStack[operatorStack.length - 1])) {
          outputQueue.push(operatorStack.pop());
        }
      }
    }

    while (operatorStack.length > 0) {
      const top = operatorStack.pop();
      if (top === '(' || top === ')') throw new Error('括号不匹配');
      outputQueue.push(top);
    }

    // RPN 求值
    const stack = [];
    const mathFuncs = {
      'sin': (x) => Math.sin(x * Math.PI / 180),
      'cos': (x) => Math.cos(x * Math.PI / 180),
      'tan': (x) => Math.tan(x * Math.PI / 180),
      'sqrt': (x) => {
        if (x < 0) throw new Error('负数不能求平方根');
        return Math.sqrt(x);
      },
      'log': (x) => {
        if (x <= 0) throw new Error('对数自变量必须大于0');
        return Math.log10(x);
      },
      'ln': (x) => {
        if (x <= 0) throw new Error('对数自变量必须大于0');
        return Math.log(x);
      }
    };

    for (const token of outputQueue) {
      if (typeof token === 'number') {
        stack.push(token);
      } else if (token === 'neg') {
        const x = stack.pop();
        if (x === undefined) throw new Error('表达式不完整');
        stack.push(-x);
      } else if (token in mathFuncs) {
        const x = stack.pop();
        if (x === undefined) throw new Error('表达式不完整');
        stack.push(mathFuncs[token](x));
      } else {
        const b = stack.pop();
        const a = stack.pop();
        if (a === undefined || b === undefined) throw new Error('表达式不完整');
        switch (token) {
          case '+': stack.push(a + b); break;
          case '-': stack.push(a - b); break;
          case '*': stack.push(a * b); break;
          case '/':
            if (b === 0) throw new Error('除数不能为零');
            stack.push(a / b);
            break;
          case '%': stack.push(a % b); break;
          case '^': stack.push(Math.pow(a, b)); break;
        }
      }
    }

    if (stack.length !== 1) throw new Error('语法错误');
    return stack[0];
  }

  const StandardCalc = {
    init() {
      const display = document.getElementById('calcDisplay');
      const preview = document.getElementById('calcPreview');
      const keys = document.querySelectorAll('.calc-grid button');
      let currentInput = '0';
      let hasEvaluated = false;

      function updateDisplay() {
        if (!display) return;
        display.textContent = currentInput;
        
        // 实时尝试解析和预览计算结果
        if (currentInput !== '0' && currentInput !== '') {
          try {
            const cleanExpr = currentInput.replace(/×/g, '*').replace(/÷/g, '/');
            const result = safeEvaluate(cleanExpr);
            if (!Number.isNaN(result) && result !== undefined && preview) {
              preview.textContent = '= ' + Number(result.toFixed(8)).toString();
            }
          } catch (e) {
            if (preview) preview.textContent = '';
          }
        } else {
          if (preview) preview.textContent = '';
        }
      }

      keys.forEach((key) => {
        key.addEventListener('click', () => {
          const action = key.getAttribute('data-action');
          const value = key.textContent;

          if (!action) {
            // 输入数字/点/括号/常数
            if (hasEvaluated) {
              currentInput = value === '.' ? '0.' : value;
              hasEvaluated = false;
            } else {
              if (currentInput === '0' && value !== '.') {
                currentInput = value;
              } else {
                currentInput += value;
              }
            }
          } else {
            // 操作符及特殊按键
            switch (action) {
              case 'clear':
                currentInput = '0';
                hasEvaluated = false;
                break;
              case 'backspace':
                if (currentInput.length > 1) {
                  currentInput = currentInput.slice(0, -1);
                } else {
                  currentInput = '0';
                }
                break;
              case 'evaluate':
                try {
                  const result = safeEvaluate(currentInput);
                  if (display) {
                    // 保留有效的小数位，最长 10 位，消除浮点误差
                    const finalRes = Number(result.toFixed(10)).toString();
                    currentInput = finalRes;
                    hasEvaluated = true;
                    if (preview) preview.textContent = '';
                  }
                } catch (err) {
                  if (display) {
                    display.textContent = 'Error';
                    setTimeout(() => {
                      updateDisplay();
                    }, 1200);
                  }
                }
                return;
              case 'neg':
                if (currentInput.startsWith('-')) {
                  currentInput = currentInput.slice(1);
                } else if (currentInput !== '0') {
                  currentInput = '-' + currentInput;
                }
                break;
              default:
                // 科学函数或运算符 (sin(, cos(, tan(, log(, ln(, sqrt(, ^, %, +, -, *, /)
                if (hasEvaluated) {
                  hasEvaluated = false;
                }
                if (['+', '-', '×', '÷', '^', '%'].includes(value)) {
                  currentInput += ' ' + value + ' ';
                } else {
                  currentInput += value; // 函数本身自带左括号，如 sin(
                }
                break;
            }
          }
          updateDisplay();
        });
      });

      // 初始化显示
      updateDisplay();
    }
  };

  window.StandardCalc = StandardCalc;
})();
