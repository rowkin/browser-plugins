/**
 * 万能计算器 Popup 主控制脚本
 */
document.addEventListener('DOMContentLoaded', async () => {
  // ─── 1. 初始化中英文语言状态与 DOM 翻译 ───
  let currentLang = localStorage.getItem('user_lang');
  if (!currentLang) {
    // 默认获取系统或插件语言
    currentLang = (typeof chrome !== 'undefined' && chrome.i18n && chrome.i18n.getUILanguage().toLowerCase().startsWith('en')) ? 'en' : 'zh';
    localStorage.setItem('user_lang', currentLang);
  }
  
  // 翻译页面
  window.i18n.initDOMTranslation();
  updateLangButtonUI();

  // 初始化主题模式与计算器简化/科学模式
  applyTheme();
  updateCalcModeUI();

  // 语言一键切换 🌐
  const btnToggleLang = document.getElementById('btnToggleLang');
  if (btnToggleLang) {
    btnToggleLang.addEventListener('click', () => {
      currentLang = currentLang === 'zh' ? 'en' : 'zh';
      localStorage.setItem('user_lang', currentLang);
      
      // 重新翻译整个 DOM
      window.i18n.initDOMTranslation();
      updateLangButtonUI();
      applyTheme();
      updateCalcModeUI();

      // 触发各模块因语言改变而需要的局部重绘
      if (window.ExchangeRate && typeof window.ExchangeRate.init === 'function') {
        window.ExchangeRate.init();
      }
      if (window.UnitConverter && typeof window.UnitConverter.renderGrid === 'function') {
        window.UnitConverter.renderGrid();
      }
      if (window.Mortgage && typeof window.Mortgage.calculate === 'function') {
        const tbody = document.getElementById('loanResultBody');
        if (tbody && tbody.children.length > 0) {
          window.Mortgage.calculate();
        } else {
          const btnReset = document.getElementById('btnResetLoan');
          if (btnReset) btnReset.click();
        }
      }
      if (window.Bmi && typeof window.Bmi.calculate === 'function') {
        window.Bmi.calculate();
      }
    });
  }

  function updateLangButtonUI() {
    const btn = document.getElementById('btnToggleLang');
    if (!btn) return;
    btn.title = currentLang === 'zh' ? 'Switch to English' : '切换为中文';
  }

  // ─── 主题（三态）控制逻辑 ───
  function applyTheme() {
    const themeMode = localStorage.getItem('theme_mode') || 'auto';
    const htmlEl = document.documentElement;
    const themeIcon = document.getElementById('themeIcon');
    const btnTheme = document.getElementById('btnToggleTheme');
    const isEnglish = currentLang === 'en';
    
    let activeTheme = 'light';
    let tooltip = '';
    let iconStr = '🌓';
    
    if (themeMode === 'light') {
      activeTheme = 'light';
      iconStr = '☀️';
      tooltip = isEnglish ? 'Light Theme (Click to switch)' : '当前：浅色模式 (点击切换)';
    } else if (themeMode === 'dark') {
      activeTheme = 'dark';
      iconStr = '🌙';
      tooltip = isEnglish ? 'Dark Theme (Click to switch)' : '当前：深色模式 (点击切换)';
    } else { // auto
      iconStr = '🌓';
      tooltip = isEnglish ? 'Auto Theme (Follows System/Time)' : '当前：跟随系统/时间 (点击切换)';
      
      // 时间自动切换逻辑：下午 18 点至次日清晨 6 点自动转为深色
      const hours = new Date().getHours();
      const isNight = hours >= 18 || hours < 6;
      if (isNight) {
        activeTheme = 'dark';
      } else {
        const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        activeTheme = prefersDark ? 'dark' : 'light';
      }
    }
    
    htmlEl.setAttribute('data-theme', activeTheme);
    if (themeIcon) themeIcon.textContent = iconStr;
    if (btnTheme) btnTheme.title = tooltip;
  }

  const btnToggleTheme = document.getElementById('btnToggleTheme');
  if (btnToggleTheme) {
    btnToggleTheme.addEventListener('click', () => {
      const modes = ['auto', 'light', 'dark'];
      const currentMode = localStorage.getItem('theme_mode') || 'auto';
      let nextIdx = (modes.indexOf(currentMode) + 1) % modes.length;
      const nextMode = modes[nextIdx];
      localStorage.setItem('theme_mode', nextMode);
      applyTheme();
    });
  }

  // 监听系统主题变化以保持 auto 模式实时响应
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    const currentMode = localStorage.getItem('theme_mode') || 'auto';
    if (currentMode === 'auto') {
      applyTheme();
    }
  });

  // ─── 计算器简化/科学切换逻辑 ───
  function updateCalcModeUI() {
    const mode = localStorage.getItem('calc_mode') || 'simple';
    const gridSci = document.getElementById('calcGridSci');
    const gridSimple = document.getElementById('calcGridSimple');
    const btnToggle = document.getElementById('btnToggleCalcMode');
    
    if (!btnToggle) return;
    
    const isEnglish = currentLang === 'en';
    
    if (mode === 'simple') {
      if (gridSci) gridSci.style.display = 'none';
      if (gridSimple) gridSimple.style.display = 'grid';
      btnToggle.textContent = isEnglish ? 'Scientific Mode' : '切换科学计算';
    } else {
      if (gridSci) gridSci.style.display = 'grid';
      if (gridSimple) gridSimple.style.display = 'none';
      btnToggle.textContent = isEnglish ? 'Simple Mode' : '切换简化计算';
    }
  }

  const btnToggleCalcMode = document.getElementById('btnToggleCalcMode');
  if (btnToggleCalcMode) {
    btnToggleCalcMode.addEventListener('click', () => {
      const currentMode = localStorage.getItem('calc_mode') || 'simple';
      const newMode = currentMode === 'simple' ? 'scientific' : 'simple';
      localStorage.setItem('calc_mode', newMode);
      updateCalcModeUI();
    });
  }

  // ─── 2. Tab 页切换逻辑 ───
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabPanels = document.querySelectorAll('.tab-panel');

  tabButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');

      tabButtons.forEach(b => b.classList.remove('active'));
      tabPanels.forEach(p => p.classList.remove('active'));

      btn.classList.add('active');
      const targetPanel = document.getElementById(`panel-${targetTab}`);
      if (targetPanel) {
        targetPanel.classList.add('active');
      }

      // 特殊处理：当切换到“单位换算”或者“汇率换算”时，重新计算/对齐一下高度
      if (targetTab === 'units' && window.UnitConverter) {
        window.UnitConverter.renderGrid();
      }
    });
  });

  // ─── 3. AI 设置弹窗配置 ───
  const btnAiSettings = document.getElementById('btnAiSettings');
  const aiSettingsModal = document.getElementById('aiSettingsModal');
  const btnCloseSettings = document.getElementById('btnCloseSettings');
  const btnCancelSettings = document.getElementById('btnCancelSettings');
  const btnSaveSettings = document.getElementById('btnSaveSettings');
  const aiProviderSelect = document.getElementById('aiProviderSelect');
  const customAiFields = document.getElementById('customAiFields');

  const aiApiKeyInput = document.getElementById('aiApiKeyInput');
  const aiApiUrlInput = document.getElementById('aiApiUrlInput');
  const aiModelInput = document.getElementById('aiModelInput');

  // 打开弹窗
  if (btnAiSettings) {
    btnAiSettings.addEventListener('click', async () => {
      const config = await window.UniversalAI.getAIConfig();
      
      aiProviderSelect.value = config.provider || 'builtin';
      aiApiKeyInput.value = config.apiKey || '';
      aiApiUrlInput.value = config.apiUrl || '';
      aiModelInput.value = config.model || '';

      toggleCustomFields(aiProviderSelect.value);
      if (aiSettingsModal) aiSettingsModal.style.display = 'flex';
    });
  }

  // 关闭弹窗
  const closeSettingsModal = () => {
    if (aiSettingsModal) aiSettingsModal.style.display = 'none';
  };

  if (btnCloseSettings) btnCloseSettings.addEventListener('click', closeSettingsModal);
  if (btnCancelSettings) btnCancelSettings.addEventListener('click', closeSettingsModal);

  // 保存配置
  if (btnSaveSettings) {
    btnSaveSettings.addEventListener('click', async () => {
      const config = {
        provider: aiProviderSelect.value,
        apiKey: aiApiKeyInput.value.trim(),
        apiUrl: aiApiUrlInput.value.trim(),
        model: aiModelInput.value.trim()
      };

      await window.UniversalAI.saveAIConfig(config);
      alert(currentLang === 'zh' ? 'AI 引擎配置保存成功！' : 'AI configuration saved successfully!');
      closeSettingsModal();
    });
  }

  // 切换服务商显示字段
  if (aiProviderSelect) {
    aiProviderSelect.addEventListener('change', (e) => {
      toggleCustomFields(e.target.value);
    });
  }

  function toggleCustomFields(provider) {
    if (customAiFields) {
      customAiFields.style.display = provider === 'custom' ? 'block' : 'none';
    }
  }

  // ─── 4. 初始化六大计算子组件 ───
  if (window.StandardCalc && typeof window.StandardCalc.init === 'function') {
    window.StandardCalc.init();
  }
  if (window.ExchangeRate && typeof window.ExchangeRate.init === 'function') {
    window.ExchangeRate.init();
  }
  if (window.Mortgage && typeof window.Mortgage.init === 'function') {
    window.Mortgage.init();
  }
  if (window.UnitConverter && typeof window.UnitConverter.init === 'function') {
    window.UnitConverter.init();
  }
  if (window.CapitalConvert && typeof window.CapitalConvert.init === 'function') {
    window.CapitalConvert.init();
  }
  if (window.Bmi && typeof window.Bmi.init === 'function') {
    window.Bmi.init();
  }
});
