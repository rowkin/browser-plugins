/**
 * 万能计算器 Background Service Worker
 * 用于代理后台网络请求，解决 MV3 插件前台 Popup 调用部分外部 API 时的 Origin 跨域与连接关闭问题
 */

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === 'ai-stream') {
    port.onMessage.addListener(async (msg) => {
      if (msg.type === 'request') {
        const { url, options } = msg.data;
        
        try {
          // 在 Service Worker 中进行 fetch，不带有 chrome-extension:// 的 Origin，规避 WAF 安全网关屏蔽
          const response = await fetch(url, options);
          
          if (!response.ok) {
            let errorMsg = `HTTP Error ${response.status}`;
            try {
              const text = await response.text();
              const json = JSON.parse(text);
              errorMsg = json.error?.message || errorMsg;
            } catch (e) {}
            port.postMessage({ type: 'error', message: errorMsg });
            port.disconnect();
            return;
          }

          const requestBody = options.body ? JSON.parse(options.body) : {};
          
          // 如果是非流式请求，直接一次性返回
          if (!requestBody.stream) {
            const data = await response.json();
            const text = data.choices?.[0]?.message?.content || '';
            port.postMessage({ type: 'done', text });
            port.disconnect();
            return;
          }

          // 流式解析与实时传输
          const reader = response.body.getReader();
          const decoder = new TextDecoder('utf-8');
          let buffer = '';
          let fullText = '';

          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop(); // 保留半行

            for (const line of lines) {
              const cleanLine = line.trim();
              if (!cleanLine) continue;

              if (cleanLine.startsWith('data:')) {
                const jsonStr = cleanLine.substring(5).trim();
                if (jsonStr === '[DONE]') continue;

                try {
                  const parsed = JSON.parse(jsonStr);
                  const content = parsed.choices?.[0]?.delta?.content || '';
                  if (content) {
                    fullText += content;
                    port.postMessage({ type: 'chunk', text: fullText });
                  }
                } catch (e) {}
              }
            }
          }

          // 处理 buffer 中最后残留的行
          if (buffer) {
            const cleanLine = buffer.trim();
            if (cleanLine.startsWith('data:')) {
              const jsonStr = cleanLine.substring(5).trim();
              if (jsonStr !== '[DONE]') {
                try {
                  const parsed = JSON.parse(jsonStr);
                  const content = parsed.choices?.[0]?.delta?.content || '';
                  if (content) {
                    fullText += content;
                    port.postMessage({ type: 'chunk', text: fullText });
                  }
                } catch (e) {}
              }
            }
          }

          port.postMessage({ type: 'done', text: fullText });
        } catch (err) {
          port.postMessage({ type: 'error', message: err.message || 'Fetch failed' });
        } finally {
          try {
            port.disconnect();
          } catch (e) {}
        }
      }
    });
  }
});
