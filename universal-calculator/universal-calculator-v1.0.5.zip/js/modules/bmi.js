/**
 * BMI 体质指数与 AI 诊断模块 (支持中英文)
 */
(function () {
  const Bmi = {
    init() {
      const btnCalc = document.getElementById('btnCalculateBmi');
      const btnReset = document.getElementById('btnResetBmi');
      const btnAi = document.getElementById('btnBmiAiAnalyze');

      const ftEl = document.getElementById('bmiHeightFt');
      const inEl = document.getElementById('bmiHeightIn');
      const cmEl = document.getElementById('bmiHeightInput');
      const lbsEl = document.getElementById('bmiWeightLbs');
      const kgEl = document.getElementById('bmiWeightInput');

      // ─── 双向单位联动监听 ───
      if (ftEl && inEl && cmEl) {
        const updateCm = () => {
          const ft = parseFloat(ftEl.value) || 0;
          const inch = parseFloat(inEl.value) || 0;
          const cm = Math.round((ft * 12 + inch) * 2.54);
          cmEl.value = cm;
        };
        ftEl.addEventListener('input', updateCm);
        inEl.addEventListener('input', updateCm);
        
        cmEl.addEventListener('input', () => {
          const cm = parseFloat(cmEl.value);
          if (!Number.isNaN(cm) && cm > 0) {
            const totalInches = cm / 2.54;
            const ft = Math.floor(totalInches / 12);
            const inch = Math.round(totalInches % 12);
            ftEl.value = ft;
            inEl.value = inch === 12 ? 11 : inch;
          }
        });
      }

      if (lbsEl && kgEl) {
        lbsEl.addEventListener('input', () => {
          const lbs = parseFloat(lbsEl.value);
          if (!Number.isNaN(lbs) && lbs > 0) {
            const kg = Math.round((lbs / 2.20462) * 10) / 10;
            kgEl.value = kg;
          }
        });

        kgEl.addEventListener('input', () => {
          const kg = parseFloat(kgEl.value);
          if (!Number.isNaN(kg) && kg > 0) {
            const lbs = Math.round(kg * 2.20462);
            lbsEl.value = lbs;
          }
        });
      }

      if (btnCalc) {
        btnCalc.addEventListener('click', () => this.calculate());
      }

      if (btnReset) {
        btnReset.addEventListener('click', () => {
          const genderSelect = document.getElementById('bmiGenderSelect');
          if (genderSelect) genderSelect.value = 'male';
          
          if (ftEl) ftEl.value = '5';
          if (inEl) inEl.value = '9';
          if (cmEl) cmEl.value = '175';
          if (lbsEl) lbsEl.value = '143';
          if (kgEl) kgEl.value = '65';
          
          // 重置时重新计算默认 21.2 状态，保持界面美观
          this.calculate();
        });
      }

      if (btnAi) {
        btnAi.addEventListener('click', () => this.analyzeAI());
      }
    },

    calculate() {
      const hInput = document.getElementById('bmiHeightInput');
      const wInput = document.getElementById('bmiWeightInput');
      const valText = document.getElementById('bmiValText');
      const statusText = document.getElementById('bmiStatusText');
      const statusBadge = document.getElementById('bmiStatusBadge');
      const tipsText = document.getElementById('bmiTipsText');

      const isEnglish = (localStorage.getItem('user_lang') || 'zh') === 'en';

      const height = parseFloat(hInput.value); // cm
      const weight = parseFloat(wInput.value); // kg

      if (Number.isNaN(height) || height <= 30 || height > 300) {
        alert(isEnglish ? 'Please enter a valid height (30 ~ 300 cm).' : '请输入合适的身高 (30 ~ 300 cm)');
        return;
      }
      if (Number.isNaN(weight) || weight <= 2 || weight > 500) {
        alert(isEnglish ? 'Please enter a valid weight (2 ~ 500 kg).' : '请输入合适的体重 (2 ~ 500 kg)');
        return;
      }

      const heightM = height / 100;
      const bmi = weight / (heightM * heightM);

      if (valText) valText.textContent = bmi.toFixed(1);

      if (bmi < 18.5) {
        if (statusText) statusText.textContent = isEnglish ? 'Underweight' : '偏瘦';
        if (statusBadge) {
          statusBadge.style.background = '#3b82f6';
          statusBadge.style.color = 'white';
        }
        if (tipsText) {
          tipsText.textContent = isEnglish 
            ? 'Your BMI is low. Balanced nutrition and strength training are recommended.'
            : '您的 BMI 指数偏低，可能存在营养不良。建议多补充优质蛋白质与高营养膳食，配合力量训练增加肌肉量。';
        }
      } else if (bmi < 24) {
        if (statusText) statusText.textContent = isEnglish ? 'Normal' : '正常';
        if (statusBadge) {
          statusBadge.style.background = '#10b981';
          statusBadge.style.color = 'white';
        }
        if (tipsText) {
          tipsText.textContent = isEnglish
            ? 'Congratulations! Your BMI is in the healthy range. Keep it up!'
            : '恭喜！您的 BMI 指数处于最健康的范围。请继续保持合理的饮食和规律运动，继续维持良好体态！';
        }
      } else if (bmi < 28) {
        if (statusText) statusText.textContent = isEnglish ? 'Overweight' : '超重';
        if (statusBadge) {
          statusBadge.style.background = '#f59e0b';
          statusBadge.style.color = 'white';
        }
        if (tipsText) {
          tipsText.textContent = isEnglish
            ? 'Your BMI is in the overweight range. Consider adjusting your diet and adding aerobic exercise.'
            : '您的 BMI 指数属于超重范畴。建议适度调整饮食结构，减少高油高热量摄入，结合有氧运动以控制体重。';
        }
      } else {
        if (statusText) statusText.textContent = isEnglish ? 'Obese' : '肥胖';
        if (statusBadge) {
          statusBadge.style.background = '#ef4444';
          statusBadge.style.color = 'white';
        }
        if (tipsText) {
          tipsText.textContent = isEnglish
            ? 'Your BMI indicates obesity. Scientific weight and body fat management is advised.'
            : '您的 BMI 指数已达肥胖级别，可能会增加心脑血管系统疾病风险。建议咨询专业医生或营养师，进行科学的体脂管理。';
        }
      }

      // 重置之前的 AI 分析框为默认列表提示，并且确保保留 data-i18n
      const aiOutput = document.getElementById('bmiAiOutput');
      if (aiOutput) {
        aiOutput.innerHTML = `
          <ul class="default-tips">
            <li data-i18n="bmi_tip_1">Maintain current physical activity: 150 min/week.</li>
            <li data-i18n="bmi_tip_2">Ensure balanced nutrition: Focus on whole foods, lean proteins, vegetables.</li>
            <li data-i18n="bmi_tip_3">Stay hydrated: Drink adequate water daily.</li>
            <li data-i18n="bmi_tip_4">Schedule regular check-ups to monitor overall wellness.</li>
            <li data-i18n="bmi_tip_5">Target a consistent sleep schedule (7-8 hours).</li>
          </ul>
        `;
        if (window.i18n && typeof window.i18n.initDOMTranslation === 'function') {
          window.i18n.initDOMTranslation();
        }
      }
    },

    async analyzeAI() {
      const btnAi = document.getElementById('btnBmiAiAnalyze');
      const btnAiText = document.getElementById('btnBmiAiAnalyzeText');
      const aiOutput = document.getElementById('bmiAiOutput');
      const valText = document.getElementById('bmiValText');
      const statusText = document.getElementById('bmiStatusText');
      const tipsText = document.getElementById('bmiTipsText');

      const isEnglish = (localStorage.getItem('user_lang') || 'zh') === 'en';

      const bmiVal = valText ? valText.textContent : '';
      const bmiStatus = statusText ? statusText.textContent : '';
      const bmiTips = tipsText ? tipsText.textContent : '';

      if (!bmiVal || bmiVal === '-') {
        alert(isEnglish ? 'Please calculate BMI first.' : '请先进行 BMI 计算，生成结果后再进行 AI 智能诊断。');
        return;
      }

      // 【一重防护】在转为 loading 状态前先校验 API Key，如果是 custom 且未填，则通过 UI 提示而绝不抛出运行期错误
      const config = await window.UniversalAI.getAIConfig();
      if (config.provider === 'custom' && !config.apiKey) {
        if (aiOutput) {
          aiOutput.style.display = 'block';
          aiOutput.innerHTML = `
            <div style="padding: 12px; border-radius: 8px; background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.2); color: #d97706; font-size: 13px; line-height: 1.5;">
              ${isEnglish 
                ? '⚠️ API Key is missing. Please click the ⚙️ gear icon in the top right header and configure your custom API settings first.' 
                : '⚠️ 缺失 API Key 密钥。请点击右上角 ⚙️ 设置图标，在 AI 配置弹窗中填写您的 API Key 密钥。'}
            </div>
          `;
        }
        return;
      }

      // 1. 转为 Loading 状态 (仅更新文本节点以防止丢弃 data-i18n)
      btnAi.disabled = true;
      if (btnAiText) btnAiText.textContent = isEnglish ? 'Analyzing...' : '正在分析...';
      btnAi.style.opacity = '0.7';
      btnAi.style.cursor = 'not-allowed';

      if (aiOutput) {
        aiOutput.style.display = 'block';
        aiOutput.innerHTML = `
          <div class="ai-loading-container" style="display:flex;flex-direction:column;align-items:center;padding:24px 0;gap:12px">
            <div class="loading-spinner" style="width:28px;height:28px;border:3px solid var(--border-light);border-top:3px solid var(--accent);border-radius:50%;animation:spin 1s linear infinite"></div>
            <div style="font-size:12px;color:var(--text-secondary)">${window.i18n.getMessage('ai_loading_text')}</div>
          </div>
        `;
      }

      // 2. 拼装 prompt 提示词
      const height = document.getElementById('bmiHeightInput').value;
      const weight = document.getElementById('bmiWeightInput').value;

      const systemPrompt = isEnglish
        ? 'You are an experienced clinical nutritionist and fitness expert. Based on the user\'s physical parameters (height, weight, BMI value, status), provide customized recommendations including: 1. Diet and calorie intake. 2. Weekly exercise routines (cardio & strength). 3. Healthy habits. Keep it structured and action-oriented.'
        : '你是一个资深的临床营养学专家和健身运动规划教练。请根据用户计算出的 BMI 特征，为用户定制量身设计一套：1. 日常膳食热量管理方案；2. 每周运动锻炼强度和计划；3. 科学生活作息建议。请使用 Markdown 进行结构化回复，回答要专业、精准、亲切。';

      const userPrompt = isEnglish
        ? `My parameters: Height ${height} cm, Weight ${weight} kg, BMI ${bmiVal} (${bmiStatus}). Default tip: ${bmiTips}. Provide clinical nutrition and aerobic/anaerobic plan.`
        : `我的身高是 ${height} cm，体重是 ${weight} kg，计算得出 BMI 指数是 ${bmiVal}，处于「${bmiStatus}」状态。已有的基础提示是：${bmiTips}。请给出专业的临床膳食与抗阻有氧训练方案。`;

      try {
        const finalResult = await window.UniversalAI.callAI(systemPrompt, userPrompt, (fullText) => {
          if (aiOutput) {
            if (typeof window.renderInlineMarkdown === 'function') {
              aiOutput.innerHTML = window.renderInlineMarkdown(fullText);
            } else {
              aiOutput.textContent = fullText;
            }
          }
        });

        if (aiOutput && finalResult) {
          if (typeof window.renderInlineMarkdown === 'function') {
            aiOutput.innerHTML = window.renderInlineMarkdown(finalResult);
          } else {
            aiOutput.textContent = finalResult;
          }
        }
      } catch (err) {
        console.warn('AI Analysis Intercepted (Non-critical):', err);
        if (aiOutput) {
          aiOutput.textContent = isEnglish 
            ? `❌ Analysis failed: ${err.message || 'Network exception'}`
            : `❌ 智能分析失败: ${err.message || '网络连接异常，请重试'}`;
        }
      } finally {
        btnAi.disabled = false;
        if (btnAiText) btnAiText.textContent = window.i18n.getMessage('btn_ai_analyze');
        btnAi.style.opacity = '1';
        btnAi.style.cursor = 'pointer';
      }
    }
  };

  window.Bmi = Bmi;
})();
