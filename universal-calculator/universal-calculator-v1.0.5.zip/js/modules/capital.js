/**
 * 财务大写金额转换模块 (支持中文财务大写及英文金额拼写)
 */
(function () {
  function digitToChinese(n) {
    if (Number.isNaN(n) || n < 0 || n >= 1000000000000) return '金额无效 (支持 0 ~ 9999 亿)';
    const fraction = ['角', '分'];
    const digit = ['零', '壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖'];
    const unit = [
      ['元', '万', '亿'],
      ['', '拾', '佰', '仟']
    ];
    let head = n < 0 ? '欠' : '';
    n = Math.abs(n);
    let s = '';
    const decimalPart = Math.round((n % 1) * 100);
    if (decimalPart > 0) {
      const jiao = Math.floor(decimalPart / 10);
      const fen = decimalPart % 10;
      if (jiao > 0) s += digit[jiao] + fraction[0];
      if (fen > 0) s += digit[fen] + fraction[1];
    }
    
    let integerPart = Math.floor(n);
    for (let i = 0; i < unit[0].length && integerPart > 0; i++) {
      let p = '';
      for (let j = 0; j < unit[1].length && integerPart > 0; j++) {
        p = digit[integerPart % 10] + unit[1][j] + p;
        integerPart = Math.floor(integerPart / 10);
      }
      s = p.replace(/(零.)*零$/, '').replace(/^$/, '零') + unit[0][i] + s;
    }
    
    s = head + s.replace(/(零.)*零元/, '元')
                .replace(/(零.)+/g, '零')
                .replace(/^整$/, '零元整');
    if (s === '') {
      s = '零元整';
    } else if (!s.endsWith('分')) {
      s += '整';
    }
    return s;
  }

  // 辅助函数：将数字转换为英文单词拼写
  function numberToEnglishWords(num) {
    if (num === 0) return 'Zero';
    
    const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 
                  'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    const thousands = ['', 'Thousand', 'Million', 'Billion'];

    function helper(n) {
      if (n === 0) return '';
      if (n < 20) return ones[n] + ' ';
      if (n < 100) return tens[Math.floor(n / 10)] + ' ' + helper(n % 10);
      return ones[Math.floor(n / 100)] + ' Hundred ' + (n % 100 !== 0 ? 'and ' : '') + helper(n % 100);
    }

    let res = '';
    let i = 0;
    let integerPart = Math.floor(num);

    while (integerPart > 0) {
      if (integerPart % 1000 !== 0) {
        res = helper(integerPart % 1000) + thousands[i] + ' ' + res;
      }
      integerPart = Math.floor(integerPart / 1000);
      i++;
    }

    return res.trim();
  }

  function digitToEnglish(n) {
    if (Number.isNaN(n) || n < 0 || n >= 1000000000000) return 'Invalid Amount';
    
    const cents = Math.round((n % 1) * 100);
    const dollars = Math.floor(n);
    
    let res = '';
    if (dollars > 0) {
      const dollarStr = numberToEnglishWords(dollars);
      res += dollarStr + (dollars === 1 ? ' Dollar' : ' Dollars');
    }
    
    if (cents > 0) {
      const centStr = numberToEnglishWords(cents);
      if (res !== '') res += ' and ';
      res += centStr + (cents === 1 ? ' Cent' : ' Cents');
    }
    
    if (res === '') {
      res = 'Zero Dollars';
    }
    
    return res;
  }

  const CapitalConvert = {
    init() {
      const input = document.getElementById('capitalInput');
      const outputZh = document.getElementById('capitalOutputZh');
      const outputEn = document.getElementById('capitalOutputEn');
      const btnCopyZh = document.getElementById('btnCopyCapitalZh');
      const btnCopyEn = document.getElementById('btnCopyCapitalEn');

      if (!input) return;

      const handleConvert = () => {
        const val = parseFloat(input.value);
        if (Number.isNaN(val)) {
          if (outputZh) outputZh.textContent = '壹万贰仟叁佰肆拾伍元陆角柒分';
          if (outputEn) outputEn.textContent = 'One Ten-Thousand Two Thousand...';
          return;
        }

        if (outputZh) outputZh.textContent = digitToChinese(val);
        if (outputEn) outputEn.textContent = digitToEnglish(val);
      };

      input.addEventListener('input', handleConvert);

      // 复制功能
      if (btnCopyZh) {
        btnCopyZh.addEventListener('click', () => {
          if (outputZh && outputZh.textContent && !outputZh.textContent.includes('One Ten-Thousand') && !outputZh.textContent.includes('壹万')) {
            navigator.clipboard.writeText(outputZh.textContent).then(() => {
              alert(window.i18n.getMessage('tab_standard') === 'Scientific' ? 'Copied Chinese Capital' : '中文财务大写已复制到剪贴板');
            });
          }
        });
      }

      if (btnCopyEn) {
        btnCopyEn.addEventListener('click', () => {
          if (outputEn && outputEn.textContent && !outputEn.textContent.includes('One Ten-Thousand') && !outputEn.textContent.includes('壹万')) {
            navigator.clipboard.writeText(outputEn.textContent).then(() => {
              alert(window.i18n.getMessage('tab_standard') === 'Scientific' ? 'Copied English Words' : '英文金额拼写已复制到剪贴板');
            });
          }
        });
      }
    }
  };

  window.CapitalConvert = CapitalConvert;
})();
