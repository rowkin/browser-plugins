/**
 * 实时汇率换算模块
 */
(function () {
  const DEFAULT_RATES = {
    "USD": 1.0,
    "CNY": 7.258,
    "EUR": 0.918,
    "JPY": 156.24,
    "GBP": 0.785,
    "HKD": 7.812,
    "AUD": 1.505,
    "CAD": 1.368,
    "SGD": 1.348,
    "KRW": 1378.5
  };

  const CURRENCY_NAMES_ZH = {
    "CNY": "人民币 (CNY)",
    "USD": "美元 (USD)",
    "EUR": "欧元 (EUR)",
    "JPY": "日元 (JPY)",
    "GBP": "英镑 (GBP)",
    "HKD": "港币 (HKD)",
    "AUD": "澳元 (AUD)",
    "CAD": "加拿大元 (CAD)",
    "SGD": "新加坡元 (SGD)",
    "KRW": "韩元 (KRW)"
  };

  const CURRENCY_NAMES_EN = {
    "CNY": "Yuan (CNY)",
    "USD": "Dollar (USD)",
    "EUR": "Euro (EUR)",
    "JPY": "Yen (JPY)",
    "GBP": "Pound (GBP)",
    "HKD": "HK Dollar (HKD)",
    "AUD": "Aus Dollar (AUD)",
    "CAD": "Can Dollar (CAD)",
    "SGD": "Sing Dollar (SGD)",
    "KRW": "Won (KRW)"
  };

  let activeRates = { ...DEFAULT_RATES };
  let ratesLastUpdate = "2026-07-16 00:00:00";

  const ExchangeRate = {
    async init() {
      const fromSelect = document.getElementById('exchangeFromCurrency');
      const toSelect = document.getElementById('exchangeToCurrency');
      const isEnglish = window.i18n.getMessage('tab_standard') === 'Scientific';
      const names = isEnglish ? CURRENCY_NAMES_EN : CURRENCY_NAMES_ZH;

      if (!fromSelect || !toSelect) return;

      fromSelect.innerHTML = '';
      toSelect.innerHTML = '';

      // 初始化下拉框选项
      Object.keys(names).forEach((code) => {
        const optFrom = document.createElement('option');
        optFrom.value = code;
        optFrom.textContent = names[code];
        if (code === 'USD') optFrom.selected = true;
        fromSelect.appendChild(optFrom);

        const optTo = document.createElement('option');
        optTo.value = code;
        optTo.textContent = names[code];
        if (code === 'CNY') optTo.selected = true;
        toSelect.appendChild(optTo);
      });

      // 绑定输入框变化事件
      document.getElementById('exchangeFromAmount').addEventListener('input', () => {
        this.convert('from');
      });
      document.getElementById('exchangeToAmount').addEventListener('input', () => {
        this.convert('to');
      });

      fromSelect.addEventListener('change', () => this.convert('from'));
      toSelect.addEventListener('change', () => this.convert('from'));

      // 交换按钮
      document.getElementById('btnSwapCurrency').addEventListener('click', () => {
        const tmp = fromSelect.value;
        fromSelect.value = toSelect.value;
        toSelect.value = tmp;

        const fromVal = document.getElementById('exchangeFromAmount').value;
        const toVal = document.getElementById('exchangeToAmount').value;

        document.getElementById('exchangeFromAmount').value = toVal;
        document.getElementById('exchangeToAmount').value = fromVal;

        this.convert('from');
      });

      // 刷新按钮
      document.getElementById('btnRefreshExchange').addEventListener('click', () => {
        this.fetchRates(true);
      });

      // 首次获取汇率
      await this.fetchRates(false);
    },

    convert(direction = 'from') {
      const fromSelect = document.getElementById('exchangeFromCurrency');
      const toSelect = document.getElementById('exchangeToCurrency');
      const fromInput = document.getElementById('exchangeFromAmount');
      const toInput = document.getElementById('exchangeToAmount');

      const fromCode = fromSelect.value;
      const toCode = toSelect.value;

      const rateFromUsd = activeRates[fromCode];
      const rateToUsd = activeRates[toCode];

      if (!rateFromUsd || !rateToUsd) return;

      if (direction === 'from') {
        const val = parseFloat(fromInput.value);
        if (Number.isNaN(val) || val < 0) {
          toInput.value = '';
          return;
        }
        const result = val * (rateToUsd / rateFromUsd);
        toInput.value = parseFloat(result.toFixed(4));
      } else {
        const val = parseFloat(toInput.value);
        if (Number.isNaN(val) || val < 0) {
          fromInput.value = '';
          return;
        }
        const result = val * (rateFromUsd / rateToUsd);
        fromInput.value = parseFloat(result.toFixed(4));
      }
      
      // 更新对比表格
      this.updateContrastTable();
    },

    async fetchRates(isManual = false) {
      const statusEl = document.getElementById('exchangeStatus');
      if (!statusEl) return;

      const isEnglish = window.i18n.getMessage('tab_standard') === 'Scientific';
      statusEl.textContent = isEnglish ? 'Fetching rates...' : '正在获取实时汇率数据...';

      try {
        const res = await fetch('https://open.er-api.com/v6/latest/USD');
        if (!res.ok) throw new Error('Network error');

        const data = await res.json();
        if (data.result === 'success' && data.rates) {
          activeRates = {};
          Object.keys(DEFAULT_RATES).forEach((code) => {
            activeRates[code] = data.rates[code] || DEFAULT_RATES[code];
          });

          ratesLastUpdate = data.time_last_update_utc || new Date().toUTCString();
          
          if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            await chrome.storage.local.set({
              'exchange_rates_cache': activeRates,
              'exchange_rates_update_time': ratesLastUpdate
            });
          }

          statusEl.textContent = isEnglish 
            ? `Rates provided by Open Exchange Rates API, updated: ${ratesLastUpdate}`
            : `实时汇率由 Open Exchange Rates API 提供，更新于：${ratesLastUpdate}`;
        } else {
          throw new Error('Format error');
        }
      } catch (err) {
        console.warn('获取汇率接口失败，启用降级缓存：', err);
        let loadedFromCache = false;

        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          const cached = await chrome.storage.local.get(['exchange_rates_cache', 'exchange_rates_update_time']);
          if (cached.exchange_rates_cache) {
            activeRates = cached.exchange_rates_cache;
            ratesLastUpdate = cached.exchange_rates_update_time;
            statusEl.textContent = isEnglish
              ? `⚠️ Network failed. Loaded cache (updated: ${ratesLastUpdate})`
              : `⚠️ 网络连接失败，已加载本地缓存汇率（更新于：${ratesLastUpdate}）`;
            loadedFromCache = true;
          }
        }

        if (!loadedFromCache) {
          activeRates = { ...DEFAULT_RATES };
          statusEl.textContent = isEnglish
            ? `⚠️ Network failed. Loaded default preset rates.`
            : `⚠️ 网络连接失败，已加载离线出厂预设汇率。`;
        }
      }

      this.convert('from');
      this.updateContrastTable();
    },

    updateContrastTable() {
      const tbody = document.getElementById('exchangeTableBody');
      if (!tbody) return;

      const isEnglish = window.i18n.getMessage('tab_standard') === 'Scientific';
      const names = isEnglish ? CURRENCY_NAMES_EN : CURRENCY_NAMES_ZH;
      tbody.innerHTML = '';

      const rateCnyUsd = activeRates['CNY'];

      Object.keys(DEFAULT_RATES).forEach((code) => {
        if (code === 'CNY') return;

        const rateCurrencyUsd = activeRates[code];
        // 100 CNY 兑换成目标外币 = 100 * (rateCurrencyUsd / rateCnyUsd)
        const cnyToFx = (100 * (rateCurrencyUsd / rateCnyUsd)).toFixed(2);
        // 100 目标外币兑换成 CNY = 100 * (rateCnyUsd / rateCurrencyUsd)
        const fxToCny = (100 * (rateCnyUsd / rateCurrencyUsd)).toFixed(2);

        const row = document.createElement('tr');
        row.innerHTML = `
          <td><strong>${code}</strong> <span style="font-size:11px;color:var(--text-tertiary)">(${names[code].split(' ')[0]})</span></td>
          <td>100 ${code} = <strong>${fxToCny}</strong> CNY</td>
          <td>100 CNY = <strong>${cnyToFx}</strong> ${code}</td>
        `;
        tbody.appendChild(row);
      });
    }
  };

  window.ExchangeRate = ExchangeRate;
})();
