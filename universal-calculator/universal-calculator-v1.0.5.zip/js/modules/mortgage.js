/**
 * 房贷月供推演模块
 */
(function () {
  const Mortgage = {
    init() {
      const btnCalc = document.getElementById('btnCalcLoan');
      const btnReset = document.getElementById('btnResetLoan');
      
      if (btnCalc) {
        btnCalc.addEventListener('click', () => this.calculate());
      }
      if (btnReset) {
        btnReset.addEventListener('click', () => {
          document.getElementById('loanAmount').value = '100';
          document.getElementById('loanRate').value = '3.8';
          document.getElementById('loanYears').value = '30';
          const tbody = document.getElementById('loanResultBody');
          if (tbody) tbody.innerHTML = '';
          
          const isEnglish = window.i18n.getMessage('tab_standard') === 'Scientific';
          document.getElementById('summaryFirstMonth').textContent = isEnglish ? '0.00 CNY' : '0.00 元';
          document.getElementById('summaryTotalInterest').textContent = isEnglish ? '0.00 10k CNY' : '0.00 万元';
          document.getElementById('summaryTotalRepay').textContent = isEnglish ? '0.00 10k CNY' : '0.00 万元';
          document.getElementById('summaryDecrease').textContent = isEnglish ? 'Fixed' : '固定额度';
          
          const method = document.getElementById('loanMethod').value;
          const firstMonthLabel = document.getElementById('firstMonthLabel');
          const decreaseLabel = document.getElementById('decreaseLabel');
          if (firstMonthLabel) {
            firstMonthLabel.textContent = isEnglish 
              ? (method === 'acpi' ? 'Monthly Payment' : 'First Month Pay') 
              : (method === 'acpi' ? '每月月供' : '首月月供');
          }
          if (decreaseLabel) {
            decreaseLabel.textContent = isEnglish 
              ? (method === 'acpi' ? 'Monthly Trend' : 'Monthly Decrease') 
              : (method === 'acpi' ? '月供性质' : '每月递减');
          }
        });
      }
    },

    calculate() {
      const amountVal = parseFloat(document.getElementById('loanAmount').value);
      const rateVal = parseFloat(document.getElementById('loanRate').value);
      const yearsVal = parseFloat(document.getElementById('loanYears').value);
      const method = document.getElementById('loanMethod').value; // acpi (等额本息) 或 acp (等额本金)

      const isEnglish = window.i18n.getMessage('tab_standard') === 'Scientific';

      if (Number.isNaN(amountVal) || amountVal <= 0) {
        alert(isEnglish ? 'Please enter a valid loan amount.' : '请输入正确的贷款总额');
        return;
      }
      if (Number.isNaN(yearsVal) || yearsVal <= 0) {
        alert(isEnglish ? 'Please enter a valid term.' : '请输入正确的贷款期限');
        return;
      }
      if (Number.isNaN(rateVal) || rateVal <= 0) {
        alert(isEnglish ? 'Please enter a valid interest rate.' : '请输入正确的利率');
        return;
      }

      const months = yearsVal * 12;
      const principal = amountVal * 10000; // 万元转元
      const annualRate = rateVal / 100;
      const monthlyRate = annualRate / 12; // 月利率

      const tbody = document.getElementById('loanResultBody');
      if (!tbody) return;
      tbody.innerHTML = '';

      const firstMonthLabel = document.getElementById('firstMonthLabel');
      const decreaseLabel = document.getElementById('decreaseLabel');

      let totalInterest = 0;
      let totalRepay = 0;
      let firstMonthPay = 0;
      let monthlyDecrease = 0;

      const listData = [];

      if (method === 'acpi') {
        // 1. 等额本息
        if (firstMonthLabel) firstMonthLabel.textContent = isEnglish ? 'Monthly Payment' : '每月月供';
        if (decreaseLabel) decreaseLabel.textContent = isEnglish ? 'Monthly Trend' : '月供性质';

        // 每月月供公式: [P * R * (1 + R)^N] / [(1 + R)^N - 1]
        const monthlyPay = principal * (monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1);
        firstMonthPay = monthlyPay;
        monthlyDecrease = 0;

        const summaryDecrease = document.getElementById('summaryDecrease');
        if (summaryDecrease) summaryDecrease.textContent = isEnglish ? 'Fixed' : '固定额度';

        let remainingPrincipal = principal;
        let accumulatedPrincipal = 0;
        let accumulatedInterest = 0;

        totalRepay = monthlyPay * months;
        totalInterest = totalRepay - principal;

        for (let m = 1; m <= months; m++) {
          const interest = remainingPrincipal * monthlyRate; // 当期利息
          const principalPaid = monthlyPay - interest; // 当期本金

          accumulatedPrincipal += principalPaid;
          accumulatedInterest += interest;
          remainingPrincipal -= principalPaid;

          const displayRemainingPrincipal = Math.max(0, remainingPrincipal);
          const displayRemainingInterest = Math.max(0, totalInterest - accumulatedInterest);

          listData.push({
            num: m,
            monthlyPay: monthlyPay,
            principalPaid: principalPaid,
            interestPaid: interest,
            accumulatedPrincipal: accumulatedPrincipal,
            accumulatedInterest: accumulatedInterest,
            remainingPrincipal: displayRemainingPrincipal,
            remainingInterest: displayRemainingInterest
          });
        }
      } else {
        // 2. 等额本金
        if (firstMonthLabel) firstMonthLabel.textContent = isEnglish ? 'First Month Pay' : '首月月供';
        if (decreaseLabel) decreaseLabel.textContent = isEnglish ? 'Monthly Decrease' : '每月递减';

        // 每月本金固定
        const principalPerMonth = principal / months;
        let remainingPrincipal = principal;
        let accumulatedPrincipal = 0;
        let accumulatedInterest = 0;

        // 每月递减额: 每月应还本金 * 月利率
        monthlyDecrease = principalPerMonth * monthlyRate;
        const summaryDecrease = document.getElementById('summaryDecrease');
        if (summaryDecrease) {
          summaryDecrease.textContent = isEnglish 
            ? `${monthlyDecrease.toFixed(2)} CNY`
            : `${monthlyDecrease.toFixed(2)} 元`;
        }

        const tempPayments = [];
        for (let m = 1; m <= months; m++) {
          const interest = remainingPrincipal * monthlyRate; // 当期利息
          const monthlyPay = principalPerMonth + interest; // 当期月供

          accumulatedPrincipal += principalPerMonth;
          accumulatedInterest += interest;
          remainingPrincipal -= principalPerMonth;

          tempPayments.push({
            num: m,
            monthlyPay: monthlyPay,
            principalPaid: principalPerMonth,
            interestPaid: interest,
            accumulatedPrincipal: accumulatedPrincipal,
            accumulatedInterest: accumulatedInterest,
            remainingPrincipal: Math.max(0, remainingPrincipal)
          });
        }

        totalInterest = accumulatedInterest;
        totalRepay = principal + totalInterest;
        firstMonthPay = tempPayments[0].monthlyPay;

        tempPayments.forEach((p) => {
          listData.push({
            ...p,
            remainingInterest: Math.max(0, totalInterest - p.accumulatedInterest)
          });
        });
      }

      // 更新汇总卡片
      document.getElementById('summaryFirstMonth').textContent = isEnglish 
        ? `${firstMonthPay.toFixed(2)} CNY` 
        : `${firstMonthPay.toFixed(2)} 元`;
      document.getElementById('summaryTotalInterest').textContent = isEnglish 
        ? `${(totalInterest / 10000).toFixed(2)} 10k CNY` 
        : `${(totalInterest / 10000).toFixed(2)} 万元`;
      document.getElementById('summaryTotalRepay').textContent = isEnglish 
        ? `${(totalRepay / 10000).toFixed(2)} 10k CNY` 
        : `${(totalRepay / 10000).toFixed(2)} 万元`;

      // 渲染汇总表头及合计行
      const totalRow = document.createElement('tr');
      totalRow.className = 'total-row';
      totalRow.innerHTML = isEnglish ? `
        <td>Total</td>
        <td>${(totalRepay / 10000).toFixed(2)} 10k</td>
        <td>${(principal / 10000).toFixed(2)} 10k</td>
        <td>${(totalInterest / 10000).toFixed(2)} 10k</td>
        <td colspan="4" style="color:var(--text-tertiary);font-weight:normal;text-align:center">Summary Value - Details Below</td>
      ` : `
        <td>合计</td>
        <td>${(totalRepay / 10000).toFixed(2)} 万元</td>
        <td>${(principal / 10000).toFixed(2)} 万元</td>
        <td>${(totalInterest / 10000).toFixed(2)} 万元</td>
        <td colspan="4" style="color:var(--text-tertiary);font-weight:normal;text-align:center">以汇总值为准 · 详细推演如下</td>
      `;
      tbody.appendChild(totalRow);

      // 插入每期还款明细行（在 Popup 中限制只展示前 12 期和最后一期，或者为了简洁提供滚动条展示全部）
      // 由于我们有独立的明细抽屉/滚动表格，可以全部渲染，利用 CSS 滚动十分丝滑！
      listData.forEach((item) => {
        const row = document.createElement('tr');
        row.innerHTML = isEnglish ? `
          <td>M ${item.num}</td>
          <td>${item.monthlyPay.toFixed(2)}</td>
          <td>${item.principalPaid.toFixed(2)}</td>
          <td>${item.interestPaid.toFixed(2)}</td>
          <td>${(item.remainingPrincipal / 10000).toFixed(4)} 10k</td>
          <td>${(item.remainingInterest / 10000).toFixed(4)} 10k</td>
        ` : `
          <td>第 ${item.num} 期</td>
          <td>${item.monthlyPay.toFixed(2)}</td>
          <td>${item.principalPaid.toFixed(2)}</td>
          <td>${item.interestPaid.toFixed(2)}</td>
          <td>${(item.remainingPrincipal / 10000).toFixed(4)} 万</td>
          <td>${(item.remainingInterest / 10000).toFixed(4)} 万</td>
        `;
        tbody.appendChild(row);
      });
    }
  };

  window.Mortgage = Mortgage;
})();
