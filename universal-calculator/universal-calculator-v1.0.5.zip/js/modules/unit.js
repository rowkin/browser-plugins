/**
 * 常用物理单位换算模块 (支持中英文)
 */
(function () {
  const UNIT_CATEGORIES = {
    length: {
      name: '长度换算',
      name_en: 'Length',
      base: 'm',
      units: [
        { code: 'km', name: '千米 (km)', name_en: 'Kilometer (km)', rate: 1000 },
        { code: 'm', name: '米 (m)', name_en: 'Meter (m)', rate: 1.0 },
        { code: 'dm', name: '分米 (dm)', name_en: 'Decimeter (dm)', rate: 0.1 },
        { code: 'cm', name: '厘米 (cm)', name_en: 'Centimeter (cm)', rate: 0.01 },
        { code: 'mm', name: '毫米 (mm)', name_en: 'Millimeter (mm)', rate: 0.001 },
        { code: 'um', name: '微米 (µm)', name_en: 'Micrometer (µm)', rate: 0.000001 },
        { code: 'li', name: '里', name_en: 'Li (Chinese Mile)', rate: 500 },
        { code: 'zhang', name: '丈', name_en: 'Zhang', rate: 3.3333333333 },
        { code: 'chi', name: '尺', name_en: 'Chi', rate: 0.3333333333 },
        { code: 'cun', name: '寸', name_en: 'Cun', rate: 0.0333333333 },
        { code: 'mile', name: '英里 (mile)', name_en: 'Mile (mile)', rate: 1609.344 },
        { code: 'yd', name: '码 (yd)', name_en: 'Yard (yd)', rate: 0.9144 },
        { code: 'ft', name: '英尺 (ft)', name_en: 'Foot (ft)', rate: 0.3048 },
        { code: 'in', name: '英寸 (in)', name_en: 'Inch (in)', rate: 0.0254 }
      ]
    },
    weight: {
      name: '重量换算',
      name_en: 'Weight',
      base: 'kg',
      units: [
        { code: 't', name: '吨 (t)', name_en: 'Ton (t)', rate: 1000 },
        { code: 'kg', name: '千克 (kg)', name_en: 'Kilogram (kg)', rate: 1.0 },
        { code: 'g', name: '克 (g)', name_en: 'Gram (g)', rate: 0.001 },
        { code: 'mg', name: '毫克 (mg)', name_en: 'Milligram (mg)', rate: 0.000001 },
        { code: 'jin', name: '斤', name_en: 'Catty (Jin)', rate: 0.5 },
        { code: 'liang', name: '两', name_en: 'Liang', rate: 0.05 },
        { code: 'lb', name: '磅 (lb)', name_en: 'Pound (lb)', rate: 0.45359237 },
        { code: 'oz', name: '盎司 (oz)', name_en: 'Ounce (oz)', rate: 0.0283495231 }
      ]
    },
    area: {
      name: '面积换算',
      name_en: 'Area',
      base: 'm2',
      units: [
        { code: 'km2', name: '平方千米 (km²)', name_en: 'Sq Kilometer (km²)', rate: 1000000 },
        { code: 'm2', name: '平方米 (㎡)', name_en: 'Sq Meter (㎡)', rate: 1.0 },
        { code: 'ha', name: '公顷 (ha)', name_en: 'Hectare (ha)', rate: 10000 },
        { code: 'mu', name: '亩', name_en: 'Mu (Chinese Acre)', rate: 666.6666666667 },
        { code: 'mile2', name: '平方英里 (mile²)', name_en: 'Sq Mile (mile²)', rate: 2589988.1103 },
        { code: 'acre', name: '英亩', name_en: 'Acre', rate: 4046.8564 },
        { code: 'ft2', name: '平方英尺 (ft²)', name_en: 'Sq Foot (ft²)', rate: 0.09290304 }
      ]
    },
    volume: {
      name: '体积换算',
      name_en: 'Volume',
      base: 'L',
      units: [
        { code: 'm3', name: '立方米 (m³)', name_en: 'Cu Meter (m³)', rate: 1000 },
        { code: 'dm3', name: '立方分米 (dm³)', name_en: 'Cu Decimeter (dm³)', rate: 1.0 },
        { code: 'cm3', name: '立方厘米 (cm³)', name_en: 'Cu Centimeter (cm³)', rate: 0.001 },
        { code: 'L', name: '升 (L)', name_en: 'Liter (L)', rate: 1.0 },
        { code: 'mL', name: '毫升 (mL)', name_en: 'Milliliter (mL)', rate: 0.001 },
        { code: 'gal', name: '加仑 (gal)', name_en: 'Gallon (gal)', rate: 3.78541178 },
        { code: 'qt', name: '夸脱 (qt)', name_en: 'Quart (qt)', rate: 0.9463529 },
        { code: 'pt', name: '品脱 (pt)', name_en: 'Pint (pt)', rate: 0.4731764 }
      ]
    },
    temperature: {
      name: '温度换算',
      name_en: 'Temperature',
      base: 'C',
      units: [
        { code: 'C', name: '摄氏度 (°C)', name_en: 'Celsius (°C)' },
        { code: 'F', name: '华氏度 (°F)', name_en: 'Fahrenheit (°F)' },
        { code: 'K', name: '开氏度 (K)', name_en: 'Kelvin (K)' }
      ]
    },
    speed: {
      name: '速度换算',
      name_en: 'Speed',
      base: 'm_s',
      units: [
        { code: 'm_s', name: '米每秒 (m/s)', name_en: 'Meter/Sec (m/s)', rate: 1.0 },
        { code: 'km_h', name: '千米每小时 (km/h)', name_en: 'Kilometer/Hour (km/h)', rate: 0.2777777778 },
        { code: 'mph', name: '英里每小时 (mph)', name_en: 'Mile/Hour (mph)', rate: 0.44704 },
        { code: 'knot', name: '节 (knot)', name_en: 'Knot (knot)', rate: 0.5144444444 },
        { code: 'mach', name: '马赫 (mach)', name_en: 'Mach (mach)', rate: 340.3 }
      ]
    }
  };

  let activeCategory = 'length';
  let isUpdating = false;

  const UnitConverter = {
    init() {
      const catBtns = document.querySelectorAll('.units-cat-btn');
      catBtns.forEach((btn) => {
        btn.addEventListener('click', () => {
          catBtns.forEach((b) => b.classList.remove('active'));
          btn.classList.add('active');
          activeCategory = btn.dataset.cat;
          this.renderGrid();
        });
      });

      const btnReset = document.getElementById('btnResetUnits');
      if (btnReset) {
        btnReset.addEventListener('click', () => {
          const fields = document.querySelectorAll('.unit-input-field');
          fields.forEach(f => f.value = '');
        });
      }

      this.renderGrid();
    },

    renderGrid() {
      const grid = document.getElementById('unitsGrid');
      if (!grid) return;
      grid.innerHTML = '';

      const isEnglish = (localStorage.getItem('user_lang') || 'zh') === 'en';
      const catData = UNIT_CATEGORIES[activeCategory];

      catData.units.forEach((unit) => {
        const group = document.createElement('div');
        group.className = 'unit-input-group';
        
        const labelText = isEnglish ? (unit.name_en || unit.name) : unit.name;
        const placeholderText = isEnglish ? 'Value...' : '输入数值';

        group.innerHTML = `
          <label class="unit-label">${labelText}</label>
          <div class="unit-input-wrap">
            <input type="number" class="form-input unit-input-field" data-unit="${unit.code}" placeholder="${placeholderText}" step="any">
          </div>
        `;

        const input = group.querySelector('input');
        input.addEventListener('input', () => {
          if (isUpdating) return;
          this.convert(unit.code, parseFloat(input.value));
        });

        grid.appendChild(group);
      });
    },

    convert(sourceCode, value) {
      if (Number.isNaN(value)) {
        isUpdating = true;
        const fields = document.querySelectorAll('.unit-input-field');
        fields.forEach((f) => {
          if (f.dataset.unit !== sourceCode) f.value = '';
        });
        isUpdating = false;
        return;
      }

      isUpdating = true;
      const catData = UNIT_CATEGORIES[activeCategory];

      // 1. 计算基准单位数值
      let baseValue = 0;
      if (activeCategory === 'temperature') {
        if (sourceCode === 'C') baseValue = value;
        else if (sourceCode === 'F') baseValue = (value - 32) / 1.8;
        else if (sourceCode === 'K') baseValue = value - 273.15;
      } else {
        const srcUnit = catData.units.find(u => u.code === sourceCode);
        baseValue = value * srcUnit.rate;
      }

      // 2. 转换并更新其他输入框
      const fields = document.querySelectorAll('.unit-input-field');
      fields.forEach((f) => {
        const targetCode = f.dataset.unit;
        if (targetCode === sourceCode) return;

        let targetValue = 0;
        if (activeCategory === 'temperature') {
          if (targetCode === 'C') targetValue = baseValue;
          else if (targetCode === 'F') targetValue = baseValue * 1.8 + 32;
          else if (targetCode === 'K') targetValue = baseValue + 273.15;
        } else {
          const tgtUnit = catData.units.find(u => u.code === targetCode);
          targetValue = baseValue / tgtUnit.rate;
        }

        // 格式化输出浮点数，最大保留 8 位小数并消除浮点数垃圾尾巴
        f.value = parseFloat(Number(targetValue).toFixed(8));
      });

      isUpdating = false;
    }
  };

  window.UnitConverter = UnitConverter;
})();
