/**
 * 万能计算器 Popup 主控制脚本
 */
document.addEventListener('DOMContentLoaded', async () => {
  // ─── 1. 初始化中英文语言状态与 DOM 翻译 ───
  let currentLang = localStorage.getItem('user_lang');
  if (!currentLang) {
    // 默认获取系统或插件语言
    currentLang = (typeof chrome !== 'undefined' && chrome.i18n && chrome.i18n.getUILanguage().toLowerCase().startsWith('en')) ? 'en' : 'zh';
    localStorage.setItem('user_lang', currentLang);
  }
  
  // 翻译页面
  window.i18n.initDOMTranslation();
  updateLangButtonUI();

  // 初始化主题模式与计算器简化/科学模式
  applyTheme();
  updateCalcModeUI();

  // 语言一键切换 🌐
  const btnToggleLang = document.getElementById('btnToggleLang');
  if (btnToggleLang) {
    btnToggleLang.addEventListener('click', () => {
      currentLang = currentLang === 'zh' ? 'en' : 'zh';
      localStorage.setItem('user_lang', currentLang);
      
      // 重新翻译整个 DOM
      window.i18n.initDOMTranslation();
      updateLangButtonUI();
      applyTheme();
      updateCalcModeUI();

      // 触发各模块因语言改变而需要的局部重绘
      if (window.ExchangeRate && typeof window.ExchangeRate.init === 'function') {
        window.ExchangeRate.init();
      }
      if (window.UnitConverter && typeof window.UnitConverter.renderGrid === 'function') {
        window.UnitConverter.renderGrid();
      }
      if (window.Mortgage && typeof window.Mortgage.calculate === 'function') {
        const tbody = document.getElementById('loanResultBody');
        if (tbody && tbody.children.length > 0) {
          window.Mortgage.calculate();
        } else {
          const btnReset = document.getElementById('btnResetLoan');
          if (btnReset) btnReset.click();
        }
      }
      if (window.Bmi && typeof window.Bmi.calculate === 'function') {
        window.Bmi.calculate();
      }
    });
  }

  function updateLangButtonUI() {
    const btn = document.getElementById('btnToggleLang');
    if (!btn) return;
    btn.title = currentLang === 'zh' ? 'Switch to English' : '切换为中文';
  }

  // ─── 动态同步版本号 ───
  // 从扩展的 manifest 资源清单中动态读取当前版本，保证构建后版本显示绝对同步
  const versionBadge = document.getElementById('versionBadge');
  if (versionBadge) {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest) {
      const manifest = chrome.runtime.getManifest();
      versionBadge.textContent = `v${manifest.version}`;
    } else {
      versionBadge.textContent = 'v1.0.5';
    }
  }

  // ─── 品牌 Logo 点击跳转官网宣传页 ───
  // 插件 Popup 处于沙盒环境，常规 a 标签在新窗口打开可能失效或被拦截
  // 故优先使用 chrome.tabs.create API 引导用户跳转，对非插件环境使用 window.open 降级
  const brandLogo = document.querySelector('.brand');
  if (brandLogo) {
    brandLogo.addEventListener('click', () => {
      if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
        chrome.tabs.create({ url: 'https://ucalc.rowkin.xyz/' });
      } else {
        window.open('https://ucalc.rowkin.xyz/', '_blank');
      }
    });
  }

  // ─── 快捷 Issues 反馈跳转 ───
  const btnAboutIssues = document.getElementById('btnAboutIssues');
  if (btnAboutIssues) {
    btnAboutIssues.addEventListener('click', (e) => {
      e.preventDefault();
      const issuesUrl = 'https://github.com/rowkin/browser-plugins/issues';
      if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
        chrome.tabs.create({ url: issuesUrl });
      } else {
        window.open(issuesUrl, '_blank');
      }
    });
  }

  // ─── 主题（两态：浅色 / 深色）控制逻辑 ───
  // 去除 auto 状态，仅在 ☀️ 浅色与 🌙 深色间进行切换
  function applyTheme() {
    let themeMode = localStorage.getItem('theme_mode');
    
    // 若首次进入且未选择过主题，根据系统当前主题偏好做一次初始化并固化写入本地存储
    if (themeMode !== 'light' && themeMode !== 'dark') {
      const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      themeMode = prefersDark ? 'dark' : 'light';
      localStorage.setItem('theme_mode', themeMode);
    }
    
    const htmlEl = document.documentElement;
    const themeIcon = document.getElementById('themeIcon');
    const btnTheme = document.getElementById('btnToggleTheme');
    const isEnglish = currentLang === 'en';
    
    let tooltip = '';
    let iconStr = '';
    
    if (themeMode === 'light') {
      iconStr = '☀️';
      tooltip = isEnglish ? 'Light Theme (Click to switch to dark)' : '当前：浅色模式 (点击切换至深色)';
    } else {
      iconStr = '🌙';
      tooltip = isEnglish ? 'Dark Theme (Click to switch to light)' : '当前：深色模式 (点击切换至浅色)';
    }
    
    htmlEl.setAttribute('data-theme', themeMode);
    if (themeIcon) themeIcon.textContent = iconStr;
    if (btnTheme) btnTheme.title = tooltip;
  }

  const btnToggleTheme = document.getElementById('btnToggleTheme');
  if (btnToggleTheme) {
    btnToggleTheme.addEventListener('click', () => {
      let currentMode = localStorage.getItem('theme_mode');
      if (currentMode !== 'light' && currentMode !== 'dark') {
        const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        currentMode = prefersDark ? 'dark' : 'light';
      }
      
      // 仅在浅色和深色二态间进行直接互斥取反
      const nextMode = currentMode === 'light' ? 'dark' : 'light';
      localStorage.setItem('theme_mode', nextMode);
      applyTheme();
    });
  }

  // ─── 计算器简化/科学切换逻辑 ───
  function updateCalcModeUI() {
    const mode = localStorage.getItem('calc_mode') || 'simple';
    const gridSci = document.getElementById('calcGridSci');
    const gridSimple = document.getElementById('calcGridSimple');
    const btnToggle = document.getElementById('btnToggleCalcMode');
    
    if (!btnToggle) return;
    
    const isEnglish = currentLang === 'en';
    
    if (mode === 'simple') {
      if (gridSci) gridSci.style.display = 'none';
      if (gridSimple) gridSimple.style.display = 'grid';
      btnToggle.textContent = isEnglish ? 'Scientific Mode' : '切换科学计算';
    } else {
      if (gridSci) gridSci.style.display = 'grid';
      if (gridSimple) gridSimple.style.display = 'none';
      btnToggle.textContent = isEnglish ? 'Simple Mode' : '切换简化计算';
    }
  }

  const btnToggleCalcMode = document.getElementById('btnToggleCalcMode');
  if (btnToggleCalcMode) {
    btnToggleCalcMode.addEventListener('click', () => {
      const currentMode = localStorage.getItem('calc_mode') || 'simple';
      const newMode = currentMode === 'simple' ? 'scientific' : 'simple';
      localStorage.setItem('calc_mode', newMode);
      updateCalcModeUI();
    });
  }

  // ─── 2. Tab 页切换逻辑 ───
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabPanels = document.querySelectorAll('.tab-panel');

  tabButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');

      tabButtons.forEach(b => b.classList.remove('active'));
      tabPanels.forEach(p => p.classList.remove('active'));

      btn.classList.add('active');
      const targetPanel = document.getElementById(`panel-${targetTab}`);
      if (targetPanel) {
        targetPanel.classList.add('active');
      }

      // 特殊处理：当切换到“单位换算”或者“汇率换算”时，重新计算/对齐一下高度
      if (targetTab === 'units' && window.UnitConverter) {
        window.UnitConverter.renderGrid();
      }
    });
  });

  // ─── 3. AI 设置弹窗配置 ───
  const btnAiSettings = document.getElementById('btnAiSettings');
  const aiSettingsModal = document.getElementById('aiSettingsModal');
  const btnCloseSettings = document.getElementById('btnCloseSettings');
  const btnCancelSettings = document.getElementById('btnCancelSettings');
  const btnSaveSettings = document.getElementById('btnSaveSettings');
  const aiProviderSelect = document.getElementById('aiProviderSelect');
  const customAiFields = document.getElementById('customAiFields');

  const aiApiKeyInput = document.getElementById('aiApiKeyInput');
  const aiApiUrlInput = document.getElementById('aiApiUrlInput');
  const aiModelInput = document.getElementById('aiModelInput');

  // 打开弹窗
  if (btnAiSettings) {
    btnAiSettings.addEventListener('click', async () => {
      const config = await window.UniversalAI.getAIConfig();
      
      aiProviderSelect.value = config.provider || 'builtin';
      aiApiKeyInput.value = config.apiKey || '';
      aiApiUrlInput.value = config.apiUrl || '';
      aiModelInput.value = config.model || '';

      toggleCustomFields(aiProviderSelect.value);
      if (aiSettingsModal) aiSettingsModal.style.display = 'flex';
    });
  }

  // 关闭弹窗
  const closeSettingsModal = () => {
    if (aiSettingsModal) aiSettingsModal.style.display = 'none';
  };

  if (btnCloseSettings) btnCloseSettings.addEventListener('click', closeSettingsModal);
  if (btnCancelSettings) btnCancelSettings.addEventListener('click', closeSettingsModal);

  // 保存配置
  if (btnSaveSettings) {
    btnSaveSettings.addEventListener('click', async () => {
      const config = {
        provider: aiProviderSelect.value,
        apiKey: aiApiKeyInput.value.trim(),
        apiUrl: aiApiUrlInput.value.trim(),
        model: aiModelInput.value.trim()
      };

      await window.UniversalAI.saveAIConfig(config);
      alert(currentLang === 'zh' ? 'AI 引擎配置保存成功！' : 'AI configuration saved successfully!');
      closeSettingsModal();
    });
  }

  // 切换服务商显示字段
  if (aiProviderSelect) {
    aiProviderSelect.addEventListener('change', (e) => {
      toggleCustomFields(e.target.value);
    });
  }

  function toggleCustomFields(provider) {
    if (customAiFields) {
      customAiFields.style.display = provider === 'custom' ? 'block' : 'none';
    }
  }

  // ─── 4. 初始化六大计算子组件 ───
  if (window.StandardCalc && typeof window.StandardCalc.init === 'function') {
    window.StandardCalc.init();
  }
  if (window.ExchangeRate && typeof window.ExchangeRate.init === 'function') {
    window.ExchangeRate.init();
  }
  if (window.Mortgage && typeof window.Mortgage.init === 'function') {
    window.Mortgage.init();
  }
  if (window.UnitConverter && typeof window.UnitConverter.init === 'function') {
    window.UnitConverter.init();
  }
  if (window.CapitalConvert && typeof window.CapitalConvert.init === 'function') {
    window.CapitalConvert.init();
  }
  if (window.Bmi && typeof window.Bmi.init === 'function') {
    window.Bmi.init();
  }
});
