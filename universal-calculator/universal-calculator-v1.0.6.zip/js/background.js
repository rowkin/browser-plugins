/**
 * 万能计算器 Background Service Worker
 * 代理前台 AI 网络请求，绕开 WAF 对 chrome-extension:// Origin 的封锁。
 * 策略：
 *  1. 首先以【非流式】模式请求，获取完整文本后返回前台做打字机渲染（兼容性最佳）。
 *  2. 若服务端明确返回了 SSE 流式格式，也能正确解析并实时管道传输。
 */

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'ai-stream') return;

  port.onMessage.addListener(async (msg) => {
    if (msg.type !== 'request') return;

    const { url, headers, body: bodyStr } = msg.data;
    let bodyObj = {};
    try {
      bodyObj = JSON.parse(bodyStr);
    } catch (e) {}

    // 强制改为非流式：更兼容，避免流格式不一致导致静默卡死
    const nonStreamBody = { ...bodyObj, stream: false };

    try {
      console.log('[BG] Sending AI request to:', url, 'model:', bodyObj.model);

      const response = await fetch(url, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(nonStreamBody)
      });

      console.log('[BG] Response status:', response.status);

      if (!response.ok) {
        let errorMsg = `HTTP Error ${response.status}`;
        try {
          const text = await response.text();
          console.warn('[BG] Error response body:', text);
          const json = JSON.parse(text);
          errorMsg = json.error?.message || json.message || errorMsg;
        } catch (e) {}
        safeSend(port, { type: 'error', message: errorMsg });
        return;
      }

      const contentType = response.headers.get('content-type') || '';

      // 若服务端仍以 SSE 流式响应（text/event-stream）
      if (contentType.includes('event-stream') || contentType.includes('text/plain')) {
        console.log('[BG] Server returned streaming format, parsing SSE...');
        const reader = response.body.getReader();
        const decoder = new TextDecoder('utf-8');
        let buffer = '';
        let fullText = '';
        let chunkCount = 0;

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() ?? '';

          for (const line of lines) {
            const clean = line.trim();
            if (!clean || clean === 'data: [DONE]' || clean === 'data:[DONE]') continue;

            if (clean.startsWith('data:')) {
              const jsonStr = clean.substring(5).trim();
              try {
                const parsed = JSON.parse(jsonStr);
                // 兼容 delta.content（SSE增量）和 message.content（非流式）
                const content =
                  parsed.choices?.[0]?.delta?.content ||
                  parsed.choices?.[0]?.message?.content ||
                  '';
                if (content) {
                  fullText += content;
                  chunkCount++;
                  safeSend(port, { type: 'chunk', text: fullText });
                }
              } catch (e) {
                console.warn('[BG] SSE parse error for line:', clean, e.message);
              }
            }
          }
        }

        // 处理末尾残余 buffer
        if (buffer.trim().startsWith('data:')) {
          const jsonStr = buffer.trim().substring(5).trim();
          if (jsonStr && jsonStr !== '[DONE]') {
            try {
              const parsed = JSON.parse(jsonStr);
              const content = parsed.choices?.[0]?.delta?.content || parsed.choices?.[0]?.message?.content || '';
              if (content) {
                fullText += content;
                safeSend(port, { type: 'chunk', text: fullText });
              }
            } catch (e) {}
          }
        }

        console.log('[BG] SSE done. Total chunks:', chunkCount, 'Total length:', fullText.length);
        safeSend(port, { type: 'done', text: fullText });

      } else {
        // 标准 JSON 响应（非流式）
        const data = await response.json();
        console.log('[BG] JSON response received, choices:', data.choices?.length);

        const text =
          data.choices?.[0]?.message?.content ||
          data.choices?.[0]?.text ||
          data.content ||
          '';

        if (!text) {
          console.warn('[BG] Empty content from response:', JSON.stringify(data).substring(0, 300));
        }

        safeSend(port, { type: 'done', text });
      }
    } catch (err) {
      console.error('[BG] Fetch error:', err.message);
      safeSend(port, { type: 'error', message: err.message || 'Background fetch failed' });
    } finally {
      try { port.disconnect(); } catch (e) {}
    }
  });
});

/** 安全发送消息，防止 port 已关闭时抛出错误 */
function safeSend(port, msg) {
  try {
    port.postMessage(msg);
  } catch (e) {
    console.warn('[BG] safeSend failed (port closed):', e.message);
  }
}
