/**
 * 万能计算器 Background Service Worker
 * 代理前台 AI 网络请求，绕开 WAF 对 chrome-extension:// Origin 的封锁。
 *
 * 最佳策略：强制非流式 (stream: false)，直接拿完整 JSON 响应，
 * 前台拿到完整文本后用本地 simulateTypewriter 做打字机渐显。
 */

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'ai-stream') return;

  port.onMessage.addListener(async (msg) => {
    if (msg.type !== 'request') return;

    const { url, headers, body: bodyStr } = msg.data;
    let bodyObj = {};
    try { bodyObj = JSON.parse(bodyStr); } catch (e) {}

    // 强制改为非流式，避免流格式差异导致的解析失败
    const nonStreamBody = { ...bodyObj, stream: false };

    // 25 秒 AbortController 超时（前台已有 30s 保险，后台提前中止以给前台错误上报时间）
    const abortCtrl = new AbortController();
    const abortTimer = setTimeout(() => abortCtrl.abort(), 25000);

    try {
      console.log('[BG] → Request:', url, '| model:', bodyObj.model);

      const response = await fetch(url, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(nonStreamBody),
        signal: abortCtrl.signal
      });

      clearTimeout(abortTimer);
      console.log('[BG] ← Status:', response.status, response.statusText);

      if (!response.ok) {
        let errorMsg = `HTTP ${response.status} ${response.statusText}`;
        try {
          const rawText = await response.text();
          console.warn('[BG] Error body:', rawText.substring(0, 500));
          const errJson = JSON.parse(rawText);
          errorMsg = errJson?.error?.message || errJson?.message || errorMsg;
        } catch (e) {}
        safeSend(port, { type: 'error', message: errorMsg });
        return;
      }

      // 先拿 text()，再尝试 JSON 解析（更健壮，避免 body 锁定问题）
      const rawText = await response.text();
      console.log('[BG] ← Body length:', rawText.length, '| Preview:', rawText.substring(0, 200));

      let content = '';

      // 尝试标准 JSON 解析
      try {
        const json = JSON.parse(rawText);
        content =
          json?.choices?.[0]?.message?.content ||
          json?.choices?.[0]?.text ||
          json?.content ||
          '';
        console.log('[BG] Parsed JSON content length:', content.length);
      } catch (parseErr) {
        // 可能是 SSE 格式，尝试提取 data: 行
        console.warn('[BG] JSON parse failed, trying SSE extraction...');
        const lines = rawText.split('\n');
        for (const line of lines) {
          const clean = line.trim();
          if (!clean.startsWith('data:')) continue;
          const jsonStr = clean.substring(5).trim();
          if (jsonStr === '[DONE]') continue;
          try {
            const chunk = JSON.parse(jsonStr);
            const delta =
              chunk?.choices?.[0]?.delta?.content ||
              chunk?.choices?.[0]?.message?.content ||
              '';
            content += delta;
          } catch (e) {}
        }
        console.log('[BG] SSE-extracted content length:', content.length);
      }

      if (!content) {
        console.error('[BG] Empty content! Full body:', rawText.substring(0, 1000));
        safeSend(port, {
          type: 'error',
          message: `AI 返回内容为空，请检查模型(${bodyObj.model})和 API Key 是否正确配置。`
        });
        return;
      }

      safeSend(port, { type: 'done', text: content });
    } catch (err) {
      clearTimeout(abortTimer);
      if (err.name === 'AbortError') {
        console.error('[BG] Request aborted due to 25s timeout');
        safeSend(port, { type: 'error', message: 'AI 请求超时（25s），请检查网络连通性或换用响应更快的模型。' });
      } else {
        console.error('[BG] Fetch error:', err.name, err.message);
        safeSend(port, { type: 'error', message: `请求失败: ${err.message}` });
      }
    } finally {
      try { port.disconnect(); } catch (e) {}
    }
  });
});

function safeSend(port, msg) {
  try { port.postMessage(msg); } catch (e) {
    console.warn('[BG] safeSend failed:', e.message);
  }
}
