/**
 * 万能计算器 Background Service Worker
 * 代理前台 AI 网络请求，绕开 WAF 对 chrome-extension:// Origin 的封锁。
 *
 * 策略：优先使用真实 SSE 流式，让用户尽快看到第一个 token（首字符延迟最小化）。
 * 若服务端降级为非流式 JSON 响应，也能正确解析并模拟打字机。
 */

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'ai-stream') return;

  port.onMessage.addListener(async (msg) => {
    if (msg.type !== 'request') return;

    const { url, headers, body: bodyStr } = msg.data;
    let bodyObj = {};
    try { bodyObj = JSON.parse(bodyStr); } catch (e) {}

    // 使用真实流式：用户可在 1~3 秒内看到第一个 token，无需等待全部生成完成
    const streamBody = { ...bodyObj, stream: true };

    // 3 分钟 AbortController 超时（kimi-k2.6 等推理模型总生成时长可达 1~2 分钟）
    const abortCtrl = new AbortController();
    const abortTimer = setTimeout(() => abortCtrl.abort(), 180000);

    try {
      console.log('[BG] → SSE Request:', url, '| model:', bodyObj.model);

      const response = await fetch(url, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(streamBody),
        signal: abortCtrl.signal
      });

      clearTimeout(abortTimer);
      console.log('[BG] ← Status:', response.status, '| Content-Type:', response.headers.get('content-type'));

      if (!response.ok) {
        let errorMsg = `HTTP ${response.status} ${response.statusText}`;
        try {
          const rawText = await response.text();
          console.warn('[BG] Error body:', rawText.substring(0, 500));
          const errJson = JSON.parse(rawText);
          errorMsg = errJson?.error?.message || errJson?.message || errorMsg;
        } catch (e) {}
        safeSend(port, { type: 'error', message: errorMsg });
        return;
      }

      const contentType = response.headers.get('content-type') || '';
      console.log('[BG] Response is streaming:', contentType.includes('event-stream') || contentType.includes('text/plain'));

      // ─── 情况 A：服务端正常返回 SSE 流式 ───────────────────────────
      if (contentType.includes('event-stream') || contentType.includes('text/plain') || contentType.includes('octet-stream')) {
        const reader = response.body.getReader();
        const decoder = new TextDecoder('utf-8');
        let buffer = '';
        let fullText = '';
        let chunkCount = 0;

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() ?? '';

          for (const line of lines) {
            const clean = line.trim();
            if (!clean) continue;

            if (clean === 'data: [DONE]' || clean === 'data:[DONE]') {
              // 流式传输正常结束
              continue;
            }

            if (clean.startsWith('data:')) {
              const jsonStr = clean.substring(5).trim();
              try {
                const parsed = JSON.parse(jsonStr);
                const content =
                  parsed.choices?.[0]?.delta?.content ||
                  parsed.choices?.[0]?.message?.content ||
                  '';
                if (content) {
                  fullText += content;
                  chunkCount++;
                  safeSend(port, { type: 'chunk', text: fullText });
                }
              } catch (e) {
                // 忽略 SSE 格式的非 JSON 行（如 event: 或 id: 行）
              }
            }
          }
        }

        // 处理末尾残余 buffer
        if (buffer.trim().startsWith('data:')) {
          const jsonStr = buffer.trim().substring(5).trim();
          if (jsonStr && jsonStr !== '[DONE]') {
            try {
              const parsed = JSON.parse(jsonStr);
              const content = parsed.choices?.[0]?.delta?.content || '';
              if (content) {
                fullText += content;
                safeSend(port, { type: 'chunk', text: fullText });
              }
            } catch (e) {}
          }
        }

        console.log('[BG] SSE done. Chunks:', chunkCount, '| Total length:', fullText.length);

        if (!fullText) {
          safeSend(port, { type: 'error', message: `AI 返回内容为空，请检查模型(${bodyObj.model})是否支持此 API。` });
        } else {
          safeSend(port, { type: 'done', text: fullText });
        }

      } else {
        // ─── 情况 B：服务端降级为标准 JSON 非流式响应 ──────────────────
        console.log('[BG] Fallback to JSON non-streaming parse...');
        const rawText = await response.text();
        console.log('[BG] JSON body length:', rawText.length, '| Preview:', rawText.substring(0, 200));

        let content = '';
        try {
          const json = JSON.parse(rawText);
          content = json?.choices?.[0]?.message?.content || json?.choices?.[0]?.text || json?.content || '';
        } catch (e) {
          console.error('[BG] JSON parse error:', e.message);
        }

        if (!content) {
          safeSend(port, { type: 'error', message: `AI 返回内容为空，请检查模型(${bodyObj.model})配置。` });
        } else {
          safeSend(port, { type: 'done', text: content });
        }
      }

    } catch (err) {
      clearTimeout(abortTimer);
      if (err.name === 'AbortError') {
        console.error('[BG] Request aborted (3min timeout)');
        safeSend(port, { type: 'error', message: 'AI 请求超时（3分钟），请检查网络或换用响应更快的模型（推荐：doubao-seed-2.0-pro）。' });
      } else {
        console.error('[BG] Fetch error:', err.name, err.message);
        safeSend(port, { type: 'error', message: `请求失败: ${err.message}` });
      }
    } finally {
      try { port.disconnect(); } catch (e) {}
    }
  });
});

function safeSend(port, msg) {
  try { port.postMessage(msg); } catch (e) {
    console.warn('[BG] safeSend failed (port closed):', e.message);
  }
}
