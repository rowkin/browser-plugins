/**
 * 房贷月供推演模块
 */
(function () {
  const Mortgage = {
    init() {
      const btnCalc = document.getElementById('btnCalcLoan');
      const btnReset = document.getElementById('btnResetLoan');
      const btnAi = document.getElementById('btnLoanAiAnalyze');
      
      if (btnCalc) {
        btnCalc.addEventListener('click', () => this.calculate());
      }
      if (btnAi) {
        btnAi.addEventListener('click', () => this.analyzeAI());
      }
      if (btnReset) {
        btnReset.addEventListener('click', () => {
          document.getElementById('loanAmount').value = '100';
          document.getElementById('loanRate').value = '3.8';
          document.getElementById('loanYears').value = '30';
          const tbody = document.getElementById('loanResultBody');
          if (tbody) tbody.innerHTML = '';
          
          const isEnglish = window.i18n.getMessage('tab_standard') === 'Scientific';
          document.getElementById('summaryFirstMonth').textContent = isEnglish ? '0.00 CNY' : '0.00 元';
          document.getElementById('summaryTotalInterest').textContent = isEnglish ? '0.00 10k CNY' : '0.00 万元';
          document.getElementById('summaryTotalRepay').textContent = isEnglish ? '0.00 10k CNY' : '0.00 万元';
          document.getElementById('summaryDecrease').textContent = isEnglish ? 'Fixed' : '固定额度';
          
          const method = document.getElementById('loanMethod').value;
          const firstMonthLabel = document.getElementById('firstMonthLabel');
          const decreaseLabel = document.getElementById('decreaseLabel');
          if (firstMonthLabel) {
            firstMonthLabel.textContent = isEnglish 
              ? (method === 'acpi' ? 'Monthly Payment' : 'First Month Pay') 
              : (method === 'acpi' ? '每月月供' : '首月月供');
          }
          if (decreaseLabel) {
            decreaseLabel.textContent = isEnglish 
              ? (method === 'acpi' ? 'Monthly Trend' : 'Monthly Decrease') 
              : (method === 'acpi' ? '月供性质' : '每月递减');
          }

          const aiOutput = document.getElementById('loanAiOutput');
          if (aiOutput) {
            aiOutput.innerHTML = `
              <ul class="default-tips">
                <li data-i18n="mortgage_tip_1">按时足额还本付息，保持良好的个人征信与流动性储备。</li>
                <li data-i18n="mortgage_tip_2">建议将每月房贷支出控制在家庭月可支配收入的 40% 以内。</li>
                <li data-i18n="mortgage_tip_3">若稳健理财年化收益低于房贷年利率，资金充裕时可考虑提前还贷。</li>
                <li data-i18n="mortgage_tip_4">等额本金总利息较低但前期月供较重，等额本息利息稍多但月供平稳。</li>
              </ul>
            `;
            if (window.i18n && typeof window.i18n.initDOMTranslation === 'function') {
              window.i18n.initDOMTranslation();
            }
          }
        });
      }
    },

    calculate() {
      const amountVal = parseFloat(document.getElementById('loanAmount').value);
      const rateVal = parseFloat(document.getElementById('loanRate').value);
      const yearsVal = parseFloat(document.getElementById('loanYears').value);
      const method = document.getElementById('loanMethod').value; // acpi (等额本息) 或 acp (等额本金)

      const isEnglish = window.i18n.getMessage('tab_standard') === 'Scientific';

      if (Number.isNaN(amountVal) || amountVal <= 0) {
        alert(isEnglish ? 'Please enter a valid loan amount.' : '请输入正确的贷款总额');
        return;
      }
      if (Number.isNaN(yearsVal) || yearsVal <= 0) {
        alert(isEnglish ? 'Please enter a valid term.' : '请输入正确的贷款期限');
        return;
      }
      if (Number.isNaN(rateVal) || rateVal <= 0) {
        alert(isEnglish ? 'Please enter a valid interest rate.' : '请输入正确的利率');
        return;
      }

      const months = yearsVal * 12;
      const principal = amountVal * 10000; // 万元转元
      const annualRate = rateVal / 100;
      const monthlyRate = annualRate / 12; // 月利率

      const tbody = document.getElementById('loanResultBody');
      if (!tbody) return;
      tbody.innerHTML = '';

      const firstMonthLabel = document.getElementById('firstMonthLabel');
      const decreaseLabel = document.getElementById('decreaseLabel');

      let totalInterest = 0;
      let totalRepay = 0;
      let firstMonthPay = 0;
      let monthlyDecrease = 0;

      const listData = [];

      if (method === 'acpi') {
        // 1. 等额本息
        if (firstMonthLabel) firstMonthLabel.textContent = isEnglish ? 'Monthly Payment' : '每月月供';
        if (decreaseLabel) decreaseLabel.textContent = isEnglish ? 'Monthly Trend' : '月供性质';

        // 每月月供公式: [P * R * (1 + R)^N] / [(1 + R)^N - 1]
        const monthlyPay = principal * (monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1);
        firstMonthPay = monthlyPay;
        monthlyDecrease = 0;

        const summaryDecrease = document.getElementById('summaryDecrease');
        if (summaryDecrease) summaryDecrease.textContent = isEnglish ? 'Fixed' : '固定额度';

        let remainingPrincipal = principal;
        let accumulatedPrincipal = 0;
        let accumulatedInterest = 0;

        totalRepay = monthlyPay * months;
        totalInterest = totalRepay - principal;

        for (let m = 1; m <= months; m++) {
          const interest = remainingPrincipal * monthlyRate; // 当期利息
          const principalPaid = monthlyPay - interest; // 当期本金

          accumulatedPrincipal += principalPaid;
          accumulatedInterest += interest;
          remainingPrincipal -= principalPaid;

          const displayRemainingPrincipal = Math.max(0, remainingPrincipal);
          const displayRemainingInterest = Math.max(0, totalInterest - accumulatedInterest);

          listData.push({
            num: m,
            monthlyPay: monthlyPay,
            principalPaid: principalPaid,
            interestPaid: interest,
            accumulatedPrincipal: accumulatedPrincipal,
            accumulatedInterest: accumulatedInterest,
            remainingPrincipal: displayRemainingPrincipal,
            remainingInterest: displayRemainingInterest
          });
        }
      } else {
        // 2. 等额本金
        if (firstMonthLabel) firstMonthLabel.textContent = isEnglish ? 'First Month Pay' : '首月月供';
        if (decreaseLabel) decreaseLabel.textContent = isEnglish ? 'Monthly Decrease' : '每月递减';

        // 每月本金固定
        const principalPerMonth = principal / months;
        let remainingPrincipal = principal;
        let accumulatedPrincipal = 0;
        let accumulatedInterest = 0;

        // 每月递减额: 每月应还本金 * 月利率
        monthlyDecrease = principalPerMonth * monthlyRate;
        const summaryDecrease = document.getElementById('summaryDecrease');
        if (summaryDecrease) {
          summaryDecrease.textContent = isEnglish 
            ? `${monthlyDecrease.toFixed(2)} CNY`
            : `${monthlyDecrease.toFixed(2)} 元`;
        }

        const tempPayments = [];
        for (let m = 1; m <= months; m++) {
          const interest = remainingPrincipal * monthlyRate; // 当期利息
          const monthlyPay = principalPerMonth + interest; // 当期月供

          accumulatedPrincipal += principalPerMonth;
          accumulatedInterest += interest;
          remainingPrincipal -= principalPerMonth;

          tempPayments.push({
            num: m,
            monthlyPay: monthlyPay,
            principalPaid: principalPerMonth,
            interestPaid: interest,
            accumulatedPrincipal: accumulatedPrincipal,
            accumulatedInterest: accumulatedInterest,
            remainingPrincipal: Math.max(0, remainingPrincipal)
          });
        }

        totalInterest = accumulatedInterest;
        totalRepay = principal + totalInterest;
        firstMonthPay = tempPayments[0].monthlyPay;

        tempPayments.forEach((p) => {
          listData.push({
            ...p,
            remainingInterest: Math.max(0, totalInterest - p.accumulatedInterest)
          });
        });
      }

      // 更新汇总卡片
      document.getElementById('summaryFirstMonth').textContent = isEnglish 
        ? `${firstMonthPay.toFixed(2)} CNY` 
        : `${firstMonthPay.toFixed(2)} 元`;
      document.getElementById('summaryTotalInterest').textContent = isEnglish 
        ? `${(totalInterest / 10000).toFixed(2)} 10k CNY` 
        : `${(totalInterest / 10000).toFixed(2)} 万元`;
      document.getElementById('summaryTotalRepay').textContent = isEnglish 
        ? `${(totalRepay / 10000).toFixed(2)} 10k CNY` 
        : `${(totalRepay / 10000).toFixed(2)} 万元`;

      // 渲染汇总表头及合计行
      const totalRow = document.createElement('tr');
      totalRow.className = 'total-row';
      totalRow.innerHTML = isEnglish ? `
        <td>Total</td>
        <td>${(totalRepay / 10000).toFixed(2)} 10k</td>
        <td>${(principal / 10000).toFixed(2)} 10k</td>
        <td>${(totalInterest / 10000).toFixed(2)} 10k</td>
        <td colspan="4" style="color:var(--text-tertiary);font-weight:normal;text-align:center">Summary Value - Details Below</td>
      ` : `
        <td>合计</td>
        <td>${(totalRepay / 10000).toFixed(2)} 万元</td>
        <td>${(principal / 10000).toFixed(2)} 万元</td>
        <td>${(totalInterest / 10000).toFixed(2)} 万元</td>
        <td colspan="4" style="color:var(--text-tertiary);font-weight:normal;text-align:center">以汇总值为准 · 详细推演如下</td>
      `;
      tbody.appendChild(totalRow);

      // 插入每期还款明细行（在 Popup 中限制只展示前 12 期和最后一期，或者为了简洁提供滚动条展示全部）
      // 由于我们有独立的明细抽屉/滚动表格，可以全部渲染，利用 CSS 滚动十分丝滑！
      listData.forEach((item) => {
        const row = document.createElement('tr');
        row.innerHTML = isEnglish ? `
          <td>M ${item.num}</td>
          <td>${item.monthlyPay.toFixed(2)}</td>
          <td>${item.principalPaid.toFixed(2)}</td>
          <td>${item.interestPaid.toFixed(2)}</td>
          <td>${(item.remainingPrincipal / 10000).toFixed(4)} 10k</td>
          <td>${(item.remainingInterest / 10000).toFixed(4)} 10k</td>
        ` : `
          <td>第 ${item.num} 期</td>
          <td>${item.monthlyPay.toFixed(2)}</td>
          <td>${item.principalPaid.toFixed(2)}</td>
          <td>${item.interestPaid.toFixed(2)}</td>
          <td>${(item.remainingPrincipal / 10000).toFixed(4)} 万</td>
          <td>${(item.remainingInterest / 10000).toFixed(4)} 万</td>
        `;
        tbody.appendChild(row);
      });
    },

    async analyzeAI() {
      const btnAi = document.getElementById('btnLoanAiAnalyze');
      const btnAiText = document.getElementById('btnLoanAiAnalyzeText');
      const aiOutput = document.getElementById('loanAiOutput');

      const isEnglish = (localStorage.getItem('user_lang') || 'zh') === 'en';

      const amountVal = document.getElementById('loanAmount') ? document.getElementById('loanAmount').value : '';
      const rateVal = document.getElementById('loanRate') ? document.getElementById('loanRate').value : '';
      const yearsVal = document.getElementById('loanYears') ? document.getElementById('loanYears').value : '';
      const methodSelect = document.getElementById('loanMethod');
      const methodText = methodSelect ? methodSelect.options[methodSelect.selectedIndex].text : '';

      const summaryFirstMonth = document.getElementById('summaryFirstMonth') ? document.getElementById('summaryFirstMonth').textContent : '';
      const summaryTotalInterest = document.getElementById('summaryTotalInterest') ? document.getElementById('summaryTotalInterest').textContent : '';
      const summaryTotalRepay = document.getElementById('summaryTotalRepay') ? document.getElementById('summaryTotalRepay').textContent : '';

      if (!amountVal || !rateVal || !yearsVal) {
        alert(isEnglish ? 'Please complete the loan form first.' : '请先填写正确的贷款金额、利率和期限。');
        return;
      }

      // API Key 校验（针对 custom 模式）
      const config = await window.UniversalAI.getAIConfig();
      if (config.provider === 'custom' && !config.apiKey) {
        if (aiOutput) {
          aiOutput.style.display = 'block';
          aiOutput.innerHTML = `
            <div style="padding: 12px; border-radius: 8px; background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.2); color: #d97706; font-size: 13px; line-height: 1.5;">
              ${isEnglish 
                ? '⚠️ API Key is missing. Please click the ⚙️ gear icon in the top right header and configure your custom API settings first.' 
                : '⚠️ 缺失 API Key 密钥。请点击右上角 ⚙️ 设置图标，在 AI 配置弹窗中填写您的 API Key 密钥。'}
            </div>
          `;
        }
        return;
      }

      // 1. 转为 Loading 状态
      if (btnAi) {
        btnAi.disabled = true;
        btnAi.style.opacity = '0.7';
        btnAi.style.cursor = 'not-allowed';
      }
      if (btnAiText) btnAiText.textContent = isEnglish ? 'Analyzing...' : '正在分析...';

      const aiOutputCard = document.getElementById('loanAiOutputCard');
      if (aiOutput) {
        aiOutput.style.display = 'block';
        aiOutput.innerHTML = `
          <div class="ai-loading-container" style="display:flex;flex-direction:column;align-items:center;padding:24px 0;gap:12px">
            <div class="loading-spinner" style="width:28px;height:28px;border:3px solid var(--border-light);border-top:3px solid var(--accent);border-radius:50%;animation:spin 1s linear infinite"></div>
            <div style="font-size:12px;color:var(--text-secondary)">${window.i18n.getMessage('ai_loading_text')}</div>
          </div>
        `;
        if (aiOutputCard) {
          setTimeout(() => {
            aiOutputCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
          }, 80);
        }
      }

      // 2. 构建 Prompt
      const systemPrompt = isEnglish
        ? 'You are a senior financial advisor specializing in real estate finance and household asset allocation. Based on the user\'s mortgage parameters (loan amount, interest rate, term, repayment method and calculated payments), provide a structured, practical analysis including: 1. Repayment burden and debt ratio safety; 2. Equal payments vs equal principal comparison; 3. Prepayment and asset allocation advice. Keep it structured and action-oriented.'
        : '你是一位精通房产金融与家庭资产配置的资深理财顾问。请根据用户输入的房贷总额、年利率、贷款期限、还款方式及月供推演结果，为用户提供一份专业且易懂的理财评估与还款决策方案。包含：1. 房贷月供负担与风险分析（占收入合理比重）；2. 等额本息 vs 等额本金对比优劣势分析；3. 提前还款与资金理财配置建议（结合年化利率与通胀逻辑）。请使用 Markdown 格式，排版精美清晰。';

      const userPrompt = isEnglish
        ? `Loan Amount: ${amountVal} 10k CNY, Rate: ${rateVal}%, Term: ${yearsVal} years, Repayment Method: ${methodText}. Calculated Summary: First Month Pay: ${summaryFirstMonth}, Total Interest: ${summaryTotalInterest}, Total Payment: ${summaryTotalRepay}. Please provide financial advice.`
        : `我的贷款总额是 ${amountVal} 万元，年利率 ${rateVal}%，期限 ${yearsVal} 年，还款方式为「${methodText}」。推演结果：首月月供 ${summaryFirstMonth}，总利息 ${summaryTotalInterest}，总还款额 ${summaryTotalRepay}。请给出详细的理财与决策分析。`;

      try {
        const finalResult = await window.UniversalAI.callAI(systemPrompt, userPrompt, (fullText) => {
          if (aiOutput) {
            if (typeof window.renderInlineMarkdown === 'function') {
              aiOutput.innerHTML = window.renderInlineMarkdown(fullText, true);
            } else {
              aiOutput.textContent = fullText;
            }
          }
        });

        if (aiOutput && finalResult) {
          if (typeof window.renderInlineMarkdown === 'function') {
            aiOutput.innerHTML = window.renderInlineMarkdown(finalResult, false);
          } else {
            aiOutput.textContent = finalResult;
          }
        }
      } catch (err) {
        if (aiOutput) {
          aiOutput.innerHTML = `
            <div style="padding: 12px; border-radius: 8px; background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.2); color: #dc2626; font-size: 13px;">
              ❌ ${err.message || (isEnglish ? 'Failed to invoke AI service.' : '调用 AI 服务失败')}
            </div>
          `;
        }
      } finally {
        if (btnAi) {
          btnAi.disabled = false;
          btnAi.style.opacity = '1';
          btnAi.style.cursor = 'pointer';
        }
        if (btnAiText) btnAiText.textContent = window.i18n.getMessage('btn_ai_analyze');
      }
    }
  };

  window.Mortgage = Mortgage;
})();
