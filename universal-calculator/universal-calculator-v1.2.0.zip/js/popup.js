/**
 * 万能计算器 Popup 主控制脚本
 */
document.addEventListener('DOMContentLoaded', async () => {
  // ─── 1. 初始化中英文语言状态与 DOM 翻译 ───
  let currentLang = localStorage.getItem('user_lang');
  if (!currentLang) {
    // 默认获取系统或插件语言
    currentLang = (typeof chrome !== 'undefined' && chrome.i18n && chrome.i18n.getUILanguage().toLowerCase().startsWith('en')) ? 'en' : 'zh';
    localStorage.setItem('user_lang', currentLang);
  }
  
  // 翻译页面
  window.i18n.initDOMTranslation();
  updateLangButtonUI();

  // 初始化主题模式与计算器简化/科学模式
  applyTheme();
  updateCalcModeUI();

  // 语言一键切换 🌐
  const btnToggleLang = document.getElementById('btnToggleLang');
  if (btnToggleLang) {
    btnToggleLang.addEventListener('click', () => {
      currentLang = currentLang === 'zh' ? 'en' : 'zh';
      localStorage.setItem('user_lang', currentLang);
      
      // 重新翻译整个 DOM
      window.i18n.initDOMTranslation();
      updateLangButtonUI();
      applyTheme();
      updateCalcModeUI();

      // 触发各模块因语言改变而需要的局部重绘
      if (window.ExchangeRate && typeof window.ExchangeRate.init === 'function') {
        window.ExchangeRate.init();
      }
      if (window.UnitConverter && typeof window.UnitConverter.renderGrid === 'function') {
        window.UnitConverter.renderGrid();
      }
      if (window.Mortgage && typeof window.Mortgage.calculate === 'function') {
        const tbody = document.getElementById('loanResultBody');
        if (tbody && tbody.children.length > 0) {
          window.Mortgage.calculate();
        } else {
          const btnReset = document.getElementById('btnResetLoan');
          if (btnReset) btnReset.click();
        }
      }
      if (window.Bmi && typeof window.Bmi.calculate === 'function') {
        window.Bmi.calculate();
      }
    });
  }

  function updateLangButtonUI() {
    const btn = document.getElementById('btnToggleLang');
    if (!btn) return;
    btn.title = currentLang === 'zh' ? 'Switch to English' : '切换为中文';
  }

  // ─── 动态同步版本号 ───
  // 从扩展的 manifest 资源清单中动态读取当前版本，保证构建后版本显示绝对同步
  const versionBadge = document.getElementById('versionBadge');
  if (versionBadge) {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest) {
      const manifest = chrome.runtime.getManifest();
      versionBadge.textContent = `v${manifest.version}`;
    } else {
      versionBadge.textContent = 'v1.2.0';
    }
  }

  // ─── 品牌 Logo 点击跳转官网宣传页 ───
  // 插件 Popup 处于沙盒环境，常规 a 标签在新窗口打开可能失效或被拦截
  // 故优先使用 chrome.tabs.create API 引导用户跳转，对非插件环境使用 window.open 降级
  const brandLogo = document.querySelector('.brand');
  if (brandLogo) {
    brandLogo.addEventListener('click', () => {
      if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
        chrome.tabs.create({ url: 'https://ucalc.rowkin.xyz/' });
      } else {
        window.open('https://ucalc.rowkin.xyz/', '_blank');
      }
    });
  }

  // ─── 快捷 Issues 反馈跳转 ───
  const btnAboutIssues = document.getElementById('btnAboutIssues');
  if (btnAboutIssues) {
    btnAboutIssues.addEventListener('click', (e) => {
      e.preventDefault();
      const issuesUrl = 'https://github.com/rowkin/browser-plugins/issues';
      if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
        chrome.tabs.create({ url: issuesUrl });
      } else {
        window.open(issuesUrl, '_blank');
      }
    });
  }

  // ─── 主题（两态：浅色 / 深色）控制逻辑 ───
  // 去除 auto 状态，仅在 ☀️ 浅色与 🌙 深色间进行切换
  function applyTheme() {
    let themeMode = localStorage.getItem('theme_mode');
    
    // 若首次进入且未选择过主题，根据系统当前主题偏好做一次初始化并固化写入本地存储
    if (themeMode !== 'light' && themeMode !== 'dark') {
      const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      themeMode = prefersDark ? 'dark' : 'light';
      localStorage.setItem('theme_mode', themeMode);
    }
    
    const htmlEl = document.documentElement;
    const themeIcon = document.getElementById('themeIcon');
    const btnTheme = document.getElementById('btnToggleTheme');
    const isEnglish = currentLang === 'en';
    
    let tooltip = '';
    let iconStr = '';
    
    if (themeMode === 'light') {
      iconStr = '☀️';
      tooltip = isEnglish ? 'Light Theme (Click to switch to dark)' : '当前：浅色模式 (点击切换至深色)';
    } else {
      iconStr = '🌙';
      tooltip = isEnglish ? 'Dark Theme (Click to switch to light)' : '当前：深色模式 (点击切换至浅色)';
    }
    
    htmlEl.setAttribute('data-theme', themeMode);
    if (themeIcon) themeIcon.textContent = iconStr;
    if (btnTheme) btnTheme.title = tooltip;
  }

  const btnToggleTheme = document.getElementById('btnToggleTheme');
  if (btnToggleTheme) {
    btnToggleTheme.addEventListener('click', () => {
      let currentMode = localStorage.getItem('theme_mode');
      if (currentMode !== 'light' && currentMode !== 'dark') {
        const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        currentMode = prefersDark ? 'dark' : 'light';
      }
      
      // 仅在浅色和深色二态间进行直接互斥取反
      const nextMode = currentMode === 'light' ? 'dark' : 'light';
      localStorage.setItem('theme_mode', nextMode);
      applyTheme();
    });
  }

  // ─── 计算器简化/科学切换逻辑 ───
  function updateCalcModeUI() {
    const mode = localStorage.getItem('calc_mode') || 'simple';
    const gridSci = document.getElementById('calcGridSci');
    const gridSimple = document.getElementById('calcGridSimple');
    const btnToggle = document.getElementById('btnToggleCalcMode');
    
    if (!btnToggle) return;
    
    const isEnglish = currentLang === 'en';
    
    if (mode === 'simple') {
      if (gridSci) gridSci.style.display = 'none';
      if (gridSimple) gridSimple.style.display = 'grid';
      btnToggle.textContent = isEnglish ? 'Scientific Mode' : '切换科学计算';
    } else {
      if (gridSci) gridSci.style.display = 'grid';
      if (gridSimple) gridSimple.style.display = 'none';
      btnToggle.textContent = isEnglish ? 'Simple Mode' : '切换简化计算';
    }
  }

  const btnToggleCalcMode = document.getElementById('btnToggleCalcMode');
  if (btnToggleCalcMode) {
    btnToggleCalcMode.addEventListener('click', () => {
      const currentMode = localStorage.getItem('calc_mode') || 'simple';
      const newMode = currentMode === 'simple' ? 'scientific' : 'simple';
      localStorage.setItem('calc_mode', newMode);
      updateCalcModeUI();
    });
  }

  // ─── 2. Tab 页切换逻辑 ───
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabPanels = document.querySelectorAll('.tab-panel');

  tabButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');

      tabButtons.forEach(b => b.classList.remove('active'));
      tabPanels.forEach(p => p.classList.remove('active'));

      btn.classList.add('active');
      const targetPanel = document.getElementById(`panel-${targetTab}`);
      if (targetPanel) {
        targetPanel.classList.add('active');
      }

      // 特殊处理：当切换到“单位换算”或者“汇率换算”时，重新计算/对齐一下高度
      if (targetTab === 'units' && window.UnitConverter) {
        window.UnitConverter.renderGrid();
      }
    });
  });

  // ─── 3. AI 设置弹窗配置 ───
  const btnAiSettings = document.getElementById('btnAiSettings');
  const aiSettingsModal = document.getElementById('aiSettingsModal');
  const btnCloseSettings = document.getElementById('btnCloseSettings');
  const btnCancelSettings = document.getElementById('btnCancelSettings');
  const btnSaveSettings = document.getElementById('btnSaveSettings');
  const aiProviderSelect = document.getElementById('aiProviderSelect');
  const customAiFields = document.getElementById('customAiFields');

  const aiApiKeyInput = document.getElementById('aiApiKeyInput');
  const aiApiUrlInput = document.getElementById('aiApiUrlInput');
  const aiModelInput = document.getElementById('aiModelInput');

  // 一键检测服务可用性元素
  const btnTestAiConnection = document.getElementById('btnTestAiConnection');
  const aiTestResult = document.getElementById('aiTestResult');
  const btnTestAiText = document.getElementById('btnTestAiText');

  // 打开弹窗
  if (btnAiSettings) {
    btnAiSettings.addEventListener('click', async () => {
      const config = await window.UniversalAI.getAIConfig();
      
      aiProviderSelect.value = config.provider || 'builtin';
      aiApiKeyInput.value = config.apiKey || '';
      aiApiUrlInput.value = config.apiUrl || '';
      aiModelInput.value = config.model || '';

      // 打开时重置上一次测试反馈
      if (aiTestResult) {
        aiTestResult.style.display = 'none';
        aiTestResult.innerHTML = '';
      }

      toggleCustomFields(aiProviderSelect.value);
      if (aiSettingsModal) aiSettingsModal.style.display = 'flex';
    });
  }

  // 关闭弹窗
  const closeSettingsModal = () => {
    if (aiSettingsModal) aiSettingsModal.style.display = 'none';
    if (aiTestResult) {
      aiTestResult.style.display = 'none';
      aiTestResult.innerHTML = '';
    }
  };

  if (btnCloseSettings) btnCloseSettings.addEventListener('click', closeSettingsModal);
  if (btnCancelSettings) btnCancelSettings.addEventListener('click', closeSettingsModal);

  // 输入变化时隐藏旧的测试状态反馈
  [aiProviderSelect, aiApiKeyInput, aiApiUrlInput, aiModelInput].forEach((el) => {
    if (el) {
      el.addEventListener('input', () => {
        if (aiTestResult && aiTestResult.style.display !== 'none') {
          aiTestResult.style.display = 'none';
        }
      });
    }
  });

  // 一键检测服务连通性
  if (btnTestAiConnection) {
    btnTestAiConnection.addEventListener('click', async () => {
      const isZh = currentLang === 'zh';
      const provider = aiProviderSelect.value;
      const apiKey = aiApiKeyInput.value.trim();
      const apiUrl = aiApiUrlInput.value.trim();
      const model = aiModelInput.value.trim();

      const testConfig = {
        provider,
        apiKey,
        apiUrl,
        model
      };

      // 切换为检测中状态
      btnTestAiConnection.disabled = true;
      const originalText = btnTestAiText ? btnTestAiText.textContent : '';
      if (btnTestAiText) {
        btnTestAiText.textContent = isZh ? '正在检测中...' : 'Testing connectivity...';
      }

      if (aiTestResult) {
        aiTestResult.className = 'ai-test-feedback testing';
        aiTestResult.style.display = 'flex';
        aiTestResult.innerHTML = `
          <span class="feedback-icon" style="animation: spin 1s linear infinite; display: inline-block;">⏳</span>
          <div class="feedback-content">
            <strong>${isZh ? '正在检测 AI 服务可用性...' : 'Testing AI service availability...'}</strong>
            <div class="feedback-sub">${isZh ? '正在发送探测请求并验证模型响应，请稍候' : 'Sending probe request and verifying model response...'}</div>
          </div>
        `;
      }

      try {
        const res = await window.UniversalAI.testConnection(testConfig);
        if (aiTestResult) {
          aiTestResult.className = 'ai-test-feedback success';
          const successHeader = isZh ? 'AI 服务连接成功！' : 'AI service connected successfully!';
          const latencyLabel = `${res.latency}ms`;
          const targetInfo = provider === 'builtin'
            ? (isZh ? 'Chrome 内置 AI (Gemini Nano)' : 'Chrome built-in AI (Gemini Nano)')
            : (model || 'gpt-4o-mini');
          aiTestResult.innerHTML = `
            <span class="feedback-icon">✅</span>
            <div class="feedback-content">
              <strong>${successHeader} (${latencyLabel})</strong>
              <div class="feedback-sub">${isZh ? `模型「${targetInfo}」响应正常，服务已就绪！` : `Model "${targetInfo}" responded normally. Ready to use!`}</div>
            </div>
          `;
        }
      } catch (err) {
        if (aiTestResult) {
          aiTestResult.className = 'ai-test-feedback error';
          const failHeader = isZh ? '服务不可用或检测失败' : 'Service unavailable or test failed';
          const rawErr = err.message || String(err);
          let tip = '';
          if (rawErr.includes('AgentPlan subscription') || rawErr.includes('subscription has expired') || rawErr.includes('CodingPlan')) {
            tip = isZh ? '<strong>【提示】当前账号未开通或未绑定对应 CodingPlan/AgentPlan 套餐。</strong><br>' : '<strong>[Tip] CodingPlan/AgentPlan subscription missing or expired.</strong><br>';
          } else if (rawErr.includes('401') || rawErr.includes('Invalid API') || rawErr.includes('Incorrect API key')) {
            tip = isZh ? '<strong>【提示】API Key 鉴权失败，请检查密钥是否正确。</strong><br>' : '<strong>[Tip] Authentication failed. Please check your API Key.</strong><br>';
          } else if (rawErr.includes('404') || rawErr.includes('Not Found')) {
            tip = isZh ? '<strong>【提示】终结点不存在 (404)，请检查 API 终结点 (Endpoint) 地址。</strong><br>' : '<strong>[Tip] Endpoint not found (404). Please check the Endpoint URL.</strong><br>';
          }

          const errMsg = escapeHtml(rawErr);
          aiTestResult.innerHTML = `
            <span class="feedback-icon">❌</span>
            <div class="feedback-content">
              <strong>${failHeader}</strong>
              <div class="feedback-sub">${tip}${errMsg}</div>
            </div>
          `;
        }
      } finally {
        btnTestAiConnection.disabled = false;
        if (btnTestAiText) {
          btnTestAiText.textContent = originalText || (isZh ? '一键检测服务可用性' : 'Test Service Connectivity');
        }
      }
    });
  }

  // HTML 转义辅助函数，避免潜在 XSS
  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // 保存配置
  if (btnSaveSettings) {
    btnSaveSettings.addEventListener('click', async () => {
      const config = {
        provider: aiProviderSelect.value,
        apiKey: aiApiKeyInput.value.trim(),
        apiUrl: aiApiUrlInput.value.trim(),
        model: aiModelInput.value.trim()
      };

      await window.UniversalAI.saveAIConfig(config);
      alert(currentLang === 'zh' ? 'AI 引擎配置保存成功！' : 'AI configuration saved successfully!');
      closeSettingsModal();
    });
  }

  // 切换服务商显示字段
  if (aiProviderSelect) {
    aiProviderSelect.addEventListener('change', (e) => {
      toggleCustomFields(e.target.value);
    });
  }

  function toggleCustomFields(provider) {
    if (customAiFields) {
      customAiFields.style.display = provider === 'custom' ? 'block' : 'none';
    }
  }

  // ─── 4. 初始化六大计算子组件 ───
  if (window.StandardCalc && typeof window.StandardCalc.init === 'function') {
    window.StandardCalc.init();
  }
  if (window.ExchangeRate && typeof window.ExchangeRate.init === 'function') {
    window.ExchangeRate.init();
  }
  if (window.Mortgage && typeof window.Mortgage.init === 'function') {
    window.Mortgage.init();
  }
  if (window.UnitConverter && typeof window.UnitConverter.init === 'function') {
    window.UnitConverter.init();
  }
  if (window.CapitalConvert && typeof window.CapitalConvert.init === 'function') {
    window.CapitalConvert.init();
  }
  if (window.Bmi && typeof window.Bmi.init === 'function') {
    window.Bmi.init();
  }

  // ─── 5. 全局 AI 会话助手与上下文感知逻辑 ───
  initAIChatAssistant();
});

/** 内联轻量 Markdown 渲染器 (含打字机光标支持) */
function renderInlineMarkdown(text, showCursor = false) {
  if (!text) return '';
  let html = text
    .replace(/^#### (.*$)/gim, '<h4>$1</h4>')
    .replace(/^### (.*$)/gim, '<h3>$1</h3>')
    .replace(/^## (.*$)/gim, '<h2>$1</h2>')
    .replace(/^# (.*$)/gim, '<h1>$1</h1>')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/^\* (.*$)/gim, '<li>$1</li>')
    .replace(/\n\n/g, '<br>')
    .replace(/\n/g, '<br>');

  if (html.includes('<li>')) {
    html = html.replace(/(<li>.*<\/li>)/gs, '<ul>$1</ul>');
  }

  if (showCursor) {
    html += '<span class="ai-cursor"></span>';
  }
  return html;
}
window.renderInlineMarkdown = renderInlineMarkdown;

/** 初始化全局 AI 在线会话助手 */
function initAIChatAssistant() {
  const btnToggleAiChat = document.getElementById('btnToggleAiChat');
  const aiChatModal = document.getElementById('aiChatModal');
  const btnCloseAiChat = document.getElementById('btnCloseAiChat');
  const chatContextBadge = document.getElementById('chatContextBadge');
  const chatContextText = document.getElementById('chatContextText');
  const btnInsertChatContext = document.getElementById('btnInsertChatContext');
  const chatMessages = document.getElementById('chatMessages');
  const chatInput = document.getElementById('chatInput');
  const btnSendChat = document.getElementById('btnSendChat');
  const promptTags = document.querySelectorAll('.chat-prompt-tag');

  let activeContextData = null;

  // 打开 AI 会话弹窗并更新当前上下文
  if (btnToggleAiChat) {
    btnToggleAiChat.addEventListener('click', () => {
      updateActiveContext();
      if (window.i18n && typeof window.i18n.initDOMTranslation === 'function') {
        window.i18n.initDOMTranslation();
      }
      if (aiChatModal) aiChatModal.style.display = 'flex';
      if (chatInput) chatInput.focus();
    });
  }

  // 关闭 AI 会话弹窗
  if (btnCloseAiChat) {
    btnCloseAiChat.addEventListener('click', () => {
      if (aiChatModal) aiChatModal.style.display = 'none';
    });
  }

  // 抓取当前 Tab 面板的有效上下文
  function updateActiveContext() {
    const activeTabBtn = document.querySelector('.tab-btn.active');
    const tabName = activeTabBtn ? activeTabBtn.getAttribute('data-tab') : 'calculator';

    if (tabName === 'loan') {
      const amount = document.getElementById('loanAmount')?.value || '100';
      const rate = document.getElementById('loanRate')?.value || '3.8';
      const years = document.getElementById('loanYears')?.value || '30';
      const methodSelect = document.getElementById('loanMethod');
      const methodText = methodSelect ? methodSelect.options[methodSelect.selectedIndex].text : '';
      activeContextData = `🏠 房贷上下文：金额 ${amount} 万 | 年利率 ${rate}% | 期限 ${years} 年 | 方式: ${methodText}`;
    } else if (tabName === 'bmi') {
      const h = document.getElementById('bmiHeightInput')?.value || '175';
      const w = document.getElementById('bmiWeightInput')?.value || '65';
      const bmiVal = document.getElementById('bmiValText')?.textContent || '-';
      const status = document.getElementById('bmiStatusText')?.textContent || 'Normal';
      activeContextData = `🩺 BMI 上下文：身高 ${h}cm | 体重 ${w}kg | BMI ${bmiVal} (${status})`;
    } else if (tabName === 'exchange') {
      const fromVal = document.getElementById('exchangeFromAmount')?.value || '100';
      const fromCurr = document.getElementById('exchangeFromCurrency')?.value || 'CNY';
      const toCurr = document.getElementById('exchangeToCurrency')?.value || 'USD';
      activeContextData = `🪙 汇率上下文：从 ${fromVal} ${fromCurr} 兑换至 ${toCurr}`;
    } else if (tabName === 'calculator') {
      const display = document.getElementById('calcDisplay')?.textContent || '0';
      activeContextData = `🧮 科学计算上下文：当前表达式/数值为 ${display}`;
    } else {
      activeContextData = null;
    }

    if (chatContextBadge && chatContextText) {
      if (activeContextData) {
        chatContextBadge.style.display = 'flex';
        chatContextText.textContent = activeContextData;
      } else {
        chatContextBadge.style.display = 'none';
      }
    }
  }

  // 点击“+ 发送分析”
  if (btnInsertChatContext) {
    btnInsertChatContext.addEventListener('click', () => {
      if (activeContextData) {
        sendChatMessage(`请帮我深入分析我当前的操作面板数据：\n${activeContextData}`);
      }
    });
  }

  // 点击快捷 Prompt Tag
  promptTags.forEach(tag => {
    tag.addEventListener('click', () => {
      const prompt = tag.getAttribute('data-prompt');
      if (prompt) {
        sendChatMessage(prompt);
      }
    });
  });

  // 发送聊天消息
  if (btnSendChat) {
    btnSendChat.addEventListener('click', () => handleSendInput());
  }
  if (chatInput) {
    chatInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') handleSendInput();
    });
  }

  function handleSendInput() {
    const text = chatInput.value.trim();
    if (!text) return;
    chatInput.value = '';
    sendChatMessage(text);
  }

  async function sendChatMessage(userText) {
    if (!chatMessages) return;

    // 1. 追加用户消息气泡
    const userMsgEl = document.createElement('div');
    userMsgEl.className = 'chat-msg user';
    userMsgEl.innerHTML = `
      <div class="chat-avatar">👤</div>
      <div class="chat-bubble">${userText.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>')}</div>
    `;
    chatMessages.appendChild(userMsgEl);

    // 2. 追加 AI 消息气泡 (0ms 瞬间首帧水合: 显示上下文快照与思考光标)
    const initialAiHtml = activeContextData ? `
      <div style="font-size: 10px; color: var(--text-tertiary); margin-bottom: 4px; border-bottom: 1px dashed var(--border-light); padding-bottom: 2px;">
        📌 已关联上下文: ${activeContextData.substring(0, 45)}...
      </div>
      <span>🤖 正在结合上下文思考解答中...<span class="ai-cursor"></span></span>
    ` : `<span>🤖 正在思考解答中...<span class="ai-cursor"></span></span>`;

    const aiMsgEl = document.createElement('div');
    aiMsgEl.className = 'chat-msg assistant';
    aiMsgEl.innerHTML = `
      <div class="chat-avatar">🤖</div>
      <div class="chat-bubble">${initialAiHtml}</div>
    `;
    chatMessages.appendChild(aiMsgEl);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    const bubbleContent = aiMsgEl.querySelector('.chat-bubble');

    const systemPrompt = `你是一位全能精通的 AI 助手，嵌套于浏览器插件 Universal Calculator 中。用户当前操作上下文为：${activeContextData || '通用视图'}。请根据用户的问题提供精准、专业且美观的回答。使用 Markdown 结构化呈现。`;

    try {
      let hasStreamed = false;
      const finalResult = await window.UniversalAI.callAI(systemPrompt, userText, (fullText) => {
        if (bubbleContent) {
          hasStreamed = true;
          bubbleContent.innerHTML = renderInlineMarkdown(fullText, true);
          chatMessages.scrollTop = chatMessages.scrollHeight;
        }
      });
      // 结束去除打字光标
      if (bubbleContent && (finalResult || hasStreamed)) {
        const textToRender = finalResult || bubbleContent.innerText;
        bubbleContent.innerHTML = renderInlineMarkdown(textToRender, false);
      }
    } catch (err) {
      if (bubbleContent) {
        bubbleContent.innerHTML = `<span style="color: #ef4444;">❌ ${err.message || '调用 AI 出错'}</span>`;
      }
    }
  }
}
